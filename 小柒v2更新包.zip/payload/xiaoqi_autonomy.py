# -*- coding: utf-8 -*-
"""小柒自主演化：身份线索、模拟想法、主动联系决策。仅标准库。"""
import sqlite3, threading, re, random
from datetime import datetime,timezone,timedelta
from pathlib import Path
import xiaoqi_emotion_engine as emotion
LOCK=threading.RLock()
DB=Path(__file__).resolve().parent/'xiaoqi_emotion_data'/'autonomy.sqlite3'

def connect():
    DB.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(str(DB),timeout=10)
    c.execute('PRAGMA busy_timeout=10000')
    c.execute("""CREATE TABLE IF NOT EXISTS thoughts(id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT NOT NULL, mood TEXT, thought TEXT, target TEXT, action TEXT, outcome TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS identity_links(group_id TEXT, sender_id TEXT, private_id TEXT, status TEXT, basis TEXT, time TEXT, PRIMARY KEY(group_id,sender_id))""")
    c.execute("""CREATE TABLE IF NOT EXISTS autonomy_state(key TEXT PRIMARY KEY,value TEXT)""")
    c.commit();return c

def log(mood,thought,target='',action='想法',outcome='仅记录'):
    with LOCK:
        with connect() as c:
            c.execute('INSERT INTO thoughts(time,mood,thought,target,action,outcome) VALUES(?,?,?,?,?,?)',
                (datetime.now().astimezone().isoformat(timespec='seconds'),str(mood)[:50],str(thought)[:260],str(target)[:120],str(action)[:80],str(outcome)[:120]))
            c.execute('DELETE FROM thoughts WHERE id NOT IN (SELECT id FROM thoughts ORDER BY id DESC LIMIT 2000)')

def thinking(limit=100):
    with connect() as c:
        return c.execute('SELECT time,mood,thought,target,action,outcome FROM thoughts ORDER BY id DESC LIMIT ?', (max(1,min(int(limit),500)),)).fetchall()

def identify(group,member):
    """只凭稳定的微信ID匹配；昵称、头像、备注不可当成相同身份。"""
    group=str(group or ''); member=str(member or '').strip()
    if not group.endswith('@chatroom') or not member:return
    with emotion.db() as c:
        exists=c.execute("SELECT 1 FROM profiles WHERE uid=? AND scope='private' AND opt_out=0",(member,)).fetchone()
    status='已确认' if exists else '待关联'; private_id=member if exists else ''
    with LOCK:
        with connect() as c:
            c.execute("""INSERT INTO identity_links(group_id,sender_id,private_id,status,basis,time) VALUES(?,?,?,?,?,?)
            ON CONFLICT(group_id,sender_id) DO UPDATE SET private_id=excluded.private_id,status=excluded.status,basis=excluded.basis,time=excluded.time""",
            (group,member,private_id,status,'一致的微信唯一ID' if exists else '没有稳定私聊ID证据',datetime.now().astimezone().isoformat(timespec='seconds')))

def identities(limit=150):
    with connect() as c:return c.execute('SELECT group_id,sender_id,private_id,status,basis,time FROM identity_links ORDER BY time DESC LIMIT ?', (limit,)).fetchall()

def note_incoming(chat,sender,kind,text):
    if str(chat).endswith('@chatroom'):
        identify(chat,sender)
    elif kind=='private':
        # 私聊出现后，重新验证已记录的同ID群成员；绝不通过昵称合并档案。
        member=str(chat)
        with LOCK:
            with connect() as c:
                c.execute("UPDATE identity_links SET private_id=?,status='已确认',basis='一致的微信唯一ID' WHERE sender_id=?",(member,member))

def status_snapshot():
    try:
        with emotion.db() as c:
            rows=c.execute("""SELECT uid,affection,mood,energy,interactions,proactive_opt_in,last_seen,last_proactive
                                FROM profiles WHERE scope='private' AND opt_out=0 ORDER BY last_seen DESC LIMIT 150""").fetchall()
        return rows
    except Exception:return []

def autonomous_tick(private_chats, groups, quiet, allowed_fn, private_fn):
    """定期模拟想法并在被允许的旧发送链路内主动发言。不直接调用微信或 LLM。"""
    now=datetime.now().astimezone()
    slot=now.strftime('%Y%m%d-%H')
    if quiet:return []
    with LOCK:
        with connect() as c:
            old=c.execute('SELECT value FROM autonomy_state WHERE key=?',('tick_hour',)).fetchone()
            if old and old[0]==slot:return []
            c.execute('INSERT OR REPLACE INTO autonomy_state(key,value) VALUES(?,?)',('tick_hour',slot))
    candidates=[]
    for uid,aff,mood,energy,count,consent,last_seen,last_proactive in status_snapshot():
        if uid not in private_chats or not consent or aff<70 or count<3:continue
        if not allowed_fn(uid) or not private_fn(uid):continue
        try:hours=(now-datetime.fromisoformat(last_seen)).total_seconds()/3600
        except Exception:continue
        if (1 if aff >= 90 else 3 if aff >= 70 else 8) <= hours <= 72:candidates.append((uid,aff,mood))
    if candidates:
        uid,aff,mood=sorted(candidates,key=lambda x:-x[1])[0]
        log('有点无聊', '一段时间没人找小柒聊天，想和熟悉、同意主动私聊的人聊聊。',uid,'考虑主动私聊','等待现有发送队列与频率限制')
        return [uid]
    # 不随意向群发消息。群聊原有话题调度本身已有时间和授权限制。
    log('平静 / 偶尔无聊','回顾最近聊天；目前没有符合主动私聊条件的好友，先不打扰。',action='自主思考',outcome='保持安静')
    return []
