# -*- coding: utf-8 -*-
"""小柒情感后台：Tkinter 标准库，所有资料只在本机显示。"""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import xiaoqi_emotion_engine as e
import xiaoqi_autonomy as autonomy

class Dashboard:
    def __init__(self,root):
        self.root=root
        root.title('小柒 · 情感与记忆管理中心 v1.0')
        root.geometry('1050x720')
        self.current=''
        self.colors={'background':'#f7f8fc','text':'#202535'}
        root.configure(bg=self.colors['background'])
        head=ttk.Frame(root,padding=14);head.pack(fill='x')
        ttk.Label(head,text='小柒 · 情感与记忆管理中心',font=('Microsoft YaHei UI',17,'bold')).pack(side='left')
        ttk.Button(head,text='刷新数据',command=self.refresh).pack(side='right')
        self.stats=ttk.Label(root,text='',font=('Microsoft YaHei UI',10),padding=12)
        self.stats.pack(fill='x')
        book=ttk.Notebook(root);book.pack(fill='both',expand=True,padx=12,pady=8)
        p1=ttk.Frame(book,padding=10);book.add(p1,text='好友关系')
        p2=ttk.Frame(book,padding=10);book.add(p2,text='记忆与近期互动')
        p3=ttk.Frame(book,padding=14);book.add(p3,text='功能设置')
        p4=ttk.Frame(book,padding=14);book.add(p4,text='说明与好友申请')
        cols=('uid','label','scope','affection','trust','mood','interactions','last_seen','opt_out')
        self.tree=ttk.Treeview(p1,columns=cols,show='headings',selectmode='browse')
        names=['微信ID','备注/群昵称','来源','好感度','信任度','模拟情绪','互动次数','最近互动','记忆关闭']
        widths=[150,140,60,75,75,100,75,155,70]
        for key,name,w in zip(cols,names,widths):self.tree.heading(key,text=name);self.tree.column(key,width=w,stretch=key in ('label','last_seen'))
        self.tree.pack(fill='both',expand=True,side='top');self.tree.bind('<<TreeviewSelect>>',self.choose)
        actions=ttk.Frame(p1,padding=(0,12));actions.pack(fill='x')
        ttk.Label(actions,text='修改选中好友的好感度（0～100）：').pack(side='left')
        self.aff=tk.StringVar(value='50');ttk.Entry(actions,textvariable=self.aff,width=6).pack(side='left',padx=4)
        ttk.Button(actions,text='更新好感度',command=self.change_affection).pack(side='left',padx=5)
        ttk.Button(actions,text='彻底删除此人资料',command=self.delete_person).pack(side='left',padx=5)
        ttk.Button(actions,text='允许主动私聊',command=lambda:self.proactive(True)).pack(side='left',padx=5)
        ttk.Button(actions,text='禁止主动私聊',command=lambda:self.proactive(False)).pack(side='left',padx=5)
        ttk.Label(p2,text='选中的好友：',padding=(0,3)).pack(anchor='w')
        self.who=ttk.Label(p2,text='请先在“好友关系”页选择一位好友。');self.who.pack(anchor='w')
        self.thought=ttk.Label(p2,text='',justify='left',wraplength=970);self.thought.pack(anchor='w',pady=7)
        self.memo=tk.Text(p2,wrap='word',font=('Microsoft YaHei UI',11),height=27,background='#ffffff')
        self.memo.pack(fill='both',expand=True,pady=8)
        self.setting_vars={}
        for key,label in (
            ('enabled','启用情感与好感度系统'),
            ('private_memory_enabled','允许保存私聊记忆'),
            ('group_memory_enabled','允许保存与小柒互动的群成员记忆'),
            ('store_recent_messages','保存近期对话摘要（30天默认自动过期）'),
            ('proactive_relationship_prompt','主动话题允许关系风格提示'),
            ('owner_command_enabled','开启主人微信管理指令'),
            ('private_proactive_enabled','允许已同意的好友收到低频主动问候'),
        ):
            var=tk.BooleanVar(value=False);self.setting_vars[key]=var
            ttk.Checkbutton(p3,text=label,variable=var).pack(anchor='w',pady=8)
        ttl=ttk.Frame(p3);ttl.pack(anchor='w',pady=16)
        ttk.Label(ttl,text='近期互动保存天数：').pack(side='left')
        self.days=tk.StringVar(value='30');ttk.Combobox(ttl,width=9,values=['7','14','30','60','90'],textvariable=self.days,state='readonly').pack(side='left',padx=6)
        ttk.Button(p3,text='保存情感系统设置',command=self.save_settings).pack(anchor='w',pady=9)
        ttk.Label(p3,text='设置会被运行中的小柒读取；正在生成的回复可能仍采用旧设置。',foreground='#667085').pack(anchor='w',pady=4)
        info=('【关于情感】\n好感度、情绪和模拟“想法”只是本地交互状态机，不代表真实意识。\n'
              '每位好友按照微信ID独立存储记忆；群成员也按发送人区分。\n'
              '不会自动读取电脑文件或把 A 的私人记忆发送给 B。\n\n'
              '【好友隐私】\n好友发送“小柒 我的好感度”可查看自己的关系阶段。\n'
              '发送“小柒 我的记忆”可查看记住的事实；\n'
              '发送“小柒 别记住我”可停用记录；\n'
              '发送“小柒 清除我的记忆”可以删除并关闭后续记录。\n'
              '发送“小柒 可以主动找我”明确同意偶尔主动私聊，最多每天一次；\n'
              '发送“小柒 不要主动找我”取消同意，关闭主动私聊。\n\n'
              '【微信好友申请】\n当前上传的主程序没有经过验证的微信申请读取/通过接口。\n'
              '为避免误通过陌生人、影响原版，升级包采用“人工同意”的安全模式，\n'
              '不自动点击好友申请。通过微信客户端批准后，新好友首次聊天时自动建立个人档案。\n\n'
              '【主人管理】\n必须从原版验证的主人微信私聊发送：\n'
              '小柒情感 帮助 / 小柒情感 状态 / 小柒情感 好感度 <完整微信ID>\n'
              '【退出】关闭管理中心不会停止小柒，关闭小柒也不会删除情感记忆。')
        txt=tk.Text(p4,wrap='word',font=('Microsoft YaHei UI',11),background='#ffffff',relief='flat')
        txt.insert('1.0',info);txt.configure(state='disabled');txt.pack(fill='both',expand=True)
        # 状态日志与跨会话身份线索；不会自动共享私聊中的记忆。
        p5=ttk.Frame(book,padding=10);book.add(p5,text='自主想法日志')
        self.thought_log=tk.Text(p5,wrap='word',font=('Microsoft YaHei UI',10));self.thought_log.pack(fill='both',expand=True)
        p6=ttk.Frame(book,padding=10);book.add(p6,text='群聊身份线索')
        self.identity_log=tk.Text(p6,wrap='word',font=('Microsoft YaHei UI',10));self.identity_log.pack(fill='both',expand=True)
        ttk.Label(p6,text='仅相同稳定微信ID自动标为已确认；昵称相同不会合并；私聊内容不自动公开到群聊。').pack(anchor='w')
        self.refresh()

    def refresh(self):
        try:
            s=e.stats();self.stats.configure(text=f'好友档案 {s["people"]} 人    长期记忆 {s["facts"]} 条    最近互动 {s["events"]} 条    数据库文件 {s["db_size_mb"]} MB')
            for item in self.tree.get_children():self.tree.delete(item)
            for row in e.profiles():self.tree.insert('', 'end',values=row)
            config=e.config()
            for k,var in self.setting_vars.items():var.set(config[k])
            self.days.set(str(config['retention_days']))
            self.thought_log.delete('1.0','end')
            lines=['【小柒模拟心情、想法与行动日志（仅本机，不代表真实意识）】','']
            for stamp,mood,thought,target,action,outcome in autonomy.thinking(150):
                lines.append(f'{stamp[:19]}  [{mood}] {thought}\n  目标：{target or "无"}  行动：{action}  结果：{outcome}\n')
            self.thought_log.insert('1.0','\n'.join(lines))
            self.identity_log.delete('1.0','end')
            rows=autonomy.identities()
            self.identity_log.insert('1.0','\n'.join(f'群：{g}  发言人：{s}  私聊：{p or "尚无"}  {st}（{basis}）' for g,s,p,st,basis,ts in rows) or '暂无群聊身份线索')
            if self.current:self.show_memory()
        except Exception as ex:messagebox.showerror('读取失败',str(ex))

    def choose(self,event=None):
        selection=self.tree.selection()
        if not selection:return
        row=self.tree.item(selection[0],'values');self.current=row[0]
        self.aff.set(str(row[3]));self.show_memory()

    def show_memory(self):
        if not self.current:return
        try:
            self.who.configure(text=self.current)
            self.thought.configure(text=e.thought(self.current))
            lines=['【长期事实】']
            for cat,fact,score,ts in e.memories(self.current):lines.append(f'  [{cat}] {fact}  (权重{score}，{ts[:10]})')
            lines+=['','【最近互动摘要】']
            for role,text,ts in e.recent(self.current):lines.append(f'  {ts[:16]}  {"小柒" if role=="assistant" else "好友"}：{text}')
            self.memo.delete('1.0','end');self.memo.insert('1.0','\n'.join(lines))
        except Exception as ex:messagebox.showerror('读取记忆失败',str(ex))

    def change_affection(self):
        if not self.current:return messagebox.showinfo('提醒','请先选中好友')
        try:
            value=int(self.aff.get());e.set_affection(self.current,value);self.refresh()
        except Exception as ex:messagebox.showerror('修改失败',str(ex))

    def delete_person(self):
        if not self.current:return messagebox.showinfo('提醒','请先选中好友')
        if not messagebox.askyesno('永久删除确认','确定从情感数据库彻底删除此微信ID的全部情感资料和记忆吗？\n这个操作不可撤销。'):return
        try:e.erase(self.current);self.current='';self.memo.delete('1.0','end');self.refresh()
        except Exception as ex:messagebox.showerror('删除失败',str(ex))

    def proactive(self,enabled):
        if not self.current:return messagebox.showinfo('提醒','请先选中好友')
        if enabled and not messagebox.askyesno('主动私聊权限','只有好友已经明确同意小柒主动联系时才应该打开。\n确认已获得同意？'):return
        try:
            e.set_proactive_opt_in(self.current,enabled)
            messagebox.showinfo('已更新','该好友'+('允许主动私聊' if enabled else '已关闭主动私聊'))
            self.refresh()
        except Exception as ex:messagebox.showerror('设置失败',str(ex))

    def save_settings(self):
        try:
            changes={k:v.get() for k,v in self.setting_vars.items()}
            changes['retention_days']=int(self.days.get())
            e.save_config(changes)
            messagebox.showinfo('完成','情感系统设置已保存。')
        except Exception as ex:messagebox.showerror('保存失败',str(ex))

if __name__=='__main__':
    try:
        root=tk.Tk();Dashboard(root);root.mainloop()
    except Exception as ex:
        print('打开情感管理中心失败：',ex)
        raise
