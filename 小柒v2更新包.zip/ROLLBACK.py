# -*- coding: utf-8 -*-
from pathlib import Path
import sys,json,hashlib,shutil
from UPDATE import choose_dir,digest

def main():
    target=choose_dir()
    if target is None:return
    root=target/'xiaoqi_update_backups'
    dirs=sorted([p for p in root.glob('community_emotion_vision_*') if (p/'rollback.json').is_file()],reverse=True) if root.is_dir() else []
    if not dirs:print('没有找到本更新包的回退记录');return
    backup=dirs[0]; record=json.loads((backup/'rollback.json').read_text(encoding='utf8'))
    if Path(record['target']).resolve()!=target:raise RuntimeError('备份目标与选择目录不一致')
    for name,info in record['files'].items():
        current=target/name
        if not current.is_file() or digest(current)!=info['new_sha256']:raise RuntimeError('文件已发生其他修改，拒绝覆盖或删除: '+name)
        if info['previous'] and digest(backup/name)!=info['old_sha256']:raise RuntimeError('备份校验失败: '+name)
    print('准备恢复',backup)
    if input('确保小柒已停止；输入 ROLLBACK 确认: ').strip()!='ROLLBACK':return
    for name,info in record['files'].items():
        dst=target/name
        if info['previous']:shutil.copy2(backup/name,dst)
        else:dst.unlink()
    print('已恢复本次更新前的程序。个人配置和聊天数据库未修改。')
if __name__=='__main__':
    try:main()
    except Exception as ex:print('ERROR:',ex)
