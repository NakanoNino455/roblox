# -*- coding: utf-8 -*-
"""Offline fail-closed upgrade for a clean public v1.0.0 community installation."""
import sys,json,hashlib,shutil,datetime,os,py_compile
from pathlib import Path
HERE=Path(__file__).resolve().parent
M=json.loads((HERE/'manifest.json').read_text(encoding='utf8'))
FILES=list(M['payload_sha256'])
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def choose_dir():
    if len(sys.argv)>1: return Path(sys.argv[1]).expanduser().resolve()
    try:
        import tkinter as tk
        from tkinter import filedialog
        w=tk.Tk();w.withdraw()
        name=filedialog.askdirectory(title='选择已安装小柒 v1.0.0 的文件夹（包含 config.json）')
        w.destroy()
        return Path(name).resolve() if name else None
    except Exception as exc:
        print('目录选择窗口无法打开：',exc)
        s=input('请粘贴已安装小柒的文件夹路径（回车取消）: ').strip().strip('"')
        return Path(s).expanduser().resolve() if s else None

def main():
    if sys.version_info[:2]!=(3,11):raise RuntimeError('请使用 Python 3.11 运行更新器')
    target=choose_dir()
    if target is None:print('已取消');return 0
    print('目标目录：',target)
    if not target.is_dir():raise RuntimeError('目标安装目录不存在')
    # v1.0.0 installer copies app/* to selected root, not a nested app folder
    mainfile=target/'xiaoqi_v4_voice_choice.py'
    for requirement in ('config.json','persona.json','xiaoqi_v32.py','xiaoqi4_extra.py','xiaoqi_guardian.py','xiaoqi_autosong_v1'):
        if not (target/requirement).exists():raise RuntimeError('不是完整的已安装 v1.0.0 目录，缺少 '+requirement+'；请先运行旧安装包 INSTALL.cmd')
    if digest(mainfile) not in M['base_supported_sha256']:
        raise RuntimeError('主程序版本不是本包核对过的 v1.0.0 原版。为避免覆盖其他用户定制版，已停止。没有修改文件')
    if digest(target/'xiaoqi4_extra.py')!=M['payload_sha256']['xiaoqi4_extra.py']:
        raise RuntimeError('视觉辅助模块已被修改，拒绝覆盖；请先核对旧版文件')
    for name,expected in M['payload_sha256'].items():
        file=HERE/'payload'/name
        if not file.is_file() or digest(file)!=expected:raise RuntimeError('升级文件校验失败: '+name)
        py_compile.compile(str(file),doraise=True)
    # never overwrite a preexisting emotional add-on; user may have other patch
    for name in FILES:
        if name not in ('xiaoqi_v4_voice_choice.py','xiaoqi4_extra.py') and (target/name).exists():
            raise RuntimeError('检测到已有情感模块 '+name+'，不覆盖。此包仅供未升级的社区 v1.0.0 用户使用')
    print('预检查通过。不会覆盖微信配置、人物设定、API Key、歌曲、语音模型或现有数据库。')
    print('请先关闭小柒和守护器。建议在备份好个人数据后操作。')
    if input('确认程序已退出，输入 UPDATE 开始（否则取消）：').strip()!='UPDATE':
        print('取消。未修改文件');return 0
    backup_root=target/'xiaoqi_update_backups'
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=backup_root/('community_emotion_vision_'+stamp)
    backup.mkdir(parents=True,exist_ok=False)
    replaced=[];created=[]
    record={'target':str(target),'files':{},'release':M['release']}
    try:
        # Prepare backups before any overwrite
        for name in FILES:
            dst=target/name
            if dst.exists():
                if not dst.is_file():raise RuntimeError('目标路径不是文件: '+name)
                shutil.copy2(dst,backup/name)
                record['files'][name]={'old_sha256':digest(dst),'new_sha256':M['payload_sha256'][name],'previous':True}
            else:record['files'][name]={'old_sha256':None,'new_sha256':M['payload_sha256'][name],'previous':False}
        (backup/'rollback.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
        for name in FILES:
            dst=target/name
            if dst.exists() and digest(dst)!=record['files'][name]['old_sha256']:
                raise RuntimeError('安装期间文件已改变，停止: '+name)
            tmp=target/(name+'.new_xiaoqi_update')
            try:
                shutil.copyfile(HERE/'payload'/name,tmp)
                if digest(tmp)!=M['payload_sha256'][name]:raise RuntimeError('写入校验失败')
                os.replace(tmp,dst)
            finally:
                if tmp.exists():tmp.unlink()
            (replaced if record['files'][name]['previous'] else created).append(name)
        # Only add new, opt-in launcher files; do not automatically start/send messages
        commands={
         'OPEN_EMOTION_DASHBOARD.cmd':'@echo off\r\ncd /d "%~dp0"\r\npy -3.11 -X utf8 xiaoqi_emotion_dashboard.py\r\npause\r\n',
         'START_UPDATED_GUARDIAN.cmd':'@echo off\r\ncd /d "%~dp0"\r\nset "PYTHONPATH=%CD%;%PYTHONPATH%"\r\npy -3.11 -u xiaoqi_guardian.py\r\npause\r\n'}
        for filename,content in commands.items():
            p=target/filename
            if p.exists():continue
            p.write_bytes(content.encode('ascii'))
            created.append(filename)
            record['files'][filename]={'old_sha256':None,'new_sha256':digest(p),'previous':False}
        (backup/'rollback.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf8')
        print('\n更新完成。备份: ',backup)
        print('下次启动：双击安装目录里的 START_UPDATED_GUARDIAN.cmd')
        print('情感管理中心：OPEN_EMOTION_DASHBOARD.cmd')
        print('如果需要回退：先停止程序，再运行本更新包的 ROLLBACK.cmd 并指定安装目录。')
        print('首次启用自动发消息前，请完成权限/接收者授权检查。')
        return 0
    except Exception:
        print('更新中断：正在恢复本次已改动的文件')
        for name in reversed(replaced):shutil.copy2(backup/name,target/name)
        for name in created:
            if (target/name).exists(): (target/name).unlink()
        raise
if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:print('ERROR:',type(exc).__name__,str(exc));sys.exit(1)
