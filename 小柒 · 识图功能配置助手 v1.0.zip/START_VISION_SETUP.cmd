@echo off
setlocal
cd /d "%~dp0"
py -3.11 "vision_setup.py"
if errorlevel 1 (
  echo.
  echo Could not start the setup. Please install 64-bit Python 3.11 with tkinter and Python Launcher.
)
pause
