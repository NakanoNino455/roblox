# -*- coding: utf-8 -*-
"""Xiaoqi community vision configuration assistant (no bot source changes)."""
import base64
import importlib.util
import io
import os
import struct
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import winreg
import zlib

TITLE = '小柒 · 识图 API 配置助手'
REG_PATH = r'Environment'
KEY_NAME = 'DASHSCOPE_API_KEY'
MODEL_NAME = 'XIAOQI_VISION_MODEL'
DEFAULT_MODEL = 'qwen3-vl-plus'


def get_user_env(name):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_READ) as key:
            return winreg.QueryValueEx(key, name)[0]
    except FileNotFoundError:
        return ''


def set_user_env(name, value):
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)
    os.environ[name] = value
    try:
        import ctypes
        HWND_BROADCAST = 0xffff
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        result = ctypes.c_ulong(0)
        ctypes.windll.user32.SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, 0,
            'Environment', SMTO_ABORTIFHUNG, 1000, ctypes.byref(result))
    except Exception:
        pass


def make_red_test_png():
    # 24x24 solid red PNG, constructed without Pillow or external files.
    def chunk(name, payload):
        return struct.pack('>I', len(payload)) + name + payload + struct.pack('>I', zlib.crc32(name + payload) & 0xffffffff)
    w = h = 24
    rows = b''.join(b'\x00' + b'\xf0\x20\x20' * w for _ in range(h))
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w,h,8,2,0,0,0))
            + chunk(b'IDAT', zlib.compress(rows)) + chunk(b'IEND', b''))


class Setup:
    def __init__(self, root):
        self.root = root
        self.root.title(TITLE)
        self.root.geometry('750x590')
        self.root.minsize(690, 540)
        self.path = tk.StringVar()
        self.api_key = tk.StringVar()
        self.model = tk.StringVar(value=get_user_env(MODEL_NAME) or DEFAULT_MODEL)
        self.status = tk.StringVar(value='准备就绪。请先确认已安装小柒 v1.0.0，并更新到 v2.2。')
        main = ttk.Frame(root, padding=22)
        main.pack(fill='both', expand=True)
        ttk.Label(main, text=TITLE, font=('Microsoft YaHei UI', 17, 'bold')).pack(anchor='w')
        ttk.Label(main, text='独立配置工具：不覆盖小柒主程序、人设、好友记忆、歌曲库或语音模型。', wraplength=670).pack(anchor='w', pady=(4,16))
        group = ttk.LabelFrame(main, text='① 找到升级完成的小柒目录（只读检查）', padding=12)
        group.pack(fill='x', pady=5)
        line = ttk.Frame(group); line.pack(fill='x')
        ttk.Entry(line, textvariable=self.path).pack(side='left', fill='x', expand=True, padx=(0,7))
        ttk.Button(line, text='选择文件夹', command=self.pick).pack(side='left')
        ttk.Button(group, text='检查识图基础文件', command=self.check_files).pack(anchor='w', pady=(8,0))
        keybox = ttk.LabelFrame(main, text='② 配置自己的阿里云百炼 API Key', padding=12)
        keybox.pack(fill='x', pady=7)
        ttk.Label(keybox, text='DASHSCOPE_API_KEY（密钥不会写入更新包，也不会上传给发布者）').pack(anchor='w')
        ttk.Entry(keybox, textvariable=self.api_key, show='●').pack(fill='x', pady=6)
        ttk.Label(keybox, text='识图模型：').pack(anchor='w')
        ttk.Entry(keybox, textvariable=self.model).pack(fill='x', pady=5)
        ttk.Button(keybox, text='保存到当前 Windows 用户环境变量', command=self.save).pack(anchor='w', pady=(6,0))
        ttk.Label(keybox, text='提示：密钥会以明文保存在当前 Windows 用户的环境变量中；请保护好 Windows 账户，不要分享截图或密钥。',
                  wraplength=670, foreground='#835900').pack(anchor='w', pady=(6,0))
        check = ttk.LabelFrame(main, text='③ 检查依赖与连接（自愿联网测试）', padding=12)
        check.pack(fill='x', pady=8)
        buttons = ttk.Frame(check);buttons.pack(fill='x')
        ttk.Button(buttons, text='检查 openai SDK', command=self.check_sdk).pack(side='left', padx=(0,8))
        ttk.Button(buttons, text='安装/更新 openai SDK', command=self.install_sdk).pack(side='left', padx=(0,8))
        ttk.Button(buttons, text='测试百炼识图 API', command=self.test_api).pack(side='left')
        ttk.Label(check, text='点击测试将把程序内置的小红色测试图片发送至阿里云百炼，可能产生少量 API 费用；不会上传微信聊天图片。', wraplength=670).pack(anchor='w', pady=(9,0))
        ttk.Label(main, text='④ 保存完成后：退出小柒及守护器，重新打开 CMD/启动器再启动小柒。必要时注销重新登录 Windows。', wraplength=680).pack(anchor='w', pady=(6,10))
        ttk.Label(main, textvariable=self.status, foreground='#17632a', wraplength=675).pack(anchor='w', pady=(3,0))
        self.log = tk.Text(main, height=6, wrap='word', font=('Consolas',10))
        self.log.pack(fill='both', expand=True, pady=(5,0))
        self.say('工具不会自行安装依赖、发起网络请求或修改程序；所有这些操作都需要用户点击对应按钮。')
        if get_user_env(KEY_NAME):
            self.say('检测到当前 Windows 用户已设置 DASHSCOPE_API_KEY（已隐藏具体内容）。')

    def say(self, msg):
        self.log.insert('end', msg + '\n'); self.log.see('end')

    def progress(self, msg):
        self.root.after(0, lambda: (self.status.set(msg), self.say(msg)))

    def pick(self):
        path = filedialog.askdirectory(title='选择 v2.2 小柒安装目录')
        if path: self.path.set(path)

    def check_files(self):
        path = self.path.get().strip()
        if not path or not os.path.isdir(path):
            messagebox.showwarning(TITLE, '请先选择已经安装的小柒目录。'); return
        main = os.path.join(path, 'xiaoqi_v4_voice_choice.py')
        extra = os.path.join(path, 'xiaoqi4_extra.py')
        if os.path.isfile(main) and os.path.isfile(extra):
            self.progress('识图基础文件存在；这不等于已经测试通过识图。')
        else:
            self.progress('目录不完整：' + ('缺少主程序；' if not os.path.isfile(main) else '') + ('缺少 xiaoqi4_extra.py。' if not os.path.isfile(extra) else ''))
            messagebox.showwarning(TITLE, '请选择完成 v2.2 更新后、直接包含主程序的目录。')

    def save(self):
        key = self.api_key.get().strip()
        model = self.model.get().strip() or DEFAULT_MODEL
        if not key:
            messagebox.showwarning(TITLE, '请输入自己的 API Key。不会读取或显示现有密钥。');return
        if len(key) < 12 or any(c.isspace() for c in key):
            messagebox.showwarning(TITLE, 'Key 格式可能不正确：请检查是否多复制了空格或换行。');return
        if not model or any(c.isspace() for c in model):
            messagebox.showwarning(TITLE, '模型名称不能包含空格。');return
        try:
            set_user_env(KEY_NAME, key)
            set_user_env(MODEL_NAME, model)
            self.api_key.set('')
            self.progress('配置已保存到当前 Windows 用户环境变量。密钥输入框已清空；重启小柒及其守护器后生效。')
            messagebox.showinfo(TITLE, '保存成功！\n\n请关闭并重新启动小柒与守护器，然后测试图片识别。')
        except Exception as e:
            self.progress('保存失败：' + type(e).__name__ + '（请检查当前 Windows 账号的注册表权限）')

    def check_sdk(self):
        try:
            from openai import OpenAI
            self.progress('当前 Python 的 openai SDK 已安装。解释器：' + sys.executable)
        except ImportError:
            self.progress('当前 Python 缺少 openai SDK。请点击「安装/更新 openai SDK」。解释器：' + sys.executable)

    def install_sdk(self):
        if not messagebox.askyesno(TITLE, '需要联网，且将在当前 Python 3.11 环境中执行 pip install --upgrade openai。\n\n确认继续？'):
            return
        self.progress('正在安装依赖，请等待；可能需要访问 pypi.org。')
        def work():
            try:
                p = subprocess.run([sys.executable,'-m','pip','install','--upgrade','openai'], capture_output=True,text=True,timeout=180,errors='replace')
                if p.returncode == 0:
                    self.progress('openai SDK 安装成功。')
                else:
                    self.progress('安装失败，返回码 '+str(p.returncode)+'；请检查网络及 pip。\n' + (p.stderr or '')[-900:])
            except Exception as e:
                self.progress('安装过程失败：'+type(e).__name__+': '+str(e)[:200])
        threading.Thread(target=work, daemon=True).start()

    def test_api(self):
        key = get_user_env(KEY_NAME) or os.environ.get(KEY_NAME,'')
        if not key:
            messagebox.showwarning(TITLE, '还未检测到保存的 DASHSCOPE_API_KEY。请先保存。');return
        if not messagebox.askyesno(TITLE, '将向阿里云百炼发送一张程序生成的红色测试图片；可能产生少量模型调用费用。\n\n确认开始？'):
            return
        self.progress('正在请求阿里云百炼视觉接口（通常需要几秒）。')
        def work():
            try:
                from openai import OpenAI
                image_uri = 'data:image/png;base64,' + base64.b64encode(make_red_test_png()).decode('ascii')
                cli = OpenAI(api_key=key,base_url='https://dashscope.aliyuncs.com/compatible-mode/v1',timeout=30,max_retries=0)
                r=cli.chat.completions.create(model=get_user_env(MODEL_NAME) or DEFAULT_MODEL,
                    messages=[{'role':'user','content':[{'type':'text','text':'请用一个中文颜色词描述这张测试图片的主要颜色。'},
                    {'type':'image_url','image_url':{'url':image_uri}}]}],max_tokens=60)
                answer=str(r.choices[0].message.content or '').strip()
                self.progress('视觉 API 响应成功。模型回答：'+ answer[:120] + '。现在请重启小柒，再做微信图片测试。')
            except ImportError:
                self.progress('缺少 openai SDK：请先点击安装依赖。')
            except Exception as e:
                # Never log raw API response content or key; some SDK errors may contain request context.
                err_type=type(e).__name__
                code=getattr(e,'status_code',None)
                self.progress('视觉 API 测试未通过：'+err_type+(f'（HTTP {code}）' if code else '')+'。检查 API Key、模型权限、配额和网络。')
        threading.Thread(target=work, daemon=True).start()

if __name__ == '__main__':
    if sys.platform != 'win32':
        print('This configuration tool must be run on Windows.');sys.exit(1)
    root=tk.Tk()
    try: ttk.Style().theme_use('vista')
    except tk.TclError: pass
    Setup(root)
    root.mainloop()
