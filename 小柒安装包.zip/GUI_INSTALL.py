# -*- coding: utf-8 -*-
"""Xiaoqi 1.0.1 graphical onboarding. Does not silently enable messaging."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import subprocess,sys,shutil,importlib.util,json,threading,queue
ROOT=Path(__file__).resolve().parent
SOURCE=(ROOT/'app'/'xiaoqi_guardian.py').exists()
DEFAULT=Path.home()/'Documents'/'Xiaoqi Community'
class UI:
 def __init__(self):
  self.win=tk.Tk();self.win.title('小柒 Xiaoqi · 新手引导 v1.0.1');self.win.geometry('850x665');self.win.minsize(720,590)
  self.q=queue.Queue();self.busy=False
  root=ttk.Frame(self.win,padding=20);root.pack(fill='both',expand=True)
  ttk.Label(root,text='小柒 Xiaoqi · 一站式安装与配置',font=('Microsoft YaHei UI',19,'bold')).pack(anchor='w')
  ttk.Label(root,text='作者：同一意   |   新用户引导 v1.0.1   |   默认不自动发送微信消息').pack(anchor='w',pady=(4,12))
  self.status=tk.StringVar(value='从上到下操作即可，无须手动输入 CMD 命令。')
  ttk.Label(root,textvariable=self.status,foreground='#21618c',wraplength=770).pack(anchor='w',pady=7)
  self.folder=tk.StringVar(value=str(DEFAULT))
  if SOURCE:
   ttk.Label(root,text='① 安装到独立文件夹（不会覆盖旧版）',font=('Microsoft YaHei UI',11,'bold')).pack(anchor='w',pady=(9,5))
   row=ttk.Frame(root);row.pack(fill='x');ttk.Entry(row,textvariable=self.folder).pack(side='left',fill='x',expand=True)
   ttk.Button(row,text='选择位置',command=self.pick).pack(side='left',padx=6)
   ttk.Button(row,text='安装并继续',command=self.install).pack(side='left')
  else:
   ttk.Label(root,text='① 已进入独立安装目录：'+str(ROOT),wraplength=790).pack(anchor='w',pady=10)
  ttk.Separator(root).pack(fill='x',pady=13)
  ttk.Label(root,text='② 配置与检查（按顺序点击）',font=('Microsoft YaHei UI',11,'bold')).pack(anchor='w')
  buttons=ttk.Frame(root);buttons.pack(fill='x',pady=9)
  ttk.Button(buttons,text='1. 填写微信账号',command=lambda:self.run_gui('configure_local.py')).pack(side='left',padx=3)
  ttk.Button(buttons,text='2. 检查环境',command=self.check).pack(side='left',padx=3)
  ttk.Button(buttons,text='3. 安装基础 SDK',command=self.install_sdk).pack(side='left',padx=3)
  ttk.Button(buttons,text='4. 功能配置',command=lambda:self.run_gui('FEATURE_SETUP.py')).pack(side='left',padx=3)
  ttk.Button(buttons,text='5. 全功能检查',command=lambda:self.run_task('FULL_CHECK.py')).pack(side='left',padx=3)
  ttk.Separator(root).pack(fill='x',pady=12)
  ttk.Label(root,text='③ 启动前确认',font=('Microsoft YaHei UI',11,'bold')).pack(anchor='w')
  ttk.Label(root,text='首次使用建议只检查和演示。真实微信发送需兼容的 wechatauto，且必须由本人确认启动。',wraplength=780).pack(anchor='w',pady=5)
  ttk.Button(root,text='需要时手动启动小柒（保留安全确认）',command=self.launch).pack(anchor='w',pady=4)
  ttk.Label(root,text='安装日志 / 环境检测结果',font=('Microsoft YaHei UI',10,'bold')).pack(anchor='w',pady=(12,5))
  frame=ttk.Frame(root);frame.pack(fill='both',expand=True)
  self.log=tk.Text(frame,height=12,wrap='word',font=('Consolas',9));self.log.pack(side='left',fill='both',expand=True)
  sc=ttk.Scrollbar(frame,command=self.log.yview);sc.pack(side='right',fill='y');self.log.configure(yscrollcommand=sc.set)
  ttk.Label(root,text='注意：本包不包含 wechatauto 安装源、语音模型权重或曲库；不会假装这些组件已安装。',foreground='#8a4b12',wraplength=780).pack(anchor='w',pady=7)
  self.win.after(120,self.poll)
 def pick(self):
  x=filedialog.askdirectory(title='选择空文件夹');
  if x:self.folder.set(x)
 def write(self,s):self.log.insert('end',str(s)+'\n');self.log.see('end')
 def install(self):
  target=Path(self.folder.get()).expanduser().resolve();src=ROOT.resolve()
  if target==src or src in target.parents or target in src.parents:messagebox.showerror('位置错误','请选择与安装包互不包含的独立文件夹');return
  if target.exists() and any(target.iterdir()):messagebox.showerror('保护已有文件','目标文件夹必须为空；不会覆盖旧版小柒');return
  try:
   target.mkdir(parents=True,exist_ok=True)
   for item in (ROOT/'app').iterdir():
    if item.name=='__pycache__':continue
    if item.is_dir():shutil.copytree(item,target/item.name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    else:shutil.copy2(item,target/item.name)
   shutil.copytree(ROOT/'docs',target/'docs')
   for f in ROOT.iterdir():
    if f.is_file() and f.name not in ('setup_wizard.py',) and f.suffix.lower() in ('.cmd','.py','.json','.txt','.md','.html','.bat'):
     if f.name.startswith('【') or f.name in ('README.md','AUTHOR.md','VERSION.json','requirements-basic.txt','config.example.json','persona.example.json','settings-safe.example.json','CHANGELOG.md') or f.name.endswith('.cmd') or f.name in ('environment_check.py','configure_local.py','FEATURE_SETUP.py','SETUP_COMPONENTS.py','FULL_CHECK.py','xiaoqi_launcher.py','GUI_INSTALL.py','使用说明_从这里开始.txt'):
      shutil.copy2(f,target/f.name)
   for example,actual in (('config.example.json','config.json'),('persona.example.json','persona.json'),('settings-safe.example.json','xiaoqi_final_settings.json')):shutil.copy2(ROOT/example,target/actual)
   (target/'INSTALL_COMPLETE.txt').write_text('已复制程序；并不代表微信或语音依赖已经安装。自动发送默认关闭。\n',encoding='utf-8')
   self.write('程序文件已复制到 '+str(target));self.status.set('已复制完成，正在打开安装目录的引导窗口。')
   subprocess.Popen([sys.executable,str(target/'GUI_INSTALL.py')],cwd=target)
   self.win.destroy()
  except Exception as e:messagebox.showerror('安装未完成',str(e));self.write('安装失败：'+str(e))
 def run_gui(self,script):
  if SOURCE:messagebox.showinfo('先安装','请先点击「安装并继续」，在安装目录继续配置。');return
  try:subprocess.Popen([sys.executable,str(ROOT/script)],cwd=ROOT);self.write('已打开：'+script)
  except Exception as e:messagebox.showerror('无法打开',str(e))
 def worker(self,args):
  def job():
   try:
    p=subprocess.Popen(args,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    for line in p.stdout:self.q.put(line.rstrip())
    rc=p.wait();self.q.put('结束，退出码 '+str(rc)+('（有失败项，请查看上面的内容）' if rc else ''))
   except Exception as e:self.q.put('执行失败：'+str(e))
   self.q.put(None)
  if self.busy:messagebox.showinfo('请稍候','已有任务正在执行');return
  self.busy=True;threading.Thread(target=job,daemon=True).start()
 def poll(self):
  try:
   while True:
    msg=self.q.get_nowait()
    if msg is None:self.busy=False
    else:self.write(msg)
  except queue.Empty:pass
  self.win.after(120,self.poll)
 def run_task(self,script):
  if SOURCE:messagebox.showinfo('先安装','请先安装到独立目录');return
  self.worker([sys.executable,'-X','utf8',str(ROOT/script)])
 def check(self):
  if SOURCE:messagebox.showinfo('先安装','请先安装到独立目录');return
  self.write('基础环境检测（只检查，不发送微信消息）：')
  self.worker([sys.executable,'-X','utf8',str(ROOT/'environment_check.py')])
 def install_sdk(self):
  if SOURCE:messagebox.showinfo('先安装','请先安装到独立目录');return
  if not messagebox.askyesno('确认联网安装','将联网安装 requirements-basic.txt 中的 openai SDK。\n不会安装 wechatauto、不会启动微信。继续？'):return
  self.worker([sys.executable,'-m','pip','install','-r',str(ROOT/'requirements-basic.txt')])
 def launch(self):
  if SOURCE:messagebox.showinfo('先安装','请先安装到独立目录');return
  if not messagebox.askyesno('运行确认','将打开启动脚本，仍需完成环境检查及授权。确认继续？'):return
  try:subprocess.Popen(['cmd','/c',str(ROOT/'START_WITH_CONFIRMATION.cmd')],cwd=ROOT,creationflags=getattr(subprocess,'CREATE_NEW_CONSOLE',0))
  except Exception as e:messagebox.showerror('启动失败',str(e))
 def mainloop(self):self.win.mainloop()
if __name__=='__main__':UI().mainloop()
