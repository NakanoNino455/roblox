@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3.11 -X utf8 "%~dp0FEATURE_SETUP.py"
if errorlevel 1 echo Setup did not complete.
pause
