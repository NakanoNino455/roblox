# -*- coding: utf-8 -*-
"""Inject this installation's optional voice/song paths and launch unchanged guardian.
Does not run without explicit authorization in START_WITH_CONFIRMATION.cmd.
"""
from pathlib import Path
import sys, os, json, subprocess
HERE=Path(__file__).resolve().parent
APP=HERE
if not (APP/'xiaoqi_guardian.py').is_file():
    APP=HERE/'app' # when run from source folder before install
cfg=APP/'private'/'runtime_paths.json'
if cfg.is_file():
    try: data=json.loads(cfg.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError): data={}
    keys={'cosy_root':'XIAOQI_COSY_ROOT','cosy_python':'XIAOQI_COSY_PYTHON','cosy_model':'XIAOQI_COSY_MODEL','reference_wav':'XIAOQI_REFERENCE_WAV'}
    for k,v in keys.items():
        if isinstance(data.get(k),str) and data[k].strip():os.environ[v]=data[k]
# Keep the local permission prompts in existing guardian (do not auto-approve).
raise SystemExit(subprocess.call([sys.executable,'-u',str(APP/'xiaoqi_guardian.py')],cwd=str(APP)))
