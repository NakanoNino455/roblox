# -*- coding: utf-8 -*-
"""Feature configuration + explicit-on-click installation. No implicit background install."""
import os,json,subprocess,sys,threading,queue,webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox
ROOT=Path(__file__).resolve().parent
APP=ROOT if (ROOT/'xiaoqi_v4_voice_choice.py').is_file() else ROOT/'app'
PRIVATE=APP/'private';PRIVATE.mkdir(exist_ok=True)
SETTINGS=PRIVATE/'runtime_paths.json'
SONGCFG=APP/'xiaoqi_autosong_v1'/'autosong.json'
ENVROOT=ROOT/'.xiaoqi_base_env'
REPO_URLS={
 'cosy':'https://github.com/FunAudioLLM/CosyVoice',
 'seed':'https://github.com/Plachtaa/seed-vc',
 'model':'https://modelscope.cn/models/iic/CosyVoice2-0.5B',
 'python':'https://www.python.org/downloads/',
 'vbcable':'https://vb-audio.com/Cable/',
 'ffmpeg':'https://ffmpeg.org/download.html',
}
def load(path):
    try:return json.loads(path.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):return {}
def save(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,path)
def exe_path(folder):return str(folder/'Scripts'/'python.exe')
class GUI(tk.Tk):
 def __init__(self):
    super().__init__();self.title('小柒完整版 · 功能与模型安装 | 作者：同一意');self.geometry('940x760');self.minsize(800,650)
    self.q=queue.Queue();self.busy=False
    d=load(SETTINGS); cosy=APP/'third_party'/'CosyVoice'
    defaults={
      'cosy_root':str(cosy),
      'cosy_python':exe_path(APP/'cosyvoice_env'),
      'cosy_model':str(APP/'CosyVoice2-0.5B'),
      'reference_wav':str(PRIVATE/'reference.wav'),
      'seed_root':str(APP/'xiaoqi_singing'/'third_party'/'seed-vc'),
      'seed_python':exe_path(APP/'xiaoqi_seedvc_env'),
      'song_studio':str(APP/'xiaoqi_singing'/'xiaoqi_songstudio')}
    self.vars={k:tk.StringVar(value=d.get(k,v)) for k,v in defaults.items()}
    container=ttk.Frame(self,padding=18);container.pack(fill='both',expand=True)
    ttk.Label(container,text='🐳 小柒 · 全功能安装与配置',font=('Microsoft YaHei UI',19,'bold')).pack(anchor='w')
    ttk.Label(container,text='作者：同一意  |  独立部署 • 原项目不覆盖  |  必须使用自己的微信和授权音频').pack(anchor='w',pady=(4,12))
    tabs=ttk.Notebook(container);tabs.pack(fill='both',expand=True)
    config=ttk.Frame(tabs,padding=14);install=ttk.Frame(tabs,padding=14);tabs.add(config,text='1. 配置模型路径');tabs.add(install,text='2. 安装缺失环境')
    for key,title in [('cosy_root','CosyVoice 源码目录'),('cosy_python','CosyVoice Python 环境'),('cosy_model','CosyVoice2 模型目录'),('reference_wav','你的参考音色 WAV'),('seed_root','Seed-VC 源码目录'),('seed_python','Seed-VC Python 环境'),('song_studio','歌曲转换工作台')]:
      row=ttk.Frame(config);row.pack(fill='x',pady=6)
      ttk.Label(row,text=title,width=24).pack(side='left');ttk.Entry(row,textvariable=self.vars[key]).pack(side='left',fill='x',expand=True)
      def browse(k=key):
        p=filedialog.askopenfilename(title='选择文件') if k.endswith('python') or k=='reference_wav' else filedialog.askdirectory(title='选择文件夹')
        if p:self.vars[k].set(p)
      ttk.Button(row,text='浏览…',command=browse).pack(side='left',padx=6)
    ttk.Button(config,text='保存路径并写入离线音乐库配置',command=self.save_settings).pack(anchor='w',pady=10)
    ttk.Label(config,text='提示：只需要设置自己的参考音频，安装包不包括作者的音色或他人的商业歌曲。\n保存后必须运行全功能检查，状态显示就绪才表示该功能已准备好。',wraplength=780).pack(anchor='w',pady=5)
    ttk.Label(install,text='下面各步骤需要联网且可能下载几个 GB。只在点击时执行，失败会保留日志。\nCosyVoice 官方推荐 Python 3.10/Conda；安装脚本尽力准备独立环境，具体系统可能还需补齐官方依赖。',wraplength=800).pack(anchor='w',pady=6)
    for label,action in [('准备基础聊天依赖（Python 3.11 + wechatauto）','base'),('下载和安装 CosyVoice2（包含官方模型）','voice'),('下载和安装 Seed-VC 唱歌环境','singing')]:
      ttk.Button(install,text=label,command=lambda a=action:self.start_install(a)).pack(fill='x',pady=4)
    for label,key in [('查看 CosyVoice 官方项目','cosy'),('查看 Seed-VC 官方项目与 GPL 许可证','seed'),('查看 CosyVoice2 官方模型','model'),('查看微信语音虚拟音频设备','vbcable'),('查看 FFmpeg 官方下载','ffmpeg')]:
      ttk.Button(install,text=label,command=lambda k=key:webbrowser.open(REPO_URLS[k])).pack(anchor='w',pady=2)
    status=ttk.Frame(container);status.pack(fill='x',pady=8)
    ttk.Button(status,text='重新检查全部功能',command=self.do_check).pack(side='left')
    ttk.Button(status,text='打开私人配置文件夹',command=lambda:os.startfile(str(PRIVATE))).pack(side='left',padx=9)
    self.text=tk.Text(container,height=13,wrap='word');self.text.pack(fill='both',expand=False)
    self.after(150,self.poll);self.do_check()
 def emit(self,msg):self.text.insert('end',str(msg)+'\n');self.text.see('end')
 def save_settings(self):
    d={k:v.get().strip() for k,v in self.vars.items()};save(SETTINGS,d)
    cfg=load(SONGCFG);cfg.update({'project':str(APP),'studio':d['song_studio'],'reference':d['reference_wav'],
       'controller_python':d['seed_python'],'sender_cwd':str(APP),'auto_fetch':False})
    cfg.setdefault('wechat_enabled',False)
    save(SONGCFG,cfg)
    messagebox.showinfo('已保存','已更新本机设置；未修改机器人原始逻辑，也没有自动发送消息。')
    self.do_check()
 def do_check(self):
    self.text.delete('1.0','end');self.emit('==== 全功能就绪检查 ===')
    ok=lambda p:Path(self.vars[p].get()).is_file() if p.endswith('python') or p=='reference_wav' else Path(self.vars[p].get()).is_dir()
    for key,name in [('cosy_root','CosyVoice 源码'),('cosy_python','CosyVoice Python'),('cosy_model','CosyVoice2 模型'),('reference_wav','参考音色'),('seed_root','Seed-VC 源码'),('seed_python','Seed-VC Python'),('song_studio','歌曲工作台')]:self.emit(('✅ ' if ok(key) else '❌ ')+name)
    self.emit('提示：路径存在不代表模型推理正常；需要分别试听和点歌测试。')
 def start_install(self,kind):
    if self.busy:return
    item={'base':'聊天依赖','voice':'CosyVoice2（大型模型）','singing':'Seed-VC（大型依赖）'}[kind]
    if not messagebox.askyesno('联网下载授权','确定下载并安装【'+item+'】？\n可能需要几 GB 空间和较长时间。\n只会在本副本内创建环境，不覆盖已有小柒。'):return
    self.save_settings();self.busy=True;self.emit('开始安装 '+item)
    def worker():
      proc=subprocess.Popen([sys.executable,'-X','utf8',str(ROOT/'SETUP_COMPONENTS.py'),'--component',kind],cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
      for line in proc.stdout:self.q.put(line.rstrip())
      self.q.put('安装结束，返回码 '+str(proc.wait()));self.q.put(None)
    threading.Thread(target=worker,daemon=True).start()
 def poll(self):
    try:
      while True:
        x=self.q.get_nowait()
        if x is None:
          self.busy=False
          self.emit('请查看上方安装结果；如失败，打开 logs/setup_latest.log。然后点击重新检查全部功能。')
        else:self.emit(x)
    except queue.Empty:pass
    self.after(150,self.poll)
if __name__=='__main__':GUI().mainloop()
