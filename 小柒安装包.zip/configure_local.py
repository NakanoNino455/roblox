# -*- coding: utf-8 -*-
"""Local GUI editor for new user's account. No sending, no network, no secrets stored."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
import json,os
ROOT=Path(__file__).resolve().parent
CFG=ROOT/'config.json'
PERSONA=ROOT/'persona.json'

def load():
    try:return json.loads(CFG.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):return {}

def main():
    w=tk.Tk();w.title('小柒 · 新用户配置 — 作者：同一意');w.geometry('760x460');w.minsize(650,410)
    f=ttk.Frame(w,padding=22);f.pack(fill='both',expand=True)
    ttk.Label(f,text='🐳 小柒账号配置',font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w')
    ttk.Label(f,text='Created by 同一意 · 这些信息只保存在本机，不会发送给作者。').pack(anchor='w',pady=(5,15))
    fields=[('微信数据库账号标识 db_account','db_account'),('小柒账号 wxid','approved_account_wxid'),('主人账号 wxid','owner_wxid'),('主人显示称呼（可选）','owner_display_name')]
    c=load();inputs={}
    for label,key in fields:
        bar=ttk.Frame(f);bar.pack(fill='x',pady=6)
        ttk.Label(bar,text=label,width=31).pack(side='left')
        var=tk.StringVar(value=c.get(key,'') if not str(c.get(key,'')).startswith('请填写') else '')
        ttk.Entry(bar,textvariable=var).pack(side='left',fill='x',expand=True)
        inputs[key]=var
    text=('请在兼容的 wechatauto 文档中确认每个字段含义。\n'
          '所有自动发送保持关闭，不会在此界面启动微信。\n'
          'DeepSeek API Key 请在自己的运行环境中配置，不要写进公开仓库。\n'
          '注：现有代码要求小柒测试账号的微信昵称为“小柒”。')
    ttk.Label(f,text=text,justify='left',wraplength=670).pack(anchor='w',pady=(12,12))
    def save():
        result={k:v.get().strip() for k,v in inputs.items()}
        if not all(result[k] for k in ('db_account','approved_account_wxid','owner_wxid')):
            if not messagebox.askyesno('还没填完整','账号字段未填完整，将保持不可安全启动状态。仍要保存吗？'):return
        out={**c,**result,'reply_enabled':False,'morning_enabled':False}
        temp=CFG.with_suffix('.tmp');temp.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(temp,CFG)
        messagebox.showinfo('保存成功','已写入本地 config.json。\n下一步：运行 CHECK_ENV.cmd，然后 RUN_DEMO.cmd。')
    row=ttk.Frame(f);row.pack(fill='x',pady=7)
    ttk.Button(row,text='保存到本机',command=save).pack(side='left')
    ttk.Button(row,text='退出',command=w.destroy).pack(side='right')
    ttk.Label(f,text='Xiaoqi · © 同一意 · GitHub @2068969346-maker').pack(anchor='e',side='bottom')
    w.mainloop()

if __name__=='__main__':main()
