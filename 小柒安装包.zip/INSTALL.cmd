@echo off
cd /d "%~dp0"
call "%~dp0双击我_开始安装.cmd"
