# -*- coding: utf-8 -*-
"""小柒：非阻塞音频合成 + 主线程串行发送。默认关闭；仅单进程内存队列。"""
import os
import sys
import time
import tempfile
import subprocess
import threading
from pathlib import Path
from collections import deque
from concurrent.futures import ThreadPoolExecutor

PROJECT=Path(__file__).resolve().parent
COSY_ROOT=Path(os.environ.get('XIAOQI_COSY_ROOT', str(PROJECT/'third_party'/'CosyVoice')))
COSY_PYTHON=Path(os.environ.get('XIAOQI_COSY_PYTHON', str(PROJECT/'cosyvoice_env'/'Scripts'/'python.exe')))
STOP=PROJECT/'STOP_XIAOQI'
_LOCK=threading.Lock()
_POOL=ThreadPoolExecutor(max_workers=1, thread_name_prefix='xiaoqi_voice_tts')
_PENDING=deque()
_KNOWN=set()
_LAST_BY_TARGET={}
_LAST_GLOBAL=0.0
_MAX_PENDING=3

def _enabled(kind,target):
    if os.environ.get('XIAOQI_VOICE_ENABLE')!='1': return False
    if kind not in ('group','private'): return False
    if kind=='group' and os.environ.get('XIAOQI_VOICE_SCOPE','private')!='all': return False
    allowed={x.strip() for x in os.environ.get('XIAOQI_VOICE_TARGETS','').split('|') if x.strip()}
    return bool(allowed and ('*' in allowed or target in allowed))

def _mood(text):
    """Lightweight emotion selection without changing the voice reference."""
    text=str(text)
    if any(t in text for t in ('抱抱','别难过','没关系','辛苦了','对不起','晚安','难受','安慰')):
        return 'gentle'
    if any(t in text for t in ('太棒','哈哈','开心','恭喜','耶','好耶','！','!')):
        return 'happy'
    if any(t in text for t in ('请注意','首先','步骤','建议','原因','注意事项','风险')):
        return 'calm'
    return 'playful'

def _generate(text,out):
    subprocess.run([str(COSY_PYTHON),str(PROJECT/'xiaoqi_voice_generate_v3.py'),
                   '--text',text,'--out',str(out),
                   '--mode','emotion','--style',_mood(text),'--speed','1.0'], cwd=str(COSY_ROOT),
                   check=True,timeout=150,stdout=subprocess.DEVNULL)
    return out

def enqueue_voice(job_id,target,text,kind='private'):
    """Fire-and-forget voice generation after confirmed text delivery. No GUI call here."""
    if STOP.exists() or not _enabled(kind,target): return False
    text=str(text or '').strip()
    if not text or len(text)>160 or not COSY_PYTHON.is_file(): return False
    key=str(job_id)
    with _LOCK:
        if key in _KNOWN or len(_PENDING)>=_MAX_PENDING: return False
        _KNOWN.add(key)
        folder=Path(tempfile.mkdtemp(prefix='xiaoqi_voice_task_'))
        wav=folder/'voice.wav'
        fut=_POOL.submit(_generate,text,wav)
        _PENDING.append((key,target,kind,time.monotonic(),folder,fut))
    print('语音合成任务已排队（尚未发送）：',key,repr(target),flush=True)
    return True

def pending_count():
    with _LOCK:
        return len(_PENDING)

def _cleanup(folder):
    try:
        for p in folder.iterdir():
            if p.is_file(): p.unlink(missing_ok=True)
        folder.rmdir()
    except OSError: pass

def dispatch_one_ready():
    """Call only in main GUI loop, never from a background worker."""
    global _LAST_GLOBAL
    if STOP.exists() or os.environ.get('XIAOQI_VOICE_ENABLE')!='1': return False
    with _LOCK:
        if not _PENDING: return False
        item=_PENDING[0]
        key,target,kind,created,folder,fut=item
        if not fut.done(): return False
        _PENDING.popleft()
    try:
        wav=fut.result()
        if time.monotonic()-created>180:
            print('语音任务过期，跳过',key,flush=True);return False
        if not _enabled(kind,target) or STOP.exists():return False
        now=time.monotonic()
        # Global 1 voice / 60s, per chat 1 voice / 10min; drop, never retry or backfill.
        if now-_LAST_GLOBAL<60 or now-_LAST_BY_TARGET.get((kind,target),-1e9)<600:
            print('语音冷却中，丢弃任务',key,flush=True);return False
        # Sender demands exact foreground UIA name and refuses to switch chats.
        # At most one interactive GUI operation at once (this is called on main loop).
        # No scripted 5s focus switch: keep existing sender's verified foreground check.
        cmd=[sys.executable,str(PROJECT/'xiaoqi_voice_sender_auto_v2.py'),
             '--target',target,'--wav',str(wav),'--send','--open-target','--no-wait']
        _LAST_GLOBAL=now
        _LAST_BY_TARGET[(kind,target)]=now
        result=subprocess.run(cmd,cwd=str(COSY_ROOT),timeout=95,check=False)
        if result.returncode:
            print('语音未确认成功；不自动重试',key,flush=True)
            return False
        print('语音发送动作执行完毕（客户端交付需人工核对）',key,flush=True)
        return True
    except Exception as exc:
        print('语音已跳过；不重试',key,type(exc).__name__,str(exc)[:120],flush=True)
        return False
    finally:
        _cleanup(folder)


def voice_ready(target, kind='private'):
    """Non-mutating eligibility check for the exclusive voice route."""
    if STOP.exists() or not _enabled(kind,target): return False
    if not COSY_PYTHON.is_file() or not (PROJECT/'xiaoqi_voice_sender_auto_v2.py').is_file(): return False
    now=time.monotonic()
    if now-_LAST_GLOBAL < 60 or now-_LAST_BY_TARGET.get((kind,target),-1e9)<600: return False
    return True

def send_voice_only(job_id,target,text,kind='private'):
    """Blocking GUI-thread delivery. No text sent here, no retry on uncertainty."""
    global _LAST_GLOBAL
    if not voice_ready(target,kind): raise RuntimeError('语音开关/授权/冷却未允许发送')
    text=str(text or '').strip()
    if not text or len(text)>160: raise RuntimeError('语音文字长度超出限制')
    folder=Path(tempfile.mkdtemp(prefix='xiaoqi_voice_exclusive_'))
    try:
        wav=_generate(text,folder/'voice.wav')
        if STOP.exists() or not _enabled(kind,target): raise RuntimeError('语音合成期间授权已改变')
        if not voice_ready(target,kind): raise RuntimeError('语音合成后冷却/发送条件不满足')
        now=time.monotonic()
        _LAST_GLOBAL=now
        _LAST_BY_TARGET[(kind,target)]=now
        cmd=[sys.executable,str(PROJECT/'xiaoqi_voice_sender_auto_v2.py'),
             '--target',target,'--wav',str(wav),'--send','--open-target','--no-wait']
        r=subprocess.run(cmd,cwd=str(COSY_ROOT),timeout=95,check=False)
        if r.returncode: raise RuntimeError('微信语音发送器未确认成功，禁止重发')
        print('语音专属回复：发送器执行成功，实际送达需人工核对',job_id,repr(target),flush=True)
        return True
    finally:
        _cleanup(folder)
