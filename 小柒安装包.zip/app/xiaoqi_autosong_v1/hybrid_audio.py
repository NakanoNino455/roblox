"""PCM timeline assembly; only standard library, no downloads or separation."""
import audioop,hashlib,json,os,uuid,wave
from array import array
from pathlib import Path
BASE=Path(__file__).resolve().parent

def read_pcm(path,rate):
 with wave.open(str(path),'rb') as w:
  data=w.readframes(w.getnframes());width=w.getsampwidth();channels=w.getnchannels();source_rate=w.getframerate()
 if channels==2:data=audioop.tomono(data,width,.5,.5)
 elif channels!=1:raise ValueError('只支持单声道或双声道 WAV')
 if width==1:data=audioop.bias(data,1,-128)
 data=audioop.lin2lin(data,width,2)
 if source_rate!=rate:data,_=audioop.ratecv(data,2,1,source_rate,rate,None)
 return data

def save_pcm(path,data,rate):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
 with wave.open(str(tmp),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(rate);w.writeframes(data)
 os.replace(tmp,path)

def load_plan(sid,source=None):
 path=BASE/'plans'/sid/'plan.json'
 if not path.is_file():return None
 plan=json.loads(path.read_text(encoding='utf-8'))
 if source is not None and hashlib.sha256(Path(source).read_bytes()).hexdigest()!=plan['source_sha256']:return None
 plan['_folder']=str(path.parent);return plan

def blend_gap(target,gap,a,b,rate):
 """Crossfade inside a conservative quiet interval; leave vocal regions intact."""
 length=b-a
 if len(gap)//2!=length:raise ValueError('原曲间奏音频长度与时间轴不一致')
 before=array('h');before.frombytes(bytes(target[a*2:b*2]));replacement=array('h');replacement.frombytes(gap)
 fade=min(round(.08*rate),length//2)
 # First/last song boundaries have no transition to another segment.
 for j in range(fade):
  if a>0:
   alpha=(j+1)/fade;replacement[j]=round(before[j]*(1-alpha)+replacement[j]*alpha)
  if b<len(target)//2:
   alpha=(j+1)/fade;k=length-1-j;replacement[k]=round(before[k]*(1-alpha)+replacement[k]*alpha)
 target[a*2:b*2]=replacement.tobytes()

def finish_full(path,sid,source=None):
 plan=load_plan(sid,source)
 if not plan:return Path(path)
 path=Path(path);out=path.with_name(path.stem+'_original_gaps.wav');meta=out.with_suffix('.json')
 fingerprint=hashlib.sha256((Path(plan['_folder'])/'plan.json').read_bytes()+path.read_bytes()).hexdigest()
 if out.is_file() and meta.is_file() and json.loads(meta.read_text())['fingerprint']==fingerprint:return out
 rate=plan['rate'];data=bytearray(read_pcm(path,rate));wanted=plan['frames']*2
 if abs(len(data)-wanted)>rate:raise ValueError('成品与原曲时间轴相差超过0.5秒，不能直接替换间奏。请保留旧成品并重新转换。')
 data=(data+b'\0'*max(0,wanted-len(data)))[:wanted]
 for g in plan['gaps']:
  gap=read_pcm(Path(plan['_folder'])/g['file'],rate);blend_gap(data,gap,g['start'],g['end'],rate)
 save_pcm(out,data,rate);meta.write_text(json.dumps({'fingerprint':fingerprint,'preserved_raw':str(path)}),encoding='utf-8')
 return out

def convert_active(req,core,plan):
 """Convert only vocal blocks; original gaps never pass through Seed-VC."""
 rate=plan['rate'];data=read_pcm(req['source'],rate)
 if len(data)//2!=plan['frames']:raise ValueError('人声音源与时间轴不一致')
 folder=Path(req['destination']).parent/'vocal_blocks';folder.mkdir(exist_ok=True)
 assembled=bytearray(plan['frames']*2)
 for i,(a,b) in enumerate(plan['active']):
  source=folder/f'input_{i:03d}.wav';save_pcm(source,data[a*2:b*2],rate)
  result=core.convert(str(source),req['reference'],name=req['name']+f'_{i:03d}',steps=30,setup=False)
  converted=read_pcm(result,rate);wanted=(b-a)*2
  if abs(len(converted)-wanted)>max(rate,int(wanted*.03)):raise ValueError('人声段转换长度变化过大，未覆盖已有成品')
  assembled[a*2:b*2]=(converted+b'\0'*max(0,wanted-len(converted)))[:wanted]
 for g in plan['gaps']:
  # Gaps are copied unchanged here. Blend edges against adjacent voice over 80ms.
  gap=read_pcm(Path(plan['_folder'])/g['file'],rate)
  if len(gap)!=(g['end']-g['start'])*2:raise ValueError('间奏文件不完整')
  assembled[g['start']*2:g['end']*2]=gap
 save_pcm(req['destination'],assembled,rate)
 return Path(req['destination'])
