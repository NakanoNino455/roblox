"""Transfer paths via UTF-8 JSON files, never console text. No dependencies."""
import json,os,sys,shutil,traceback
from pathlib import Path

def save(path,data):
 path=Path(path);tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=True),encoding='utf-8');os.replace(tmp,path)

def main(request_path):
 request_path=Path(request_path);req=json.loads(request_path.read_text(encoding='utf-8'));result=Path(req['result'])
 try:
  sys.path.insert(0,req['studio']);import song_core
  from hybrid_audio import load_plan,convert_active
  plan=load_plan(req['name'].removeprefix('xq_'),req['source'])
  output=convert_active(req,song_core,plan) if plan else Path(song_core.convert(req['source'],req['reference'],name=req['name'],steps=30,setup=False))
  if not output.is_file():raise FileNotFoundError('转换器返回路径不存在：'+str(output))
  dest=Path(req['destination']);tmp=dest.with_suffix('.tmp.wav');dest.parent.mkdir(parents=True,exist_ok=True)
  if output.resolve()!=dest.resolve():shutil.copy2(output,tmp);os.replace(tmp,dest)
  save(result,{'ok':True,'wav':str(dest),'original_output':str(output)})
 except Exception as exc:
  save(result,{'ok':False,'error':str(exc),'traceback':traceback.format_exc()});raise
if __name__=='__main__':main(sys.argv[1])
