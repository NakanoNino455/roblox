"""Install alongside current studio; patch only exact known hooks, keeping a backup."""
import ast, datetime, json, shutil, sys, tkinter as tk
from pathlib import Path
from tkinter import filedialog,messagebox
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from song_engine import write,read

def patch_bot(text):
    if '# XIAOQI_AUTOSONG_V1' in text:return text
    ast.parse(text)
    anchor='def make_queue_answer(persona, kind, payload, client, chat=None):\n'
    dispatch='            # Single-threaded GUI sender.'
    if text.count(anchor)!=1 or text.count(dispatch)!=1:raise RuntimeError('此微信主脚本结构不兼容，未修改。请提供当前正在运行的主脚本。')
    required=['v4_send_allowed','resolve_group_name','resolve_private_name','send_wechat_group','send_wechat_private','owner_paused']
    tree=ast.parse(text);names={n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    if not all(n in names for n in required):raise RuntimeError('主脚本缺少所需权限或发送接口，未修改。')
    insert='''    # XIAOQI_AUTOSONG_V1
    if chat and kind in ('private', 'mention') and v4_send_allowed(str(chat)):
        from xiaoqi_autosong_v1.xiaoqi_song_hook import command as song_command
        song_reply = song_command(str(chat), mem._newest(payload))
        if song_reply is not None: return song_reply
'''
    text=text.replace(anchor,anchor+insert,1)
    hook='''            # XIAOQI_AUTOSONG_V1 dispatch on the existing GUI thread
            try:
                from xiaoqi_autosong_v1.xiaoqi_song_hook import dispatch_one as song_dispatch
                song_dispatch(
                    allowed=lambda uid: (auto_send_groups and not owner_paused() and not STOP.exists()
                        and bool(load_settings()['auto_send_enabled']) and v4_send_allowed(uid)
                        and (uid in groups or private_allowed(load_settings(), uid))),
                    resolve_name=lambda uid: (resolve_group_name(db,uid) if uid.endswith('@chatroom') else resolve_private_name(db,uid)),
                    send_text=lambda uid,text: (send_wechat_group(wx,db,uid,text) if uid.endswith('@chatroom') else send_wechat_private(wx,db,uid,text)),
                    paused=(paused or not auto_send_groups))
            except Exception as song_error:
                print('点歌调度暂不可用:', str(song_error)[:200], flush=True)
'''
    text=text.replace(dispatch,hook+dispatch,1);ast.parse(text);return text

