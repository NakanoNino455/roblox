"""Main-thread delivery, ordered full-song parts; no replay after uncertainty."""
import concurrent.futures,hashlib,json,subprocess,sys,threading,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from song_engine import settings,parse_request,segments,write,utf8_env
_POOL=concurrent.futures.ThreadPoolExecutor(max_workers=1);_LOCK=threading.Lock();_JOBS=[];_KNOWN={};_LAST=0

def command(chat,text):
 req=parse_request(text)
 if not req:
  if '点歌' in str(text):
   print('群点歌未匹配：请使用 @小柒 点歌 歌名；消息开头=',ascii(str(text)[:100]),flush=True)
   return '请这样点歌：@小柒 点歌 我不难过（不要附加其他文字）。'
  return None
 print('点歌指令已识别', '群聊' if str(chat).endswith('@chatroom') else '私聊',req['title'],flush=True)
 c=settings()
 if not c.get('wechat_enabled',True):return '点歌已关闭。'
 if (Path(c['project'])/'STOP_XIAOQI').exists():return None
 key=hashlib.sha256((str(chat)+'|'+str(text)).encode()).hexdigest()
 with _LOCK:
  if time.time()-_KNOWN.get(key,0)<30:return '已收到，请等当前点歌完成。'
  if len(_JOBS)>=3:return '点歌队列已满，请稍候。'
  _KNOWN[key]=time.time();job=dict(id=hashlib.sha256((key+str(time.time())).encode()).hexdigest()[:20],chat=str(chat),request=req,created=time.time(),status='queued',parts=None,next=0)
  _JOBS.append((job,_POOL.submit(_generate,req,c)));write(HERE/'jobs'/(job['id']+'.json'),job)
 return '收到《'+req['title']+'》，'+('会按顺序分多条语音唱完整首。' if req['full'] else '这次随机唱一段。')+'首次需要转换整首，请稍等。'
def _generate(req,c):
 r=subprocess.run([c['controller_python'],str(HERE/'song_engine.py'),'--title',req['title'],'--artist',req['artist']],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=15000,env=utf8_env())
 if not r.stdout.strip():raise RuntimeError(r.stderr[-800:] or '制作进程没有输出')
 result=json.loads(r.stdout.strip().splitlines()[-1])
 if not result.get('ok'):raise RuntimeError(result.get('error','制作失败'))
 return result

def dispatch_one(allowed,resolve_name,send_text,paused=False):
 global _LAST
 c=settings();root=Path(c['project'])
 with _LOCK:
  if paused or (root/'STOP_XIAOQI').exists() or not c.get('wechat_enabled',True):
   for job,fut in _JOBS:
    fut.cancel();job['status']='cancelled';write(HERE/'jobs'/(job['id']+'.json'),job)
   _JOBS.clear();return
  if not _JOBS or time.time()-_LAST<5:return
  job,future=_JOBS[0]
  if not future.done():return
 uid=job['chat'];finished=False
 try:
  if time.time()-job['created']>21600 or not allowed(uid):job['status']='expired_or_disallowed';finished=True;return
  name=resolve_name(uid)
  if not name:job['status']='target_unresolved';finished=True;return
  try:result=future.result()
  except Exception as exc:
   job['status']='failed';job['error']=str(exc);finished=True;_LAST=time.time();send_text(uid,'《'+job['request']['title']+'》未完成：'+str(exc)[:180]);return
  if job['parts'] is None:job['parts']=segments(result,uid,job['request']['full']);job['result']=result
  sender=root/'xiaoqi_voice_sender_auto_v2.py'
  if not sender.is_file():raise RuntimeError('缺少已有微信语音发送器')
  if not allowed(uid) or (root/'STOP_XIAOQI').exists():job['status']='cancelled';finished=True;return
  i=job['next'];job['status']='sending';write(HERE/'jobs'/(job['id']+'.json'),job);_LAST=time.time()
  r=subprocess.run([sys.executable,str(sender),'--target',str(name),'--wav',job['parts'][i],'--send','--open-target','--no-wait'],cwd=c.get('sender_cwd',str(root)),timeout=100)
  if r.returncode:job['status']='uncertain';finished=True;return
  job['next']+=1;job['status']='sender_completed' if job['next']==len(job['parts']) else 'part_completed';finished=job['status']=='sender_completed'
 except Exception as exc:
  job['status']='uncertain' if job['status']=='sending' else 'failed';job['error']=str(exc);finished=True
 finally:
  write(HERE/'jobs'/(job['id']+'.json'),job)
  if finished:
   with _LOCK:
    if _JOBS and _JOBS[0][0] is job:_JOBS.pop(0)
