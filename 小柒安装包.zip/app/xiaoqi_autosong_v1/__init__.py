"""Xiaoqi auto song add-on."""
