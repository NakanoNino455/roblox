"""Offline full-song conversion and PCM slicing. Python 3.11, no pip or web."""
import hashlib,json,os,re,subprocess,sys,uuid,wave,sqlite3,random,time,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
CONFIG=HERE/'autosong.json'
def read(p,default):return json.loads(Path(p).read_text(encoding='utf-8-sig')) if Path(p).is_file() else default
def write(p,obj):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.'+uuid.uuid4().hex+'.tmp');tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)
def settings():return read(CONFIG,{})
def norm(s):return re.sub(r'[^\w\u4e00-\u9fff]','',s).casefold()
def connect():
 db=sqlite3.connect(HERE/'catalog.sqlite3',timeout=30);db.row_factory=sqlite3.Row
 db.execute('CREATE TABLE IF NOT EXISTS songs(id TEXT PRIMARY KEY,title TEXT,artist TEXT,source TEXT,sha256 TEXT,status TEXT,wav TEXT,error TEXT)')
 db.execute('CREATE TABLE IF NOT EXISTS history(chat TEXT,song TEXT,last_start INTEGER,PRIMARY KEY(chat,song))')
 return db
def rows():
 with connect() as db:return [dict(r) for r in db.execute('SELECT * FROM songs ORDER BY title')]
def update(sid,**fields):
 if set(fields)-{'status','wav','error'}:raise ValueError('未知字段')
 with connect() as db:db.execute('UPDATE songs SET '+','.join(k+'=?' for k in fields)+' WHERE id=?',(*fields.values(),sid))
def validate(p):
 with wave.open(str(p),'rb') as w:
  if w.getnframes()==0 or w.getnchannels() not in (1,2) or w.getsampwidth() not in (1,2,3,4):raise ValueError('需要单声道或双声道 PCM WAV')
  return w.getnframes()/w.getframerate()
def add(path,title,artist='',ready=False):
 p=Path(path);validate(p);digest=hashlib.sha256(p.read_bytes()).hexdigest();sid=hashlib.sha256((norm(title)+'|'+norm(artist)).encode()).hexdigest()[:24]
 folder=HERE/('ready_imports' if ready else 'vocals');folder.mkdir(exist_ok=True);dest=folder/(digest+'.wav')
 if not dest.exists():shutil.copy2(p,dest)
 with connect() as db:
  old=db.execute('SELECT * FROM songs WHERE id=?',(sid,)).fetchone()
  if old and old['sha256']==digest and not ready:return sid
  db.execute('INSERT OR REPLACE INTO songs VALUES(?,?,?,?,?,?,?,?)',(sid,title,artist,str(dest.relative_to(HERE)),digest,'可点歌' if ready else '待转换',str(dest.relative_to(HERE)) if ready else '', ''))
 return sid
def seed():
 for x in read(HERE/'seed_manifest.json',[]):
  p=HERE/x['source']
  if p.is_file():add(p,x['title'],x['artist'])
def resolve(title,artist=''):
 found=[r for r in rows() if norm(r['title'])==norm(title) and (not artist or norm(r['artist'])==norm(artist))]
 if len(found)>1:raise RuntimeError('同名歌曲，请用：点歌 歌名 - 歌手')
 if not found:raise RuntimeError('曲库尚未收录这首歌，请上传音源补库。')
 return found[0]
def utf8_env():
 env=os.environ.copy();env['PYTHONUTF8']='1';env['PYTHONIOENCODING']='utf-8'
 env['HF_HUB_OFFLINE']='1';env['TRANSFORMERS_OFFLINE']='1'
 return env

def publish(r,out,src):
 duration=validate(out)
 if duration<validate(src)*0.95:raise RuntimeError('转换结果明显短于整首音源，未保存为完整歌曲')
 folder=HERE/'converted';folder.mkdir(exist_ok=True);dest=folder/(r['id']+'.wav')
 if Path(out).resolve()!=dest.resolve():
  tmp=dest.with_suffix('.recover.tmp.wav');shutil.copy2(out,tmp);os.replace(tmp,dest)
 update(r['id'],status='可点歌',wav=str(dest.relative_to(HERE)),error='')
 return dict(title=r['title'],artist=r['artist'],id=r['id'],wav=str(dest),cached=False)

def recover_existing(r,c,src,emit=print):
 # Only recover failures that specifically showed a lost/garbled result path.
 error=r.get('error','')
 if r['status']!='失败' or not ('Errno 2' in error and ('outputs' in error or '\ufffd' in error)):return None
 outputs=Path(c['studio'])/'outputs'
 if not outputs.is_dir():return None
 clean=re.sub(r'[<>:"/\\|?*\x00-\x1f]','_',r['title']).strip('. ')[:80]
 candidates=[]
 for task in outputs.iterdir():
  if not task.is_dir() or not task.name.startswith(clean+'_'):continue
  # This is song_core's final named copy, not arbitrary cached/model audio.
  expected=task/(clean+'_小柒音色.wav')
  if expected.is_file():candidates.append(expected)
 for p in sorted(candidates,key=lambda p:p.stat().st_mtime,reverse=True):
  try:result=publish(r,p,src)
  except (OSError,ValueError,wave.Error,RuntimeError):continue
  emit('已找回上次生成的整首 WAV，无需重新转换。');return result
 return None

def hybrid_result(result,r):
 from hybrid_audio import finish_full
 out=finish_full(result['wav'],r['id'],HERE/r['source'])
 result['wav']=str(out)
 return result

def get_song(title,artist='',emit=print):
 r=resolve(title,artist);p=HERE/r['wav'] if r['wav'] else None
 if p and p.is_file():
  validate(p);return hybrid_result(dict(title=r['title'],artist=r['artist'],id=r['id'],wav=str(p),cached=True),r)
 c=settings();ref=Path(c['reference']);src=HERE/r['source']
 if not src.is_file():raise RuntimeError('缺少完整人声音源')
 lock=HERE/'conversion.lock'
 try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
 except FileExistsError:raise RuntimeError('已有转换任务；请等待完成。如上次崩溃，请关闭转换进程后再处理 conversion.lock。')
 os.close(fd)
 try:
  recovered=recover_existing(r,c,src,emit)
  if recovered:return hybrid_result(recovered,r)
  if not ref.is_file():raise RuntimeError('小柒参考音色文件不存在：'+str(ref))
  py=Path(c['controller_python']);studio=Path(c['studio'])
  if not py.is_file():raise RuntimeError('现有转换Python不存在：'+str(py))
  if not (studio/'song_core.py').is_file():raise RuntimeError('现有 song_core.py 不存在：'+str(studio))
  update(r['id'],status='转换中',error='');emit('转换整首：'+r['title'])
  job=HERE/'conversion_jobs'/uuid.uuid4().hex;job.mkdir(parents=True)
  destination=job/'output.wav';result_file=job/'result.json';request=job/'request.json'
  write(request,dict(studio=str(studio),source=str(src.resolve()),reference=str(ref.resolve()),name='xq_'+r['id'],destination=str(destination.resolve()),result=str(result_file.resolve())))
  log=job/'conversion.log'
  # Binary file handles avoid every Windows console codepage decoding dependency.
  with log.open('wb') as output:
   proc=subprocess.run([str(py),'-X','utf8','-u',str(HERE/'conversion_worker.py'),str(request)],stdout=output,stderr=subprocess.STDOUT,env=utf8_env(),timeout=14400)
  data=read(result_file,{})
  if proc.returncode or not data.get('ok'):
   reason=data.get('error') or log.read_bytes()[-3500:].decode('utf-8',errors='replace')
   raise RuntimeError(str(reason)+'\n详细日志：'+str(log))
  # Destination is known before starting; do not trust console output for paths.
  result=publish(r,destination,src)
  write(job/'completed.json',dict(result=result,original_output=data.get('original_output','')))
  return hybrid_result(result,r)
 except Exception as exc:update(r['id'],status='失败',error=str(exc));raise
 finally:lock.unlink(missing_ok=True)
def parse_request(text):
 text=str(text or '').replace('\u200b','').replace('\ufeff','').strip()
 # Raw DB group text may retain sender-ID + colon/newline before the mention.
 text=re.sub(r'^wxid_[A-Za-z0-9]+\s*:\s*','',text).strip()
 # Only remove an initial mention; do not search history for a song command.
 text=re.sub(r'^(?:@小柒[\s\u2005\u00a0，,：:]*|小柒[\s，,：:]*)','',text).strip()
 m=re.fullmatch(r'(?:点歌|唱首|唱一首|唱一下|来首|来一首|我要听|我想听|唱)\s*(.+)',text)
 if not m:return None
 value=m.group(1).strip();full=bool(re.search(r'完整|整首|全部|从头到尾|唱完',value))
 value=re.sub(r'完整版|完整首|完整|整首|全部|从头到尾|唱完','',value).strip(' 《》「」吧呀啊~～！!。')
 parts=re.split(r'\s+-\s+',value,maxsplit=1)
 if not parts[0] or len(value)>80:return None
 return dict(title=parts[0],artist=parts[1] if len(parts)>1 else '',full=full)

def segments(result,chat,full=False,limit=45):
 """Full mode covers all frames without gaps; default avoids last start per chat."""
 p=Path(result['wav']);duration=validate(p)
 with wave.open(str(p),'rb') as src:
  rate=src.getframerate();n=src.getnframes();length=int(limit*rate)
  if full:spans=[(a,min(length,n-a)) for a in range(0,n,length)]
  else:
   # 5-second grid; remove near-silent windows so instrumental gaps aren't selected.
   import audioop
   from hybrid_audio import load_plan
   row=next((r for r in rows() if r['id']==result['id']),None)
   plan=load_plan(result['id'],HERE/row['source']) if row else None
   starts=[round(t*rate) for t in plan['random_starts'] if round(t*rate)<n] if plan else list(range(0,max(1,n-length+1),5*rate))
   energies=[]
   for a in starts:
    src.setpos(a);data=src.readframes(min(length,n-a));energies.append(audioop.rms(data,src.getsampwidth()))
   peak=max(energies,default=0);starts=[a for a,v in zip(starts,energies) if v>=max(1,peak*0.25)] or [0]
   with connect() as db:
    old=db.execute('SELECT last_start FROM history WHERE chat=? AND song=?',(str(chat),result['id'])).fetchone()
    choices=[a for a in starts if not old or abs(a-old[0])>=10*rate] or [a for a in starts if not old or a!=old[0]] or starts
    a=random.SystemRandom().choice(choices);db.execute('INSERT OR REPLACE INTO history VALUES(?,?,?)',(str(chat),result['id'],a))
   spans=[(a,min(length,n-a))]
  folder=HERE/'clips'/uuid.uuid4().hex;folder.mkdir(parents=True)
  paths=[]
  for i,(a,count) in enumerate(spans):
   src.setpos(a);data=src.readframes(count);width=src.getsampwidth();channels=src.getnchannels()
   import audioop
   if channels==2:data=audioop.tomono(data,width,0.5,0.5)
   if width==1:data=audioop.bias(data,1,-128)
   data=audioop.lin2lin(data,width,2);data,_=audioop.ratecv(data,2,1,rate,16000,None)
   out=folder/f'{i+1:03d}.wav'
   with wave.open(str(out),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(data)
   paths.append(str(out))
 return paths
if __name__=='__main__':
 import argparse
 a=argparse.ArgumentParser();a.add_argument('--title',required=True);a.add_argument('--artist',default='');args=a.parse_args()
 try:print(json.dumps({'ok':True,**get_song(args.title,args.artist,emit=lambda s:print(s,file=sys.stderr))},ensure_ascii=True))
 except Exception as exc:print(json.dumps({'ok':False,'error':str(exc)},ensure_ascii=True));sys.exit(2)
