"""SQLite catalog; audio stays in managed files alongside the database."""
import sqlite3, hashlib, shutil, time, wave
from pathlib import Path
BASE=Path(__file__).resolve().parent

def connect():
    db=sqlite3.connect(BASE/'music.sqlite3',timeout=30)
    db.row_factory=sqlite3.Row
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('''CREATE TABLE IF NOT EXISTS songs(id TEXT PRIMARY KEY,title TEXT NOT NULL,artist TEXT NOT NULL,
        source TEXT DEFAULT '',vocals INTEGER DEFAULT 0,wav TEXT DEFAULT '',status TEXT DEFAULT '待制作',
        error TEXT DEFAULT '',updated REAL)''')
    return db

def key(title,artist):
    return hashlib.sha256((title.strip().casefold()+'|'+artist.strip().casefold()).encode()).hexdigest()[:24]

def upsert(title,artist='',**fields):
    title=title.strip();artist=artist.strip()
    if not title:raise ValueError('歌名不能为空')
    if set(fields)-{'source','vocals','wav','status','error'}:raise ValueError('未知字段')
    sid=key(title,artist)
    with connect() as db:
        db.execute('INSERT OR IGNORE INTO songs(id,title,artist,updated) VALUES(?,?,?,?)',(sid,title,artist,time.time()))
        fields['updated']=time.time()
        db.execute('UPDATE songs SET '+','.join(k+'=?' for k in fields)+' WHERE id=?',(*fields.values(),sid))
    return sid

def rows():
    with connect() as db:return [dict(r) for r in db.execute('SELECT * FROM songs ORDER BY title,artist')]

def find(title,artist=''):
    import re
    norm=lambda s:re.sub(r'[^\w\u4e00-\u9fff]','',s).casefold()
    matches=[r for r in rows() if norm(r['title'])==norm(title) and (not artist or norm(r['artist'])==norm(artist))]
    if len(matches)>1:raise RuntimeError('有同名歌曲，请用：点歌 歌名 - 歌手')
    return matches[0] if matches else None

def valid_wav(path):
    try:
        with wave.open(str(path),'rb') as w:return w.getnframes()>0 and w.getframerate()>0
    except (OSError,EOFError,wave.Error):return False

def import_audio(path,title,artist='',mode='source'):
    path=Path(path)
    if not path.is_file():raise FileNotFoundError(str(path))
    if mode=='ready' and not valid_wav(path):raise ValueError('成品请使用可播放的 PCM WAV 文件')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    folder=BASE/'audio'/('ready' if mode=='ready' else 'sources');folder.mkdir(parents=True,exist_ok=True)
    dest=folder/(digest+path.suffix.lower())
    if not dest.exists():shutil.copy2(path,dest)
    if mode=='ready':return upsert(title,artist,wav=str(dest),status='可点歌',error='')
    return upsert(title,artist,source=str(dest),vocals=int(mode=='vocals'),wav='',status='待制作',error='')

def initialize(c):
    import json
    candidates=BASE/'popular_candidates.json'
    for r in json.loads(candidates.read_text(encoding='utf-8')):
        if not find(r['title'],r.get('artist','')):upsert(r['title'],r.get('artist',''))
    for r in c.get('local_sources',[]):
        if Path(r.get('source','')).is_file():
            old=find(r['title'],r.get('artist',''))
            if not old or not old['source']:upsert(r['title'],r.get('artist',''),source=r['source'],vocals=1)
    for meta in (BASE/'cache').glob('*/metadata.json'):
        try:
            r=json.loads(meta.read_text(encoding='utf-8'));p=meta.parent/'song.wav'
            old=find(r['title'],r.get('artist',''))
            if valid_wav(p) and (not old or not old['wav']):upsert(r['title'],r.get('artist',''),wav=str(p),status='可点歌')
        except (ValueError,KeyError,OSError):pass
