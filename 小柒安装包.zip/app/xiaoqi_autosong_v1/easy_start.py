"""Discover known installation, preserve configuration, then open a single UI."""
import os,sys,json,shutil,datetime,subprocess,tkinter as tk
from pathlib import Path
from tkinter import filedialog,messagebox
HERE=Path(__file__).resolve().parent
from install import patch_bot
from song_engine import read,write

def locate():
    homes=[Path.home()/'Desktop',Path.home()/'OneDrive'/'Desktop']
    choices=[HERE.parent,HERE.parent.parent]+[h/'xiaoqi_wechat_v2'/'xiaoqi_wechat_v2' for h in homes]+[h/'xiaoqi_wechat_v2' for h in homes]
    found=[]
    for p in choices:
        if (p/'xiaoqi_v4_voice_choice.py').is_file() and p.resolve() not in found:found.append(p.resolve())
    if len(found)==1:return found[0]
    p=filedialog.askopenfilename(title='只需一次：选择 xiaoqi_v4_voice_choice.py',filetypes=[('小柒微信主脚本','xiaoqi_v4_voice_choice.py')])
    return Path(p).parent if p else None

def setup(root):
    dest=root/'xiaoqi_autosong_v1';cfg=read(dest/'autosong.json',{})
    studio=Path(cfg.get('studio') or root/'missing')
    if not (studio/'song_core.py').is_file():
        candidates=list((root/'xiaoqi_singing').rglob('song_core.py'))
        if len(candidates)==1:studio=candidates[0].parent
        else:
            p=filedialog.askopenfilename(title='找到多个工作台：选择正在用的 song_core.py',initialdir=str(root),filetypes=[('工作台','song_core.py')])
            if not p:return
            studio=Path(p).parent
    ref=Path(cfg.get('reference') or root/'xiaoqi_reference_16k.wav')
    if not ref.is_file():
        refs=[p for p in [root/'xiaoqi_singing'/'xiaoqi_reference_16k.wav',Path.home()/'Desktop'/'xiaoqi_reference_16k.wav'] if p.is_file()]
        if refs:ref=refs[0]
        else:
            p=filedialog.askopenfilename(title='首次使用：选择小柒参考音色 WAV',initialdir=str(root),filetypes=[('音色','*.wav')])
            if not p:return
            ref=Path(p)
    bot=root/'xiaoqi_v4_voice_choice.py';original=bot.read_text(encoding='utf-8-sig');patched=patch_bot(original)
    stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=root/'xiaoqi_music_backups'/stamp;backup.mkdir(parents=True)
    shutil.copy2(bot,backup/bot.name)
    if dest.is_dir():
        for p in dest.iterdir():
            if p.is_file() and p.suffix in {'.py','.json'}:shutil.copy2(p,backup/p.name)
    dest.mkdir(exist_ok=True)
    for p in HERE.iterdir():
        if p.suffix in {'.py','.json'} and p.name!='autosong.json' and p.resolve()!=(dest/p.name).resolve():shutil.copy2(p,dest/p.name)
    cozy=root/'cosyvoice_env'/'Scripts'/'python.exe'
    cfg.update(project=str(root),studio=str(studio),reference=str(ref))
    cfg.setdefault('controller_python',str(cozy) if cozy.is_file() else sys.executable)
    cfg['auto_fetch']=False
    cfg.setdefault('wechat_enabled',True)
    legacy=Path.home()/'Desktop'/'CosyVoice'/'QwenAudio-CosyVoice-8555549'
    cfg.setdefault('sender_cwd',str(legacy if legacy.is_dir() else root))
    # Copy bundled complete vocals; preserve existing catalog and converted songs.
    for folder in ['vocals']:
        source=HERE/folder
        if source.is_dir() and source.resolve()!=(dest/folder).resolve():shutil.copytree(source,dest/folder,dirs_exist_ok=True)
    if (HERE/'catalog.sqlite3').is_file() and not (dest/'catalog.sqlite3').exists() and HERE.resolve()!=dest.resolve():
        shutil.copy2(HERE/'catalog.sqlite3',dest/'catalog.sqlite3')
    write(dest/'autosong.json',cfg)
    if original!=patched:
        tmp=bot.with_suffix('.music.tmp');tmp.write_text(patched,encoding='utf-8');os.replace(tmp,bot)
    write(HERE/'installed_location.json',{'root':str(root)})
    return dest

def main():
    app=tk.Tk();app.withdraw()
    saved=read(HERE/'installed_location.json',{})
    root=Path(saved['root']) if saved.get('root') else None
    if root and (root/'xiaoqi_autosong_v1'/'music_app.py').is_file():dest=root/'xiaoqi_autosong_v1'
    elif (HERE/'autosong.json').is_file() and (HERE/'music_app.py').is_file():dest=HERE
    else:
        root=locate()
        if not root:return
        dest=setup(root)
        if not dest:return
    subprocess.Popen([sys.executable,str(dest/'music_app.py')],cwd=str(dest))
    app.destroy()
if __name__=='__main__':
    try:main()
    except Exception as e:messagebox.showerror('小柒曲库',str(e));sys.exit(1)
