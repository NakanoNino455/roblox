import os,queue,threading,tkinter as tk
from tkinter import ttk,filedialog,simpledialog,messagebox
from pathlib import Path
import song_engine as e
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('小柒 · 离线完整曲库');self.geometry('880x600');self.q=queue.Queue();self.busy=False;e.seed()
  b=ttk.Frame(self,padding=16);b.pack(fill='both',expand=True)
  ttk.Label(b,text='小柒 · 离线完整曲库',font=('Microsoft YaHei UI',22,'bold')).pack(anchor='w')
  ttk.Label(b,text='完整人声音源 → 现有模型转换整首 → 随机一段 / 分条唱完').pack(anchor='w',pady=8)
  row=ttk.Frame(b);row.pack(fill='x')
  for label,fn in [('添加人声 WAV',lambda:self.add(False)),('添加小柒成品 WAV',lambda:self.add(True)),('导入增量曲库包',self.package),('转换选中整首',self.convert),('试听成品',self.play)]:ttk.Button(row,text=label,command=fn).pack(side='left',padx=3)
  self.table=ttk.Treeview(b,columns=('title','artist','status'),show='headings',selectmode='extended')
  for x,y in [('title','歌名'),('artist','歌手'),('status','状态')]:self.table.heading(x,text=y)
  self.table.pack(fill='both',expand=True,pady=12)
  self.enabled=tk.BooleanVar(value=e.settings().get('wechat_enabled',True));ttk.Checkbutton(b,text='启用微信点歌（重启原机器人后生效）',variable=self.enabled,command=self.save).pack(anchor='w')
  ttk.Label(b,text='点歌 我不难过：随机一段；点歌 我不难过 完整版：顺序分条唱完\n后续 MP3 请上传聊天处理为人声音源后导入。此程序只读本地 WAV。').pack(anchor='w',pady=8)
  self.log=tk.Text(b,height=8,wrap='word');self.log.pack(fill='x');self.refresh();self.after(200,self.pump)
 def save(self):c=e.settings();c['wechat_enabled']=self.enabled.get();e.write(e.CONFIG,c)
 def refresh(self):
  ids=self.table.selection();self.table.delete(*self.table.get_children())
  for r in e.rows():self.table.insert('','end',iid=r['id'],values=(r['title'],r['artist'],r['status']))
  for i in ids:
   if self.table.exists(i):self.table.selection_add(i)
 def work(self,fn):
  if self.busy:return
  self.busy=True
  def worker():
   try:fn()
   except Exception as ex:self.q.put('未完成：'+str(ex))
   finally:self.q.put(None)
  threading.Thread(target=worker,daemon=True).start()
 def pump(self):
  try:
   while True:
    msg=self.q.get_nowait()
    if msg is None:self.busy=False;self.refresh()
    else:self.log.insert('end',str(msg)+'\n');self.log.see('end')
  except queue.Empty:pass
  self.after(200,self.pump)
 def add(self,ready):
  paths=filedialog.askopenfilenames(filetypes=[('PCM WAV','*.wav')])
  for p in paths:
   parts=Path(p).stem.split(' - ',1);title=simpledialog.askstring('歌名','歌名：',initialvalue=parts[0])
   if not title:continue
   artist=simpledialog.askstring('歌手','歌手（可留空）：',initialvalue=parts[1] if len(parts)>1 else '')
   if artist is None:continue
   try:e.add(p,title,artist,ready)
   except Exception as ex:messagebox.showerror('导入失败',str(ex))
  self.refresh()
 def package(self):
  path=filedialog.askopenfilename(filetypes=[('增量人声包','*.zip')])
  if not path:return
  def task():
   import zipfile,tempfile,json,hashlib
   with zipfile.ZipFile(path) as z:
    if sum(i.file_size for i in z.infolist())>2*1024**3:raise ValueError('包过大')
    manifest=json.loads(z.read('manifest.json'))
    with tempfile.TemporaryDirectory() as temp:
     for i,r in enumerate(manifest['songs']):
      data=z.read(r['source'])
      if hashlib.sha256(data).hexdigest()!=r['sha256']:raise ValueError('音源校验失败')
      p=Path(temp)/f'{i}.wav';p.write_bytes(data);sid=e.add(p,r['title'],r.get('artist',''))
      if r.get('plan'):
       plan=json.loads(z.read(r['plan']))
       if plan['id']!=sid or plan['source_sha256']!=r['sha256']:raise ValueError('时间轴与歌曲不匹配')
       folder=e.HERE/'plans'/sid;folder.mkdir(parents=True,exist_ok=True)
       for gap in plan['gaps']:
        if Path(gap['file']).name!=gap['file']:raise ValueError('间奏文件名不合法')
        member=str(Path(r['plan']).parent/gap['file']).replace('\\','/')
        (folder/gap['file']).write_bytes(z.read(member))
       e.write(folder/'plan.json',plan)
      self.q.put('已补库：'+r['title'])
  self.work(task)
 def convert(self):
  ids=set(self.table.selection());rows=[r for r in e.rows() if r['id'] in ids]
  def task():
   for r in rows:
    try:e.get_song(r['title'],r['artist'],emit=self.q.put);self.q.put('整首已保存：'+r['title'])
    except Exception as ex:self.q.put(r['title']+'：'+str(ex))
  self.work(task)
 def play(self):
  ids=set(self.table.selection())
  for r in e.rows():
   if r['id'] in ids and r['wav']:
    self.work(lambda row=r:os.startfile(e.get_song(row['title'],row['artist'],emit=self.q.put)['wav']));break
if __name__=='__main__':App().mainloop()
