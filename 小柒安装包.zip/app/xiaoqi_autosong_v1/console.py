import json,os,queue,subprocess,sys,threading,tkinter as tk,venv
from pathlib import Path
from tkinter import ttk,messagebox,filedialog
from song_engine import settings,write,CONFIG,HERE,get_song,run,ffmpeg,toolpy,parse_request
class Console(tk.Tk):
    def __init__(self):
        super().__init__();self.title('小柒 · 自动点歌 v1');self.geometry('1080x620');self.q=queue.Queue();self.busy=False
        c=settings();self.ref=tk.StringVar(value=c['reference']);self.titlevar=tk.StringVar(value='晴天');self.artist=tk.StringVar(value='周杰伦');self.fetch=tk.BooleanVar(value=c.get('auto_fetch',True));self.wx=tk.BooleanVar(value=c.get('wechat_enabled',True))
        box=ttk.Frame(self,padding=16);box.pack(fill='both',expand=True)
        ttk.Label(box,text='小柒 · 自动点歌',font=('Microsoft YaHei UI',21,'bold')).pack(anchor='w')
        ttk.Label(box,text='本地音源 → 联网找歌 → 人声分离 → 小柒音色 → 缓存复用',padding=(0,8)).pack(anchor='w')
        row=ttk.Frame(box);row.pack(fill='x');ttk.Label(row,text='参考音色').pack(side='left');ttk.Entry(row,textvariable=self.ref).pack(side='left',fill='x',expand=True,padx=8);ttk.Button(row,text='选择',command=self.choose).pack(side='left')
        row=ttk.Frame(box);row.pack(fill='x',pady=10);ttk.Label(row,text='歌名').pack(side='left');ttk.Entry(row,textvariable=self.titlevar,width=25).pack(side='left',padx=8);ttk.Label(row,text='歌手').pack(side='left');ttk.Entry(row,textvariable=self.artist,width=20).pack(side='left',padx=8)
        row=ttk.Frame(box);row.pack(fill='x');ttk.Checkbutton(row,text='缺歌时联网找音源',variable=self.fetch,command=self.save).pack(side='left');ttk.Checkbutton(row,text='启用微信点歌（沿用原发送范围）',variable=self.wx,command=self.save).pack(side='left')
        row=ttk.Frame(box);row.pack(fill='x',pady=8)
        for label,fn in [('安装联网工具',self.install_tools),('安装人声分离',self.install_sep),('登记当前歌曲清唱',self.register),('制作/试听当前歌曲',self.make),('批量制作候选歌曲',self.batch),('打开音源目录',self.sources),('打开成品目录',self.outputs)]:ttk.Button(row,text=label,command=fn).pack(side='left',padx=2)
        ttk.Label(box,text='联网获取需目标站点可访问；找不到、需要登录或匹配不明确会报告失败。\n候选歌名没有附带歌谱或音频，成功转换后才进入可播放缓存。',wraplength=800).pack(anchor='w',pady=5)
        self.log=tk.Text(box,wrap='word',font=('Microsoft YaHei UI',10));self.log.pack(fill='both',expand=True)
        self.after(100,self.pump);self.q.put('先安装联网工具。已有清唱WAV可直接使用；含伴奏资源需要安装人声分离。')
    def choose(self):
        p=filedialog.askopenfilename(filetypes=[('参考音色','*.wav')]);
        if p:self.ref.set(p);self.save()
    def save(self):
        c=settings();c.update(reference=self.ref.get(),auto_fetch=self.fetch.get(),wechat_enabled=self.wx.get());write(CONFIG,c)
    def work(self,fn):
        if self.busy:return
        self.save();self.busy=True
        def worker():
            try:fn();self.q.put('本次操作完成。')
            except Exception as e:self.q.put('未完成：'+str(e))
            finally:self.q.put(None)
        threading.Thread(target=worker,daemon=True).start()
    def pump(self):
        try:
            while True:
                s=self.q.get_nowait()
                if s is None:self.busy=False
                else:self.log.insert('end',str(s)+'\n');self.log.see('end')
        except queue.Empty:pass
        self.after(100,self.pump)
    def install_tools(self):self.work(lambda:self.setup(False))
    def install_sep(self):self.work(lambda:self.setup(True))
    def setup(self,sep):
        c=settings();path=Path(c['separator_python'] if sep else c['tools_python'])
        if not path.is_file():
            self.q.put('创建独立工具环境：'+str(path.parent.parent));venv.EnvBuilder(with_pip=True).create(path.parent.parent)
        packages=['torch==2.5.1','torchaudio==2.5.1','demucs==4.0.1','numpy<2','soundfile'] if sep else ['yt-dlp','imageio-ffmpeg']
        args=[path,'-m','pip','install','--disable-pip-version-check','--prefer-binary',*packages]
        self.q.put('安装需要一些时间，分离环境较大；不会改动现有Seed-VC或CosyVoice环境。')
        self.q.put(run(args,1800))
    def register(self):
        title=self.titlevar.get().strip();artist=self.artist.get().strip()
        if not title:return
        path=filedialog.askopenfilename(title='选择已经做好的清唱音源',filetypes=[('歌声','*.wav *.mp3 *.flac *.ogg *.m4a')])
        if not path:return
        c=settings();rows=c.get('local_sources',[])
        rows=[r for r in rows if not (r.get('title')==title and r.get('artist')==artist)]
        rows.append({'title':title,'artist':artist,'source':path});c['local_sources']=rows;write(CONFIG,c)
        self.q.put('已登记清唱：'+title+' / '+artist)
    def make(self):
        title=self.titlevar.get().strip();artist=self.artist.get().strip()
        if not title:return
        def task():
            r=get_song(title,artist,emit=self.q.put);self.q.put(('缓存命中：' if r['cached'] else '生成成功：')+r['wav'])
            if os.name=='nt':os.startfile(r['wav'])
        self.work(task)
    def batch(self):
        rows=json.loads((HERE/'popular_candidates.json').read_text(encoding='utf-8'))
        if not messagebox.askyesno('批量制作',f'依次尝试 {len(rows)} 首候选歌曲，可能需要很长时间。失败会记录并跳到下一首。开始？'):return
        def task():
            report=[]
            for item in rows:
                if (Path(settings()['project'])/'STOP_XIAOQI').exists():self.q.put('检测到停止文件，结束批量制作。');break
                try:
                    self.q.put('正在制作：'+item['title']);r=get_song(item['title'],item['artist'],emit=self.q.put);report.append({'ok':True,**r})
                except Exception as e:report.append({'ok':False,**item,'error':str(e)});self.q.put(item['title']+'：'+str(e))
                write(HERE/'batch_report.json',report)
            self.q.put('批量结果保存在 batch_report.json')
        self.work(task)
    def sources(self):
        p=Path(settings()['source_dirs'][-1]);p.mkdir(exist_ok=True,parents=True)
        if os.name=='nt':os.startfile(p)
    def outputs(self):
        p=HERE/'cache';p.mkdir(exist_ok=True)
        if os.name=='nt':os.startfile(p)
if __name__=='__main__':Console().mainloop()
