"""XiaoQi 7.0 optional text tools + offline multimodal processors.
No implicit file-system browsing, shell execution or cross-chat data access.
All chat commands opt-in via exact prefix. Per-chat reminders stored locally.
"""
import datetime as dt
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import tempfile
import urllib.parse
import urllib.request
from html.parser import HTMLParser
from html import unescape
import ipaddress

ROOT=Path(__file__).resolve().parent
DB=ROOT/'xiaoqi7_tasks.sqlite3'
CONFIG=ROOT/'xiaoqi7_config.json'
DEFAULT={'enable_search':True,'enable_reminders':True,'max_searches_per_chat_per_hour':6,
         'max_file_size_mb':20,'enable_audio_processing':False,'enable_video_processing':False,
         'enable_document_processing':False,'enable_voice_output':False}

def config():
    if not CONFIG.exists():return DEFAULT.copy()
    try:return {**DEFAULT,**json.loads(CONFIG.read_text(encoding='utf-8-sig'))}
    except (ValueError,OSError,TypeError):return DEFAULT.copy()

def connect():
    con=sqlite3.connect(DB,timeout=10)
    con.execute('PRAGMA busy_timeout=10000')
    con.execute('''CREATE TABLE IF NOT EXISTS reminders(id INTEGER PRIMARY KEY,chat TEXT NOT NULL,
      due TEXT NOT NULL,note TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'pending')''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_due ON reminders(status,due)')
    con.execute('''CREATE TABLE IF NOT EXISTS searches(chat TEXT NOT NULL,stamp TEXT NOT NULL)''')
    con.commit()
    return con

class _SearchHTML(HTMLParser):
    """Extract visible search-result heading links; no JavaScript execution."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_h3=0
        self.a_href=None
        self.anchor_text=[]
        self.results=[]
        self.skip=0

    def handle_starttag(self, tag, attrs):
        attrs=dict(attrs)
        if tag in ('script','style','noscript'):
            self.skip+=1
        if tag=='h3':
            self.in_h3+=1
        if tag=='a' and self.in_h3 and not self.skip:
            self.a_href=attrs.get('href','')
            self.anchor_text=[]

    def handle_data(self, data):
        if self.a_href is not None and not self.skip:
            self.anchor_text.append(data)

    def handle_endtag(self, tag):
        if tag=='a' and self.a_href is not None:
            title=re.sub(r'\s+',' ',''.join(self.anchor_text)).strip()
            if title and self.a_href:
                self.results.append((title,self.a_href))
            self.a_href=None
        if tag=='h3':
            self.in_h3=max(0,self.in_h3-1)
        if tag in ('script','style','noscript'):
            self.skip=max(0,self.skip-1)


def _retrieve(url, timeout=7):
    req=urllib.request.Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36',
        'Accept-Language':'zh-CN,zh;q=0.9,en;q=0.7',
    })
    with urllib.request.urlopen(req,timeout=timeout) as response:
        raw=response.read(450000)
        charset=response.headers.get_content_charset() if hasattr(response.headers,'get_content_charset') else None
    for encoding in [charset,'utf-8','gb18030']:
        if not encoding:continue
        try:return raw.decode(encoding)
        except (LookupError,UnicodeDecodeError):continue
    return raw.decode('utf-8',errors='replace')


def _normalize_result_link(href,provider):
    href=unescape(href).strip()
    if href.startswith('//'):href='https:'+href
    elif href.startswith('/'):
        href=('https://www.baidu.com' if provider=='百度' else 'https://www.sogou.com')+href
    try:
        parsed=urllib.parse.urlsplit(href)
        if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password:return None
        # Don't return local/malformed URLs as user-visible search sources.
        host=parsed.hostname.lower()
        if host in ('localhost',) or host.endswith(('.local','.internal')):return None
        try:
            if not ipaddress.ip_address(host).is_global:return None
        except ValueError:pass
        return href[:1200]
    except ValueError:return None


def _domestic_search(query):
    providers=[
        ('百度','https://www.baidu.com/s?'+urllib.parse.urlencode({'wd':query})),
        ('搜狗','https://www.sogou.com/web?'+urllib.parse.urlencode({'query':query})),
    ]
    failures=[]
    for provider,url in providers:
        try:
            parser=_SearchHTML()
            parser.feed(_retrieve(url))
            results=[]
            seen=set()
            for title,href in parser.results:
                link=_normalize_result_link(href,provider)
                if not link or link in seen:continue
                seen.add(link)
                results.append((title[:110],link))
                if len(results)>=3:break
            if results:
                lines=[f'{i}. {title}\n{link}' for i,(title,link) in enumerate(results,1)]
                return f'{provider}网页搜索结果（仅展示标题与链接，尚未核验网页正文）：\n'+'\n'.join(lines)
            failures.append(provider+'未获取到可解析的结果')
        except Exception as exc:
            failures.append(provider+':'+type(exc).__name__)
    return None


def _wikipedia_search(query):
    url='https://zh.wikipedia.org/w/api.php?'+urllib.parse.urlencode({
      'action':'query','generator':'search','gsrsearch':query,'gsrlimit':3,
      'prop':'extracts|info','inprop':'url','exintro':'1','explaintext':'1',
      'exsentences':3,'format':'json'})
    data=json.loads(_retrieve(url,timeout=5))
    pages=list(data.get('query',{}).get('pages',{}).values())
    pages.sort(key=lambda page:page.get('index',999))
    if not pages:return None
    lines=[]
    for page in pages[:3]:
        title=str(page.get('title',''))[:90]
        desc=re.sub(r'\s+',' ',str(page.get('extract','')))[:320]
        url='https://zh.wikipedia.org/wiki/'+urllib.parse.quote(title.replace(' ','_'))
        lines.append(title+'：'+(desc or '暂无摘要')+'\n'+url)
    return '维基百科资料（并非实时新闻，需核对来源）：\n'+'\n'.join(lines)


def wiki_search(query):
    """Domestic webpage search first; wiki fallback. Never fabricate sources."""
    query=str(query).strip()[:100]
    if not query:return '请在“小柒百科”或“小柒搜索”后写要查询的内容。'
    result=_domestic_search(query)
    if result:return result
    try:
        result=_wikipedia_search(query)
        if result:return result
    except Exception:
        pass
    return '联网搜索暂时不可用：搜索站点可能超时、限制自动访问或改变网页结构，请稍后再试。'

def text_command(chat, message, private=True):
    """Return None if not a special command, otherwise a reply string.
    Public groups cannot create personal reminders. No model interpretation.
    """
    body=str(message or '').strip()
    cfg=config()
    if body.startswith(('小柒百科 ','小柒百科：','小柒搜索 ','小柒搜索：')):
        if not cfg['enable_search']:return '联网查询功能暂未启用。'
        query=re.split('[ ：]',body,1)[-1].strip()
        if not query:return '请提供查询关键词。'
        try:
            with connect() as con:
                since=(dt.datetime.now()-dt.timedelta(hours=1)).isoformat()
                n=con.execute('SELECT count(*) FROM searches WHERE chat=? AND stamp>=?',(chat,since)).fetchone()[0]
                if n>=int(cfg['max_searches_per_chat_per_hour']):return '联网查询次数已达上限，一小时后再试。'
                con.execute('INSERT INTO searches VALUES(?,?)',(chat,dt.datetime.now().isoformat()))
                con.execute('DELETE FROM searches WHERE stamp<?',(since,))
            return wiki_search(query)
        except Exception as exc:
            return '当前联网查询不可用（'+type(exc).__name__+'），请稍后再试。'
    if body.startswith('小柒提醒'):
        if not private:return '为保护隐私，提醒只能在私聊中设置。'
        if not cfg['enable_reminders']:return '提醒功能暂未启用。'
        if body in ('小柒提醒 查看','小柒提醒 列表'):
            with connect() as con:
                rows=con.execute('SELECT id,due,note FROM reminders WHERE chat=? AND status="pending" ORDER BY due LIMIT 12',(chat,)).fetchall()
            return '你的待办提醒：\n'+'\n'.join('%d. %s %s'%r for r in rows) if rows else '目前没有待办提醒。'
        m=re.fullmatch(r'小柒提醒 删除\s+(\d+)',body)
        if m:
            with connect() as con:
                n=con.execute('UPDATE reminders SET status="cancelled" WHERE chat=? AND id=? AND status="pending"',(chat,int(m.group(1)))).rowcount
            return '提醒已取消。' if n else '没有找到这条待办提醒。'
        m=re.fullmatch(r'小柒提醒\s+(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})\s+(.{1,150})',body,re.S)
        if not m:return '格式：小柒提醒 2026-10-15 08:00 交作业（使用电脑本地时间）'
        try:due=dt.datetime.strptime(m.group(1)+' '+m.group(2),'%Y-%m-%d %H:%M')
        except ValueError:return '日期时间格式不正确。'
        now=dt.datetime.now()
        if not now<due<now+dt.timedelta(days=366):return '提醒时间需要在未来一年内。'
        with connect() as con:
            if con.execute('SELECT count(*) FROM reminders WHERE chat=? AND status="pending"',(chat,)).fetchone()[0]>=30:
                return '这个聊天的待办提醒已达30条，请先删除一些。'
            cur=con.execute('INSERT INTO reminders(chat,due,note) VALUES(?,?,?)',(chat,due.isoformat(timespec='minutes'),m.group(3).strip()))
            id_=cur.lastrowid
        return f'提醒已保存（编号{id_}）：{due:%Y-%m-%d %H:%M} {m.group(3).strip()}'
    return None

def due_for_chats(chat_ids, max_count=5):
    """Reserve reminders transactionally. Only chats discovered/verified by bot.
    They are never automatically re-sent if delivery is uncertain.
    """
    ids=[str(x) for x in chat_ids if not str(x).endswith('@chatroom')]
    if not ids or not config()['enable_reminders']:return []
    result=[]
    with connect() as con:
        for chat in ids:
            if len(result)>=max_count:break
            rows=con.execute('SELECT id,note FROM reminders WHERE chat=? AND due<=? AND status="pending" ORDER BY due LIMIT ?',
                 (chat,dt.datetime.now().isoformat(timespec='minutes'),max_count-len(result))).fetchall()
            for rid,note in rows:
                if con.execute('UPDATE reminders SET status="claimed" WHERE id=? AND status="pending"',(rid,)).rowcount:
                    result.append((chat,rid,note))
    return result

def safe_local_path(path):
    p=Path(path).expanduser().resolve(strict=True)
    if not p.is_file():raise ValueError('只能处理普通文件')
    if p.stat().st_size>int(config()['max_file_size_mb'])*1024*1024:raise ValueError('文件过大')
    return p

def read_document(path):
    if not config()['enable_document_processing']:raise RuntimeError('请先在 xiaoqi7_config.json 开启文档处理')
    p=safe_local_path(path)
    if p.suffix.lower()=='.pdf':
        from pypdf import PdfReader
        text='\n'.join((page.extract_text() or '') for page in PdfReader(str(p)).pages[:25])
    elif p.suffix.lower()=='.docx':
        from docx import Document
        text='\n'.join(x.text for x in Document(str(p)).paragraphs)
    elif p.suffix.lower()=='.pptx':
        from pptx import Presentation
        text='\n'.join(shape.text for slide in Presentation(str(p)).slides[:40] for shape in slide.shapes if shape.has_text_frame)
    elif p.suffix.lower()=='.xlsx':
        import openpyxl
        wb=openpyxl.load_workbook(str(p),read_only=True,data_only=True)
        text='\n'.join(str(row) for ws in wb.worksheets[:5] for row in list(ws.values)[:100])
        wb.close()
    elif p.suffix.lower() in ('.txt','.md'):
        text=p.read_text(encoding='utf-8',errors='replace')
    else:raise ValueError('只支持 pdf/docx/pptx/xlsx/txt/md')
    return text[:18000] or '文件没有可提取的文本（扫描版PDF需要另外做OCR）。'

def transcribe_audio(path):
    if not config()['enable_audio_processing']:raise RuntimeError('请先开启音频处理')
    p=safe_local_path(path)
    if p.suffix.lower() not in ('.mp3','.wav','.m4a','.ogg','.flac','.mp4'):raise ValueError('不支持的音频格式')
    from faster_whisper import WhisperModel
    model=WhisperModel('whisper_tiny',device='cpu',compute_type='int8')
    segments,_=model.transcribe(str(p),beam_size=3,vad_filter=True)
    return ' '.join(x.text for x in segments)[:15000]

def analyze_video(path):
    if not config()['enable_video_processing']:raise RuntimeError('请先开启视频处理')
    p=safe_local_path(path)
    if p.suffix.lower()!='.mp4':raise ValueError('目前仅支持MP4')
    import xiaoqi4_extra as x4
    return x4.video_answer(p)

def synthesize_voice(text,out_path):
    if not config()['enable_voice_output']:raise RuntimeError('请先开启语音输出')
    import asyncio
    import edge_tts
    async def work():
        comm=edge_tts.Communicate(str(text)[:1200],voice='zh-CN-XiaoxiaoNeural')
        await comm.save(str(out_path))
    asyncio.run(work())
    return str(out_path)
