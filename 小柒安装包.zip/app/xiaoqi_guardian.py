"""独立 Python 守护启动器。仅对异常退出自动重启，正常/主人停止不重启。
不检测网络断线，不删除 wechatauto 缓存，不触碰聊天数据库。
"""
from collections import deque
from pathlib import Path
import subprocess
import sys
import time
import datetime
import os

HERE=Path(__file__).resolve().parent
MAIN=HERE/'xiaoqi_v4_voice_choice.py'
LOG=HERE/'xiaoqi_guardian.log'


def log(line):
    stamped=datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')+' '+line
    print(stamped,flush=True)
    with LOG.open('a',encoding='utf-8') as out:out.write(stamped+'\n')


def main():
    # 先让使用者明确批准本次守护会话；异常重启期间复用，不跨会话保存授权。
    print('本次守护运行期间，小柒会自动回复所有已授权私聊及可验证群聊。',flush=True)
    print('如主程序异常退出，守护器会尝试重新启动且不再重复询问。',flush=True)
    try:
        approved=input('输入 SEND ALL GROUPS V35 确认本次守护会话：').strip()
    except (EOFError,KeyboardInterrupt):
        log('未取得人工授权，守护器停止')
        return 0
    if approved!='SEND ALL GROUPS V35':
        log('人工未授权，守护器停止')
        return 0
    log('已取得本次守护会话授权；仅异常重启沿用')
    crashes=deque()
    while True:
        log('启动小柒；正常退出/主人停止后不会重启')
        try:
            child_env=os.environ.copy()
            child_env['XIAOQI_VOICE_ENABLE']='1'
            child_env['XIAOQI_VOICE_QUEUE_ENABLE']='1'
            child_env['XIAOQI_VOICE_SCOPE']='all'
            child_env['XIAOQI_VOICE_TARGETS']='*'
            child_env['XIAOQI_VOICE_PROBABILITY']='0.30'
            child_env['XIAOQI_GUARDIAN_APPROVED']='SESSION_ONLY'
            child_env['XIAOQI_GUARDIAN_PARENT_PID']=str(os.getpid())
            proc=subprocess.run([sys.executable,'-u',str(MAIN),'--auto-send-groups'],cwd=str(HERE),env=child_env)
        except KeyboardInterrupt:
            log('控制台人工终止，守护停止')
            return 0
        code=proc.returncode
        if code in (0,130,3221225786,-1073741510):
            log(f'小柒正常停止或人工中断（退出码 {code}），不重启')
            return 0
        now=time.monotonic()
        crashes.append(now)
        while crashes and now-crashes[0]>3600:crashes.popleft()
        if len(crashes)>5:
            log('1小时内连续异常退出超过5次，停止自动重启，需人工检查')
            return 2
        delay=min(180,15*2**(len(crashes)-1))
        log(f'小柒意外退出（退出码 {code}），{delay}秒后尝试重启，第{len(crashes)}次')
        try:time.sleep(delay)
        except KeyboardInterrupt:
            log('人工终止守护，停止重启');return 0

if __name__=='__main__':sys.exit(main())
