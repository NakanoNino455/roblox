@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3.11 -u xiaoqi_guardian.py
if errorlevel 1 echo Guardian stopped with error. Check xiaoqi_guardian.log
pause
