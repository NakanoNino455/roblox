# -*- coding: utf-8 -*-
"""小柒微信原生语音气泡（独立测试版）。默认只检查，不发送。"""
import argparse
import ctypes
import sys
import time
from pathlib import Path

import numpy as np
import sounddevice as sd
import soundfile as sf
from wechatauto import WeChatGUI

DEFAULT_WAV = Path(__file__).resolve().parent / 'private' / 'voice_test.wav'
VIRTUAL_CABLE_OUTPUT_DEVICE = 16  # CABLE Input (WASAPI)，取决于当前设备列表
USER32 = ctypes.windll.user32
VK_RMENU = 0xA5
SCAN_RALT = 0x38
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002


def current_chat(gui):
    uia = gui._get_uia()
    return uia.current_chat() if uia is not None else None


def assert_target(gui, target):
    hwnd = USER32.GetForegroundWindow()
    titlebuf = ctypes.create_unicode_buffer(256)
    USER32.GetWindowTextW(hwnd, titlebuf, len(titlebuf))
    if titlebuf.value != '微信':
        raise RuntimeError(f'当前活动窗口不是微信：{titlebuf.value!r}')
    name = current_chat(gui)
    if name is None or name != target:
        raise RuntimeError(f'聊天对象不匹配：期望 {target!r}，实际 {name!r}；已停止')
    return name


def load_wav(path):
    audio, rate = sf.read(str(path), dtype='float32', always_2d=True)
    if audio.size == 0 or rate <= 0:
        raise RuntimeError('无效或空白音频')
    mono = audio.mean(axis=1)
    count = int(round(len(mono) * 48000 / rate))
    resampled = np.interp(np.linspace(0, len(mono) - 1, count), np.arange(len(mono)), mono).astype('float32')
    return np.column_stack([resampled, resampled])


def send_voice(gui, target, audio):
    # 最终发送前重新检查，拒绝模糊匹配；不主动切换聊天
    assert_target(gui, target)
    print('确认目标：', target, '；开始录音并发送。', flush=True)
    pressed = False
    try:
        USER32.keybd_event(VK_RMENU, SCAN_RALT, KEYEVENTF_EXTENDEDKEY, 0)
        pressed = True
        time.sleep(0.7)
        sd.play(audio, 48000, device=VIRTUAL_CABLE_OUTPUT_DEVICE)
        sd.wait()
        time.sleep(0.5)
    finally:
        if pressed:
            USER32.keybd_event(VK_RMENU, SCAN_RALT, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0)
            time.sleep(0.1)
    print('已结束录音操作；请到微信确认语音气泡是否发出。')


def main():
    ap = argparse.ArgumentParser(description='小柒微信语音气泡：默认仅检查，--send 才发送')
    ap.add_argument('--target', required=True, help='精确微信聊天备注或群名')
    ap.add_argument('--wav', type=Path, default=DEFAULT_WAV)
    ap.add_argument('--send', action='store_true', help='明确允许自动发送一次语音')
    ap.add_argument('--open-target', action='store_true', help='发送前自动定位目标好友或群聊')
    ap.add_argument('--no-wait', action='store_true', help='由队列调用时跳过五秒等待')
    args = ap.parse_args()
    if not args.wav.is_file():
        raise FileNotFoundError(f'音频文件不存在: {args.wav}')
    audio = load_wav(args.wav)
    seconds = len(audio) / 48000
    if not 1 <= seconds <= 50:
        raise RuntimeError(f'安全限制：音频长度 {seconds:.1f} 秒，须为 1~50 秒')
    if not args.no_wait and not args.open_target:
        print('请在 5 秒内切换到目标微信聊天，期间不要切换其他会话。', flush=True)
        time.sleep(5)
    gui = WeChatGUI()
    if args.open_target:
        # open_chat() itself may accept loose matches: never trust its bool alone.
        if not gui.open_chat(args.target, exact=True):
            raise RuntimeError('无法打开目标会话：'+repr(args.target))
        time.sleep(0.4)
    assert_target(gui, args.target)
    print(f'严格名称校验通过：{args.target}，音频 {seconds:.2f} 秒。')
    if not args.send:
        print('当前为检查模式：没有按键、没有录音、没有发送。')
        print('需发送时由你明确加 --send；先仅在测试会话验证。')
        return
    send_voice(gui, args.target, audio)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print('用户已取消。', file=sys.stderr)
        sys.exit(130)
    except Exception as exc:
        print(f'停止：{type(exc).__name__}: {exc}', file=sys.stderr)
        sys.exit(1)
