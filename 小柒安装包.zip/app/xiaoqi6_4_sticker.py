# -*- coding: utf-8 -*-
"""小柒 6.4.3: 收藏表情前20格。支持微信 Qt 图标类主窗口，严格校验失败跳过。

默认关闭自动发送；TEST_SEND=1 时仅允许 test 群，且须自行在微信打开收藏面板。
AUTO_UI=1 时尝试自动展开面板；请先在 test 验证再用。
这不是微信开放 API，点击结果无法被本模块可靠回读验证。
"""
import ctypes
import json
import os
import random
import time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CFG = ROOT / 'xiaoqi_sticker_emotions.json'
STATE = ROOT / 'xiaoqi_sticker_state.json'
EXPECTED = (2560, 1600)
XS = (232, 363, 495, 627, 762)
YS = (835, 968, 1102, 1233)
# 根据用户截图人工初步归类，后续可修改 JSON；不保证每个图的实际情绪。
DEFAULT = {
 'enabled': False, 'test_only': True, 'allow_private': True,
 'cooldown_seconds': 180, 'chance': 0.23, 'sticker_only_chance': 0.18,
 'auto_open_panel': False,
 'slots': {'angry':[1,15], 'tease':[4,8,12], 'happy':[7,12,18],
           'shy':[2,11,13], 'surprise':[3,9,11], 'comfort':[13,16],
           'sad':[6,16,20], 'default':[2,3,11]}}

def config():
    if not CFG.exists():
        CFG.write_text(json.dumps(DEFAULT,ensure_ascii=False,indent=2),encoding='utf-8')
    try: data=json.loads(CFG.read_text(encoding='utf-8'))
    except (OSError, ValueError): return DEFAULT.copy()
    return {**DEFAULT, **data}

def mood(text):
    t=str(text)
    if any(x in t for x in ('难过','别哭','抱抱','心疼','辛苦啦','安慰')): return 'comfort'
    if any(x in t for x in ('哼','气死','不许','炸毛','生气','讨厌')): return 'angry'
    if any(x in t for x in ('害羞','脸红','喜欢你','么么','嘿嘿')): return 'shy'
    if any(x in t for x in ('？？','离谱','震惊','什么鬼','啊？')): return 'surprise'
    if any(x in t for x in ('哈哈','笑死','太好笑','好耶','开心','耶')): return 'happy'
    if any(x in t for x in ('呜呜','委屈','哭了','伤心')): return 'sad'
    if any(x in t for x in ('笨蛋','抓到','又来','嘴硬','调侃')): return 'tease'
    return 'default'

def _load_state():
    try:return json.loads(STATE.read_text(encoding='utf-8'))
    except (OSError, ValueError):return {}

def _save_state(data):
    tmp=STATE.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
    os.replace(tmp,STATE)

# Windows 64 位 HWND 必须按指针处理，避免 ctypes 默认 int 截断窗口句柄。
def _winapi(user32):
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowTextW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
    user32.GetClassNameW.argtypes = (wintypes.HWND, wintypes.LPWSTR, ctypes.c_int)
    user32.GetWindowThreadProcessId.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.DWORD))
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.GetWindowRect.argtypes = (wintypes.HWND, ctypes.POINTER(wintypes.RECT))
    user32.IsWindowVisible.argtypes = (wintypes.HWND,)
    user32.IsWindowVisible.restype = wintypes.BOOL
    return user32

def _window_info(user32, hwnd):
    if not hwnd:return ('', '')
    name=ctypes.create_unicode_buffer(256)
    cls=ctypes.create_unicode_buffer(256)
    user32.GetWindowTextW(hwnd,name,len(name))
    user32.GetClassNameW(hwnd,cls,len(cls))
    return name.value,cls.value

def _front_info(user32):
    _winapi(user32)
    return _window_info(user32,user32.GetForegroundWindow())

def _is_wechat_main(info):
    title,cls=info
    return cls=='mmui::MainWindow' and title in ('微信','Weixin','WeChat')

def _panel_visible(user32):
    """只承认与当前微信进程相同、处于已校准区域的可见表情弹窗。"""
    _winapi(user32)
    hwnd=user32.GetForegroundWindow()
    info=_window_info(user32,hwnd)
    if info[1]=='Qt51514QWindowToolSaveBits' and info[0] in ('Weixin','微信'):
        return True
    # 仅在前台为微信主窗口时枚举其进程内的弹窗；避免匹配其他程序。
    if not (_is_wechat_main(info) or (info[0] in ('微信','Weixin','WeChat') and info[1]=='Qt51514QWindowIcon' and _window_covers_button(user32,hwnd))):return False
    pid=wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
    if not pid.value:return False
    matches=[]
    CALLBACK=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    def visit(other,_):
        if other==hwnd or not user32.IsWindowVisible(other):return True
        if _window_info(user32,other)[1]!='Qt51514QWindowToolSaveBits':return True
        opid=wintypes.DWORD()
        user32.GetWindowThreadProcessId(other,ctypes.byref(opid))
        if opid.value!=pid.value:return True
        rect=wintypes.RECT()
        if not user32.GetWindowRect(other,ctypes.byref(rect)):return True
        # 校准截图中的收藏面板位于屏幕左下侧，允许合理范围偏差。
        if 50<=rect.left<=450 and 550<=rect.top<=1100 and 600<=rect.right<=1200 and 1200<=rect.bottom<=1580:
            matches.append(other)
        return True
    cb=CALLBACK(visit)
    user32.EnumWindows.argtypes=(CALLBACK,wintypes.LPARAM)
    user32.EnumWindows(cb,0)
    return bool(matches)

def _window_ok(user32):
    return _panel_visible(user32)

def _wait_panel(user32,timeout=1.5):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        if _panel_visible(user32):return True
        time.sleep(.1)
    return False

def _click(user32, x,y):
    if not user32.SetCursorPos(int(x),int(y)):return False
    time.sleep(.15)
    user32.mouse_event(0x0002,0,0,0,0)
    time.sleep(.07)
    user32.mouse_event(0x0004,0,0,0,0)
    return True

def _verify_recipient(wx, db, uid, name):
    # 独立核对微信群唯一映射/私聊联系人ID，由主程序提供已验证名称。
    gui=getattr(wx,'_gui',None)
    if not gui or gui._get_db() is not db:return False
    if not name or not gui.open_chat(name,exact=True):return False
    u=gui._get_uia()
    if not u:return False
    inp=u._chat_input()
    return bool(inp and inp.AutomationId=='chat_input_field' and inp.Name==name)

def _window_covers_button(user32, hwnd, x=495, y=1478):
    """Prevent clicks unless an actual large WeChat window covers the calibrated button."""
    if not hwnd:return False
    r=wintypes.RECT()
    if not user32.GetWindowRect(hwnd,ctypes.byref(r)):return False
    return (r.right-r.left>=1000 and r.bottom-r.top>=700 and
            r.left<=x<r.right and r.top<=y<r.bottom)

def _ensure_wechat_main_foreground(user32):
    """Support recent Weixin Qt main windows without blindly switching windows."""
    _winapi(user32)
    front=user32.GetForegroundWindow()
    title,cls=_window_info(user32,front)
    allowed_title=title in ('微信','Weixin','WeChat')
    allowed_class=cls in ('mmui::MainWindow','Qt51514QWindowIcon')
    if allowed_title and allowed_class and _window_covers_button(user32,front):
        print('收藏表情：已识别微信前台主窗口',repr((title,cls)),flush=True)
        return True
    print('收藏表情：前台窗口未通过标题/类型/尺寸检查',repr((title,cls)),flush=True)
    return False

def _prepare_panel(user32,cfg):
    if _window_ok(user32):return True
    if not cfg.get('auto_open_panel'):return False
    if not _ensure_wechat_main_foreground(user32):return False
    # 与 2560x1600 校准截图一致的按钮位置；未通过弹窗检测绝不点击表情格子。
    if not _click(user32,495,1478):return False
    if not _wait_panel(user32):
        print('收藏表情：点击笑脸后未检测到表情面板',flush=True)
        return False
    # 已打开表情弹窗后才切换收藏爱心页。
    if not _click(user32,347,1415):return False
    if not _wait_panel(user32):
        print('收藏表情：点击爱心后弹窗消失',flush=True)
        return False
    return True

def send_slot(wx,db,uid,name,slot,cfg=None):
    """返回 True 表示点击已执行，绝不表示微信已确认发送。"""
    cfg=cfg or config()
    if os.name!='nt': return False
    if cfg.get('test_only',True) and str(uid)!='48070338966@chatroom':return False
    if not 1<=int(slot)<=20:return False
    user32=ctypes.windll.user32
    try:ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except (AttributeError,OSError):pass
    if (user32.GetSystemMetrics(0),user32.GetSystemMetrics(1))!=EXPECTED:
        print('收藏表情跳过：屏幕尺寸变化',flush=True);return False
    if not _verify_recipient(wx,db,uid,name):
        print('收藏表情跳过：联系人/群对象校验失败',flush=True);return False
    if not _prepare_panel(user32,cfg):
        print('收藏表情跳过：收藏表情面板未展开；当前不自动盲点',flush=True);return False
    # 复查当前仍是表情弹窗，拒绝无关窗口。
    if not _window_ok(user32):return False
    r,c=divmod(slot-1,5)
    x,y=XS[c],YS[r]
    ok=_click(user32,x,y)
    print('收藏表情点击尝试',repr(name),'编号',slot,'已点击' if ok else '失败',flush=True)
    return ok

def plan(uid,kind,answer, cfg=None):
    cfg=cfg or config()
    if not cfg.get('enabled'):return None
    is_group=str(uid).endswith('@chatroom')
    if cfg['test_only'] and uid!='48070338966@chatroom':return None
    if not is_group and not cfg['allow_private']:return None
    if kind in ('news','weather','morning_group_news','media','link'):return None
    if random.random()>float(cfg['chance']):return None
    state=_load_state()
    if time.time()-float(state.get('last',{}).get(str(uid),0))<int(cfg['cooldown_seconds']):return None
    tag=mood(answer)
    slots=[int(s) for s in cfg['slots'].get(tag,[]) if str(s).isdigit() and 1<=int(s)<=20]
    if not slots:slots=cfg['slots'].get('default',[2])
    prev=state.get('last_slot',{}).get(str(uid))
    options=[s for s in slots if s!=prev] or slots
    return {'slot':random.choice(options),'mood':tag,
            'only':random.random()<float(cfg.get('sticker_only_chance',0))}

def commit(uid,slot):
    st=_load_state()
    st.setdefault('last',{})[str(uid)]=time.time()
    st.setdefault('last_slot',{})[str(uid)]=int(slot)
    _save_state(st)

def maybe_send_sticker(wx,db,uid,name,kind,answer,prepared=None):
    """仅在明确开关后尝试；返回 attempted click bool；失败不影响文字发送。"""
    cfg=config();item=prepared or plan(uid,kind,answer,cfg)
    if not item:return False
    try:
        ok=send_slot(wx,db,uid,name,item['slot'],cfg)
        if ok:commit(uid,item['slot'])
        return ok
    except Exception as exc:
        print('收藏表情功能异常，已跳过：',type(exc).__name__,str(exc)[:150],flush=True)
        return False

if __name__=='__main__':
    c=config()
    print('收藏表情配置文件：',CFG)
    print('当前只支持前20个槽位；自动发送默认关闭，必须先在test群单独验证。')
    print('情绪槽位：',c['slots'])
