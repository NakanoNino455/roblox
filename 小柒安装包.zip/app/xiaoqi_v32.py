"""小柒 V3.2：多好友私聊 AI 草稿 + 主动聊天模拟（绝不发送）。

运行: py -3.11 -u xiaoqi_v32.py
演示: py -3.11 xiaoqi_v32.py --demo  (无需微信/DeepSeek)
停止: Ctrl+C，或在同目录新建 STOP_XIAOQI 文件。
主动聊天仅限在 xiaoqi_v32_settings.json 中明确授权的微信用户 ID。
"""
import argparse
import hashlib
import json
import os
import sqlite3
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / 'config.json'
PERSONA = ROOT / 'persona.json'
SETTINGS = ROOT / 'xiaoqi_v32_settings.json'
STATE = ROOT / 'xiaoqi_v32_state.sqlite3'
STOP = ROOT / 'STOP_XIAOQI'
SYSTEM_IDS = {'filehelper', 'newsapp', 'fmessage', 'weixin', 'medianote'}
DEFAULT_SETTINGS = {
    'proactive_enabled': False,
    'consented_user_ids': [],
    'daily_proactive_limit_per_friend': 3,
    'cooldown_hours': 6,
    'quiet_hours_start': 23,
    'quiet_hours_end': 8,
    'minimum_hours_since_incoming': 2,
    'minimum_hours_known': 24,
    'check_interval_seconds': 30,
    'max_proactive_drafts_per_run': 3,
    'max_api_calls_per_run': 12,
    'generate_proactive_with_deepseek': False
}


def now_local():
    return datetime.now().astimezone()


def in_quiet_hour(hour, start, end):
    if start == end:
        return False
    return (start <= hour < end) if start < end else (hour >= start or hour < end)


def msg_key(message):
    fields = ('sort_seq', 'local_id', 'create_time', 'sender_id', 'content')
    return hashlib.sha256('|'.join(str(message.get(f, '')) for f in fields).encode('utf-8')).hexdigest()


def is_text(m):
    return m.get('type') in ('文本', 'text', 1) and bool(str(m.get('content') or '').strip())


def load_settings():
    if not SETTINGS.exists():
        SETTINGS.write_text(json.dumps(DEFAULT_SETTINGS, ensure_ascii=False, indent=2), encoding='utf-8')
    raw = json.loads(SETTINGS.read_text(encoding='utf-8-sig'))
    unknown = set(raw) - set(DEFAULT_SETTINGS)
    if unknown:
        raise ValueError('不支持的设置字段: ' + ','.join(sorted(unknown)))
    s = {**DEFAULT_SETTINGS, **raw}
    if type(s['proactive_enabled']) is not bool or type(s['generate_proactive_with_deepseek']) is not bool:
        raise ValueError('主动开关必须为 true/false')
    if not isinstance(s['consented_user_ids'], list) or not all(isinstance(x, str) and x.strip() for x in s['consented_user_ids']):
        raise ValueError('consented_user_ids 必须是微信 ID 字符串列表')
    s['consented_user_ids'] = list(dict.fromkeys(s['consented_user_ids']))
    numeric_limits = {'daily_proactive_limit_per_friend': (1, 3), 'cooldown_hours': (1, 48),
                      'quiet_hours_start': (0, 23), 'quiet_hours_end': (0, 23),
                      'minimum_hours_since_incoming': (1, 72), 'minimum_hours_known': (1, 720),
                      'check_interval_seconds': (10, 3600), 'max_proactive_drafts_per_run': (1, 20),
                      'max_api_calls_per_run': (1, 100)}
    for k, (lo, hi) in numeric_limits.items():
        if type(s[k]) is not int or not lo <= s[k] <= hi:
            raise ValueError(f'{k} 必须在 {lo}~{hi} 之间')
    return s


def get_chats(db):
    chats = {}
    for x in db.list_message_chats():
        uid = str(x.get('username') or '').strip()
        name = str(x.get('name') or '')
        if not uid or uid.lower() in SYSTEM_IDS or uid.endswith('@chatroom') or not name:
            continue
        try:
            matches = db.search_contact(name)
        except Exception as e:
            print('联系人检查失败，已跳过:', type(e).__name__, flush=True)
            continue
        if any(str(t.get('username') or '') == uid for t in matches):
            chats[uid] = name
    return chats


def init_state():
    conn = sqlite3.connect(STATE)
    conn.execute('CREATE TABLE IF NOT EXISTS inbound (chat TEXT, msg_key TEXT, status TEXT, PRIMARY KEY(chat,msg_key))')
    conn.execute('CREATE TABLE IF NOT EXISTS friends (chat TEXT PRIMARY KEY, first_seen TEXT NOT NULL, last_incoming TEXT)')
    conn.execute('''CREATE TABLE IF NOT EXISTS proactive_drafts (
        chat TEXT, day TEXT, slot INTEGER, created_at TEXT NOT NULL, text TEXT NOT NULL,
        PRIMARY KEY(chat,day,slot))''')
    conn.commit()
    return conn


def update_friend(conn, uid, timestamp, incoming=False):
    conn.execute('INSERT OR IGNORE INTO friends(chat,first_seen,last_incoming) VALUES (?,?,NULL)', (uid, timestamp))
    if incoming:
        conn.execute('UPDATE friends SET last_incoming=? WHERE chat=?', (timestamp, uid))
    conn.commit()


def why_not_proactive(conn, uid, s, now):
    if not s['proactive_enabled']:
        return '主动草稿开关关闭'
    if uid not in s['consented_user_ids']:
        return '好友尚未授权'
    if in_quiet_hour(now.hour, s['quiet_hours_start'], s['quiet_hours_end']):
        return '夜间免打扰'
    row = conn.execute('SELECT first_seen,last_incoming FROM friends WHERE chat=?', (uid,)).fetchone()
    if not row:
        return '未发现会话'
    first, incoming = (datetime.fromisoformat(x) if x else None for x in row)
    if now - first < timedelta(hours=s['minimum_hours_known']):
        return '新会话观察期'
    if incoming is None:
        return '尚无新收到的好友消息'
    if now - incoming < timedelta(hours=s['minimum_hours_since_incoming']):
        return '近期收到好友消息，暂不主动打扰'
    day = now.date().isoformat()
    count = conn.execute('SELECT COUNT(*) FROM proactive_drafts WHERE chat=? AND day=?', (uid, day)).fetchone()[0]
    if count >= s['daily_proactive_limit_per_friend']:
        return '今天已达到主动草稿上限'
    last = conn.execute('SELECT created_at FROM proactive_drafts WHERE chat=? ORDER BY created_at DESC LIMIT 1', (uid,)).fetchone()
    if last and now - datetime.fromisoformat(last[0]) < timedelta(hours=s['cooldown_hours']):
        return '主动草稿冷却中'
    return None


def demo():
    s = dict(DEFAULT_SETTINGS, proactive_enabled=True, consented_user_ids=['demo_friend'])
    now = datetime(2026, 10, 11, 14, 0).astimezone()
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE friends(chat TEXT PRIMARY KEY, first_seen TEXT, last_incoming TEXT)')
    c.execute('CREATE TABLE proactive_drafts(chat TEXT, day TEXT, slot INTEGER, created_at TEXT, text TEXT, PRIMARY KEY(chat,day,slot))')
    c.execute('INSERT INTO friends VALUES(?,?,?)', ('demo_friend',(now-timedelta(days=3)).isoformat(), (now-timedelta(hours=4)).isoformat()))
    assert why_not_proactive(c, 'demo_friend', s, now) is None
    c.execute('INSERT INTO proactive_drafts VALUES(?,?,?,?,?)', ('demo_friend',now.date().isoformat(),1,now.isoformat(),'模拟草稿'))
    assert why_not_proactive(c, 'demo_friend', s, now) == '主动草稿冷却中'
    assert why_not_proactive(c, 'not_consented', s, now) == '好友尚未授权'
    assert in_quiet_hour(0, 23, 8)
    assert not in_quiet_hour(14, 23, 8)
    print('安全模拟通过：授权校验、冷却、夜间免打扰、去重主键检查成功。')
    print('演示只使用虚构好友和内存数据库；未读取微信，未调用 DeepSeek，未发送消息。')
    c.close()


def main():
    cfg = json.loads(CONFIG.read_text(encoding='utf-8-sig'))
    persona = json.loads(PERSONA.read_text(encoding='utf-8-sig'))
    if cfg.get('reply_enabled') is not False or cfg.get('morning_enabled') is not False:
        raise RuntimeError('原程序的自动发送开关必须保持关闭')
    if STOP.exists():
        raise RuntimeError('检测到 STOP_XIAOQI 紧急停止文件；删除它之前不启动')
    s = load_settings()
    from wechatauto import WeChatDB  # 演示模式绝不导入微信库
    db = WeChatDB(account=cfg['db_account'])
    info = db.get_self_info()
    actual = (info.get('wxid') or info.get('username') or info.get('user_name') or '') if isinstance(info, dict) else ''
    if actual != cfg.get('approved_account_wxid') or info.get('nick_name') != '小柒':
        raise RuntimeError('当前微信数据库账号不是已授权的小柒，停止')
    ai = None
    if os.environ.get('DEEPSEEK_API_KEY'):
        from openai import OpenAI
        ai = OpenAI(api_key=os.environ['DEEPSEEK_API_KEY'], base_url='https://api.deepseek.com', timeout=35)
    system = ('你是微信上的AI虚拟角色小柒。' + json.dumps(persona, ensure_ascii=False)
              + '。简短自然，别装客服。明确自己是AI，不要冒充真人；不要提及其他好友的隐私。')
    conn = init_state()
    cursors = {}
    memories = defaultdict(lambda: deque(maxlen=12))
    last_inbound_draft = {}
    last_refresh = 0.0
    api_calls = 0
    proactive_count = 0
    interval = max(2.0, float(cfg.get('poll_seconds', 3)))
    print('小柒 V3.2 已启动：只读监听 + AI 草稿。无任何微信发送接口。', flush=True)
    print('主动草稿:', '开启' if s['proactive_enabled'] else '关闭（默认）', '授权人数:', len(s['consented_user_ids']), flush=True)
    print('最多每好友每天3条主动草稿；夜间免打扰；Ctrl+C 或创建 STOP_XIAOQI 停止。', flush=True)
    try:
        while True:
            if STOP.exists():
                print('检测到紧急停止文件，退出。', flush=True)
                break
            now = now_local()
            ticks = time.monotonic()
            if ticks-last_refresh > 10 or not cursors:
                chats = get_chats(db)
                for uid, name in chats.items():
                    if uid not in cursors:
                        recent = db.get_messages(uid, limit=int(cfg.get('initial_history_count', 15)))
                        cursors[uid] = max((int(x.get('sort_seq') or 0) for x in recent), default=0)
                        update_friend(conn, uid, now.isoformat())
                        print('发现私聊:', repr(name), '（跳过历史消息）', flush=True)
                for uid in list(cursors):
                    if uid not in chats:
                        del cursors[uid]
                last_refresh = ticks
            for uid, name in chats.items():
                if uid not in cursors:
                    continue
                try:
                    incoming = db.get_new_messages(uid, since_seq=cursors[uid], limit=50)
                except Exception as exc:
                    print('读取消息失败:', repr(name), type(exc).__name__, flush=True)
                    continue
                for m in sorted(incoming, key=lambda x: int(x.get('sort_seq') or 0)):
                    cursors[uid] = max(cursors[uid], int(m.get('sort_seq') or 0))
                    if str(m.get('sender_id')) == '2' or not is_text(m):
                        continue
                    key = msg_key(m)
                    if conn.execute('SELECT 1 FROM inbound WHERE chat=? AND msg_key=?', (uid,key)).fetchone():
                        continue
                    conn.execute('INSERT INTO inbound VALUES (?,?,?)', (uid,key,'observed'))
                    update_friend(conn, uid, now.isoformat(), incoming=True)
                    content = str(m.get('content') or '').strip()[:min(1200, int(cfg.get('max_message_chars',1200)))]
                    print('新消息:', repr(name), '预览:', repr(content[:80]), flush=True)
                    if ai is None or api_calls >= s['max_api_calls_per_run']:
                        print('跳过AI草稿：未配置密钥或达到本次API调用上限', flush=True)
                        continue
                    if ticks-last_inbound_draft.get(uid, -1e9) < max(5,float(cfg.get('cooldown_seconds',12))):
                        continue
                    try:
                        api_calls += 1
                        result = ai.chat.completions.create(model='deepseek-chat', messages=[{'role':'system','content':system}]+list(memories[uid])+[{'role':'user','content':content}], max_tokens=240,temperature=0.8)
                        reply = (result.choices[0].message.content or '').strip()
                        if not reply:
                            raise ValueError('空草稿')
                        memories[uid].extend([{'role':'user','content':content},{'role':'assistant','content':reply}])
                        conn.execute('UPDATE inbound SET status=? WHERE chat=? AND msg_key=?', ('drafted',uid,key))
                        conn.commit()
                        last_inbound_draft[uid] = time.monotonic()
                        print('小柒私聊回复草稿（不发送）:',repr(name),'→',reply, flush=True)
                    except Exception as exc:
                        conn.execute('UPDATE inbound SET status=? WHERE chat=? AND msg_key=?', ('error',uid,key))
                        conn.commit()
                        print('回复草稿生成失败:',type(exc).__name__,str(exc)[:150],flush=True)
            # 主动聊天：只针对明确同意的 ID，每次循环重新核验设置和停止开关。
            s = load_settings()
            if s['proactive_enabled'] and proactive_count < s['max_proactive_drafts_per_run'] and not STOP.exists():
                for uid, name in chats.items():
                    if STOP.exists() or proactive_count >= s['max_proactive_drafts_per_run']:
                        break
                    if why_not_proactive(conn, uid, s, now) is not None:
                        continue
                    if uid not in s['consented_user_ids']:
                        continue
                    if s['generate_proactive_with_deepseek'] and ai and api_calls < s['max_api_calls_per_run']:
                        try:
                            api_calls += 1
                            result = ai.chat.completions.create(model='deepseek-chat',messages=[{'role':'system','content':system+'请为已同意主动联系的好友写一句自然的主动问候，不催促、不索取信息、不暗示线下真实经历。' }]+list(memories[uid])+[{'role':'user','content':'为这位好友写一条自然主动聊天草稿。'}],max_tokens=120)
                            text = (result.choices[0].message.content or '').strip()
                        except Exception as exc:
                            print('主动草稿生成失败:',type(exc).__name__,flush=True)
                            continue
                    else:
                        text = '嘿～今天过得怎么样呀？有空的话聊聊最近喜欢的动漫或者游戏？（模拟草稿）'
                    if not text:
                        continue
                    count = conn.execute('SELECT COUNT(*) FROM proactive_drafts WHERE chat=? AND day=?',(uid,now.date().isoformat())).fetchone()[0]
                    try:
                        conn.execute('INSERT INTO proactive_drafts VALUES (?,?,?,?,?)',(uid,now.date().isoformat(),count+1,now.isoformat(),text))
                        conn.commit()
                    except sqlite3.IntegrityError:
                        continue
                    proactive_count += 1
                    print('小柒主动聊天草稿（绝不发送）:',repr(name),'→',text, flush=True)
            time.sleep(interval)
    except KeyboardInterrupt:
        print('已通过 Ctrl+C 停止。', flush=True)
    finally:
        conn.close()
        print('程序退出：没有向任何微信好友发送消息。', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='小柒V3.2草稿安全模拟')
    parser.add_argument('--demo', action='store_true', help='离线模拟授权/冷却/免打扰（无微信、无API）')
    args = parser.parse_args()
    demo() if args.demo else main()
