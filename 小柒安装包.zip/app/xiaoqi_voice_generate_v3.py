# -*- coding: utf-8 -*-
"""小柒 CosyVoice2 情绪语音测试（独立文件，不覆盖现有脚本）。"""
import argparse
import sys
import os
from pathlib import Path

import soundfile as sf
import torch

ROOT = Path(os.environ.get('XIAOQI_COSY_ROOT', str(Path(__file__).resolve().parent / 'third_party' / 'CosyVoice')))
PROJECT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(PROJECT))
from cosyvoice.cli.cosyvoice import CosyVoice2

STYLES = {
    'playful': '请用活泼、俏皮、带一点撒娇的年轻女生语气说话，语调自然灵动，不要夸张。',
    'happy': '请用开心、轻快、真诚的年轻女生语气说话，自然带着笑意。',
    'gentle': '请用温柔、亲近、柔和的年轻女生语气说话，语速舒缓，停顿自然。',
    'calm': '请用自然、放松、像朋友聊天一样的年轻女生语气说话，不要播音腔。',
}

def main():
    parser = argparse.ArgumentParser(description='测试小柒 CosyVoice2 情绪语音')
    parser.add_argument('--text', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--mode', choices=['original', 'emotion'], default='emotion',
                        help='original=保留原有合成方式；emotion=尝试指令式情绪表达')
    parser.add_argument('--style', choices=tuple(STYLES), default='playful')
    parser.add_argument('--speed', type=float, default=1.0)
    args = parser.parse_args()
    if not (1 <= len(args.text.strip()) <= 160):
        parser.error('text 长度必须为 1～160 字符')
    if not (0.85 <= args.speed <= 1.15):
        parser.error('speed 请保持在 0.85～1.15，避免声音失真')

    ref_path = Path(os.environ.get('XIAOQI_REFERENCE_WAV', str(PROJECT / 'private' / 'reference.wav')))
    audio, sample_rate = sf.read(str(ref_path), dtype='float32', always_2d=True)
    if sample_rate != 16000:
        raise ValueError('参考音频必须为 16000 Hz')
    reference = torch.from_numpy(audio.mean(axis=1).copy()).unsqueeze(0)

    model = CosyVoice2(os.environ.get('XIAOQI_COSY_MODEL', str(PROJECT / 'CosyVoice2-0.5B')), load_jit=False,
                       load_trt=False, load_vllm=False, fp16=False)
    model.model.llm.float()
    if args.mode == 'emotion':
        if not hasattr(model, 'inference_instruct2'):
            raise RuntimeError('当前 CosyVoice2 版本不支持 inference_instruct2，请用 --mode original')
        parts = model.inference_instruct2(args.text, STYLES[args.style], reference,
                                         stream=False, speed=args.speed, text_frontend=False)
    else:
        parts = model.inference_cross_lingual(args.text, reference,
                                             stream=False, speed=args.speed, text_frontend=False)

    chunks = [part['tts_speech'].detach().cpu() for part in parts if 'tts_speech' in part]
    if not chunks:
        raise RuntimeError('没有生成语音')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(args.out), torch.cat(chunks, dim=-1).squeeze().numpy(), model.sample_rate)
    print('VOICE_WAV', str(args.out), flush=True)

if __name__ == '__main__':
    main()
