# -*- coding: utf-8 -*-
"""安装 Seed-VC 依赖到既有独立唱歌虚拟环境，不触碰小柒 V4.1。"""
from __future__ import annotations
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent
PY=PROJECT/'xiaoqi_singing_env'/'Scripts'/'python.exe'
SEED=HERE/'third_party'/'seed-vc'
URL='https://codeload.github.com/Plachtaa/seed-vc/zip/refs/heads/main'

def say(s): print(s, flush=True)

def call(args, cwd=None):
    cmd=[str(x) for x in args]
    say('执行: '+Path(cmd[0]).name+' '+(' '.join(cmd[1:3])))
    n=subprocess.call(cmd, cwd=cwd)
    if n: raise RuntimeError(f'操作失败，返回码 {n}。请拍摄该窗口末尾报错。')

def ensure_venv():
    if not PY.is_file():
        say('[1/5] 建立隔离环境')
        call(['py','-3.11','-m','venv',PROJECT/'xiaoqi_singing_env'])
    else:
        say('[1/5] 复用现有 xiaoqi_singing_env')

def ensure_source():
    if (SEED/'inference.py').is_file():
        say('[2/5] Seed-VC 源码已存在，跳过下载')
        return
    say('[2/5] 获取 Seed-VC 官方公开源码。如果 GitHub 无法访问，此步骤会提示错误。')
    SEED.parent.mkdir(exist_ok=True,parents=True)
    with tempfile.TemporaryDirectory(prefix='xiaoqi_source_') as td:
        zpath=Path(td)/'seedvc.zip'
        req=urllib.request.Request(URL,headers={'User-Agent':'XiaoqiSingingInstaller/1.0'})
        with urllib.request.urlopen(req,timeout=90) as r, open(zpath,'wb') as out:
            shutil.copyfileobj(r,out)
        with zipfile.ZipFile(zpath) as z:
            root=Path(td)/'unpacked'
            root.mkdir()
            # 安全提取归档，拒绝路径穿越
            for item in z.infolist():
                dest=(root/item.filename).resolve()
                if not dest.is_relative_to(root.resolve()):
                    raise RuntimeError('下载包包含危险路径，已拒绝解压。')
            z.extractall(root)
        dirs=[p for p in root.iterdir() if (p/'inference.py').is_file()]
        if len(dirs)!=1: raise RuntimeError('Seed-VC 包结构不符合预期。')
        shutil.move(str(dirs[0]),str(SEED))
    say('源码准备完成。')

def installed_gpu_torch():
    proc=subprocess.run([str(PY),'-c',
                         'import torch,torchaudio,torchvision;print("PyTorch:",torch.__version__,"CUDA:",torch.cuda.is_available())'],
                         capture_output=True,text=True,errors='replace')
    if proc.returncode==0:
        say(proc.stdout.strip())
    return proc.returncode==0 and 'CUDA: True' in proc.stdout

def main():
    if not (PROJECT/'xiaoqi_voice_sender_auto_v2.py').is_file():
        say('提示：尚未找到原微信语音脚本，生成歌曲仍可进行，但发送需放在正确项目目录。')
    ensure_venv()
    say('[2/5] 检查 CUDA 环境')
    if not installed_gpu_torch():
        say('安装 CUDA 12.8 版本 PyTorch（下载较大，仅对独立环境生效）。')
        call([PY,'-m','pip','install','--upgrade','torch','torchaudio','torchvision',
              '--index-url','https://download.pytorch.org/whl/cu128'])
        if not installed_gpu_torch():
            raise RuntimeError('PyTorch 尚不能识别 NVIDIA CUDA 显卡。先不要运行转换。')
    ensure_source()
    say('[3/5] 安装 Seed-VC 推理所需依赖 + 人声分离工具。')
    call([PY,'-m','pip','install','-r',HERE/'requirements_singing.txt'])
    if not installed_gpu_torch():
        raise RuntimeError('依赖安装后 CUDA 版本 PyTorch 不可用；请提供日志以修复依赖冲突。')
    say('[4/5] 检查必要模块')
    call([PY,'-c','import torch, torchaudio, numpy, librosa, transformers, demucs, soundfile, huggingface_hub;print("Python modules ready; CUDA:",torch.cuda.is_available())'])
    (HERE / '.setup_complete').write_text('Installed. Model checkpoints download on first inference.\n', encoding='utf-8')
    say('[5/5] 安装结束。第一次翻唱还需要下载 Seed-VC 和 Demucs 官方模型；请准备自己的合法歌曲素材。')
    say('请双击「启动_小柒唱歌.bat」进入图形界面。')

if __name__=='__main__':
    try: main()
    except Exception as e:
        print('\n安装未全部完成：'+str(e),file=sys.stderr)
        print('不要反复重装已有的 V4.1；保存本窗口错误供定位。',file=sys.stderr)
        sys.exit(1)
