# -*- coding: utf-8 -*-
"""V4.1 后续接入用：只负责识别指令和启动独立歌声子进程，不修改任何主程序文件。"""
from __future__ import annotations
import re
import os
import subprocess
from pathlib import Path
from singing_core import HERE, ENV_PY, choose_song

OWNER=os.environ.get('XIAOQI_OWNER_NICKNAME','')
_running=None

def parse_singing_request(text):
    """识别聊天点歌；返回歌名、空串(随机选歌)，非点歌返回 None。"""
    if not isinstance(text,str):return None
    clean=text.strip()
    if len(clean)>100:return None
    # 指令须包含唱歌动作，以免把普通歌曲讨论误判为点歌
    if not any(x in clean for x in ('唱歌','唱首','唱一首','唱一下','翻唱','点歌','唱《','唱「','唱“')):
        return None
    quote=re.search(r'[《「“](.+?)[》」”]',clean)
    if quote:return quote.group(1).strip()
    m=re.search(r'(?:唱一下|唱一首|唱首|翻唱|点歌)[\s:：]*(.+?)(?:给我听|听听|吧|呀|好吗|可以吗|！|!|。|$)',clean)
    if m:
        title=m.group(1).strip(' ，,：:')
        if title and title not in ('歌','歌曲','好听的歌','一首歌','首歌'):
            return title
    return ''

def start_singing_for_owner(text, sender, *, dry_run=True):
    """返回 (已识别,文字反馈)。默认不会发送；只能对指定主人启动。"""
    global _running
    name=parse_singing_request(text)
    if name is None:return False,''
    if not OWNER or sender!=OWNER:return True,'小柒的唱歌功能目前只开放给主人。'
    try:
        song=choose_song(name)
    except Exception as e:
        return True,str(e)
    if _running is not None and _running.poll() is None:
        return True,'小柒还在唱上一首歌，等我唱完嘛～'
    if dry_run:
        return True,f'识别到点歌：《{song.stem}》。当前为安全测试模式，没有生成或发送。'
    # 必须由 V4.1 显式选择 dry_run=False 后才可自动处理；原文件默认不会开启。
    _running=subprocess.Popen([str(ENV_PY),str(HERE/'singing_core.py'),
                              '--song',song.stem,'--send','--recipient',OWNER],cwd=HERE,
                             creationflags=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0))
    return True,f'好耶！小柒开始准备《{song.stem}》啦，唱好后试着发给主人～'
