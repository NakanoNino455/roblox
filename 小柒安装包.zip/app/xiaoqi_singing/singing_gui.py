# -*- coding: utf-8 -*-
"""一窗口选择歌曲、随机点歌、生成预览、微信发送；模型按需在子进程运行。"""
from pathlib import Path
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from singing_core import HERE, PROJECT, SONGS, RESULTS, ENV_PY, audio_files

class App:
    def __init__(self, root):
        self.root=root
        root.title('小柒 · AI 翻唱（实验版）')
        root.geometry('760x560')
        root.minsize(670,500)
        self.song=tk.StringVar()
        self.target=tk.StringVar(value='主人')
        self.seconds=tk.StringVar(value='38')
        self.start_at=tk.StringVar(value='0')
        self.mirror=tk.BooleanVar(value=False)
        frame=ttk.Frame(root,padding=14)
        frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='小柒 · AI 翻唱',font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w')
        ttk.Label(frame,text='只处理歌曲库中你有权使用的音源。首次需要下载歌声模型；转换时占显存，完成后自动释放。',wraplength=720).pack(anchor='w',pady=(4,8))
        bar=ttk.Frame(frame);bar.pack(fill='x')
        ttk.Label(bar,text='歌曲：').pack(side='left')
        self.combo=ttk.Combobox(bar,textvariable=self.song,width=45)
        self.combo.pack(side='left',fill='x',expand=True,padx=(5,5))
        ttk.Button(bar,text='刷新',command=self.refresh).pack(side='left')
        ttk.Button(bar,text='导入歌曲',command=self.import_song).pack(side='left',padx=(5,0))
        ttk.Button(bar,text='在线曲库',command=self.open_library).pack(side='left',padx=(5,0))
        sett=ttk.Frame(frame);sett.pack(fill='x',pady=9)
        ttk.Label(sett,text='片段秒数（1～38）：').pack(side='left')
        ttk.Entry(sett,textvariable=self.seconds,width=5).pack(side='left')
        ttk.Label(sett,text='从第几秒开始：').pack(side='left',padx=(12,5))
        ttk.Entry(sett,textvariable=self.start_at,width=5).pack(side='left')
        ttk.Label(sett,text='微信接收人：').pack(side='left',padx=(20,5))
        ttk.Entry(sett,textvariable=self.target,width=17).pack(side='left')
        ttk.Checkbutton(frame,text='首次模型下载使用国内 Hugging Face 镜像（第三方服务）',variable=self.mirror).pack(anchor='w')
        actions=ttk.Frame(frame);actions.pack(fill='x',pady=12)
        self.preview=ttk.Button(actions,text='随机唱一首',command=lambda:self.start(random_mode=True,send=False));self.preview.pack(side='left')
        self.preview2=ttk.Button(actions,text='生成指定歌曲',command=lambda:self.start(random_mode=False,send=False));self.preview2.pack(side='left',padx=(7,0))
        self.send=ttk.Button(actions,text='生成并发给微信（确认后发送）',command=lambda:self.start(random_mode=False,send=True));self.send.pack(side='left',padx=(7,0))
        ttk.Label(frame,text='运行日志（失败时复制这里最后几行即可）').pack(anchor='w')
        self.log=tk.Text(frame,wrap='word',height=15,font=('Consolas',10))
        self.log.pack(fill='both',expand=True)
        ttk.Button(frame,text='打开生成结果文件夹',command=lambda: subprocess.Popen(['explorer',str(RESULTS)])).pack(anchor='e',pady=5)
        self.busy=False
        self.refresh()
        self.write('工具包只会读取原小柒脚本，不会覆盖 V4.1。\n如需按微信聊天指令自动点歌，需要把桥接模块接入 V4.1 的消息处理入口。\n')

    def open_library(self):
        from singing_library import show_library
        show_library(self.root,self.refresh)

    def refresh(self):
        names=[p.stem for p in audio_files()]
        self.combo['values']=names
        if not self.song.get() and names: self.song.set(names[0])

    def import_song(self):
        files=filedialog.askopenfilenames(title='选择有权使用的演唱音频',filetypes=[('音频','*.mp3 *.wav *.flac *.m4a *.ogg')])
        if not files:return
        import shutil
        SONGS.mkdir(exist_ok=True)
        for f in files:
            src=Path(f);dst=SONGS/src.name
            if src.resolve()==dst.resolve():continue
            if dst.exists():
                messagebox.showwarning('同名文件','歌曲库已有 '+dst.name+'，跳过。');continue
            shutil.copy2(src,dst)
        self.refresh()
        self.write('已导入歌曲。\n')

    def write(self,txt):
        self.log.insert('end',txt);self.log.see('end')

    def start(self,random_mode,send):
        if self.busy:
            messagebox.showinfo('处理中','上一首歌曲还在处理，请稍候。');return
        try:
            seconds=float(self.seconds.get())
            start_at=float(self.start_at.get())
            assert 1<=seconds<=38 and start_at>=0
        except Exception:
            messagebox.showerror('输入有误','长度必须在 1～38 秒。');return
        song='' if random_mode else self.song.get().strip()
        if not random_mode and not song:
            messagebox.showerror('缺少歌曲','请先从歌曲库选择歌曲。');return
        target=self.target.get().strip()
        if send and not target:
            messagebox.showerror('缺少接收人','请输入准确微信聊天名称。');return
        if send and not messagebox.askyesno('确认发送',f'确认在小柒账号已登录电脑微信时，生成歌曲并向「{target}」发送一条语音气泡？\n\n原发送脚本依赖微信窗口与虚拟声卡配置，无法保证每次成功。'):
            return
        cmd=[str(ENV_PY),'singing_core.py','--seconds',str(seconds),'--start',str(start_at)]
        if song:cmd+=['--song',song]
        if send:cmd+=['--send','--recipient',target]
        self.busy=True
        for btn in (self.preview,self.preview2,self.send):btn.configure(state='disabled')
        self.write('\n—— 开始执行（可能需要较长时间）——\n')
        env=None
        if self.mirror.get():
            import os
            env=os.environ.copy();env['HF_ENDPOINT']='https://hf-mirror.com'
        def worker():
            try:
                p=subprocess.Popen(cmd,cwd=str(HERE),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                   encoding='utf-8',errors='replace',bufsize=1,env=env)
                for ln in p.stdout:
                    self.root.after(0,lambda s=ln:self.write(s))
                code=p.wait()
                self.root.after(0,lambda:self.write('完成。\n' if code==0 else f'执行失败，退出码 {code}。请提供上方日志。\n'))
            except Exception as exc:
                self.root.after(0,lambda s=str(exc):self.write('运行失败：'+s+'\n'))
            finally:
                def reset():
                    self.busy=False
                    for b in (self.preview,self.preview2,self.send):b.configure(state='normal')
                self.root.after(0,reset)
        threading.Thread(target=worker,daemon=True).start()

if __name__=='__main__':
    root=tk.Tk();App(root);root.mainloop()
