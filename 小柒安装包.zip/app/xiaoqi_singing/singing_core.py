# -*- coding: utf-8 -*-
"""小柒演唱实验版：合法本地音源 -> 人声分离 -> Seed-VC 零样本音色转换 -> 音频预览/微信语音气泡。"""
from __future__ import annotations

import argparse
import datetime
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
SONGS = HERE / 'songs'
RESULTS = HERE / 'results'
SEED = HERE / 'third_party' / 'seed-vc'
ENV_PY = PROJECT / 'xiaoqi_singing_env' / 'Scripts' / 'python.exe'
SOURCE_SUFFIXES = {'.wav', '.flac', '.mp3', '.m4a', '.ogg'}
MAX_CLIP = 38


def line(s):
    print(s, flush=True)


def ffmpeg_exe():
    # 项目原本已有 FFmpeg；不修改系统 PATH
    for f in (PROJECT / 'ffmpeg.exe', HERE / 'ffmpeg.exe'):
        if f.is_file():
            return str(f)
    exe = shutil.which('ffmpeg')
    if exe:
        return exe
    raise RuntimeError('没有找到 ffmpeg.exe。请将工具包解压到小柒项目目录内。')


def run(command, *, cwd=None, timeout=3600, env=None):
    line('正在执行：' + str(Path(command[0]).name) + (' ' + ' '.join(map(str, command[1:4])) if len(command)>1 else ''))
    runtime_env = (env or os.environ.copy()).copy()
    runtime_env['PATH'] = str(PROJECT) + os.pathsep + runtime_env.get('PATH', '')
    try:
        p = subprocess.run([str(x) for x in command], cwd=cwd, env=runtime_env, timeout=timeout)
    except subprocess.TimeoutExpired as e:
        raise RuntimeError('处理超时，请查看上方输出或改用较短的歌曲片段。') from e
    if p.returncode != 0:
        raise RuntimeError(f'子程序退出码 {p.returncode}，请保留窗口日志。')


def audio_files():
    SONGS.mkdir(parents=True, exist_ok=True)
    # 只读取 songs 下的内容，无网络搜索/下载
    return sorted((p for p in SONGS.iterdir() if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES), key=lambda p: p.name.casefold())


def normalized(s):
    return re.sub(r'[^\w\u4e00-\u9fff]+', '', s, flags=re.UNICODE).casefold()


def choose_song(name=None):
    files = audio_files()
    if not files:
        raise RuntimeError('歌曲库为空。请将你有权使用的演唱音频 MP3/WAV 放入 xiaoqi_singing\\songs。')
    if not name or normalized(name) in {'随机', '随便', '来一首', '唱首歌', '唱一首歌'}:
        picked = random.choice(files)
        line('小柒随机选歌：' + picked.stem)
        return picked
    key = normalized(name)
    exact = [p for p in files if normalized(p.stem) == key]
    matches = exact or [p for p in files if key in normalized(p.stem)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise RuntimeError('歌名匹配到多首，请输入更完整的歌曲名称：' + '、'.join(p.stem for p in matches[:10]))
    raise RuntimeError(f'本地还没有《{name}》的演唱素材，不能凭歌名凭空翻唱。请先添加有权使用的音源。')


def voice_reference():
    candidates = [PROJECT / 'xiaoqi_reference_16k.wav',
                  Path(r'C:\Users\YOUR_USERNAME\Desktop\CosyVoice\QwenAudio-CosyVoice-8555549\xiaoqi_reference_16k.wav')]
    for p in candidates:
        if p.is_file():
            return p
    raise RuntimeError('没找到小柒参考音频 xiaoqi_reference_16k.wav。')


def media_duration(path):
    # 用 Python 标准库通过 ffmpeg 的 stderr 提取时长，避免依赖 ffprobe
    p = subprocess.run([ffmpeg_exe(), '-hide_banner', '-i', str(path)], capture_output=True, text=True, errors='replace')
    m = re.search(r'Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)', p.stderr)
    if not m:
        raise RuntimeError('无法识别音频时长：' + path.name)
    return int(m.group(1))*3600 + int(m.group(2))*60 + float(m.group(3))


def cut_audio(src, out, duration, start=0):
    run([ffmpeg_exe(), '-y', '-hide_banner', '-loglevel', 'error', '-ss', str(start), '-i', src,
         '-t', str(duration), '-vn', '-ac', '2', '-ar', '44100', out], timeout=300)
    if not out.is_file() or out.stat().st_size < 1000:
        raise RuntimeError('剪裁后的音频为空。')


def get_vocals(input_path, job_dir, raw_vocals):
    if '_vocals' in input_path.stem.lower() or input_path.stem.lower().endswith('人声'):
        line('发现已分离的人声素材，跳过伴奏分离。')
        return raw_vocals, None
    line('开始使用 Demucs 分离人声与伴奏（第一次可能自动下载模型）。')
    d_out = job_dir / 'separated'
    run([ENV_PY, '-m', 'demucs', '--two-stems=vocals', '-n', 'htdemucs',
         '--device', 'cuda', '-o', d_out, raw_vocals], timeout=1800)
    # htdemucs 输出目录下，以截取文件名为目录
    base = d_out / 'htdemucs' / raw_vocals.stem
    v = base / 'vocals.wav'
    bgm = base / 'no_vocals.wav'
    if not v.exists() or not bgm.exists():
        raise RuntimeError('Demucs 没有生成预期的人声文件，请检查日志。')
    return v, bgm


def convert_voice(vocals, reference, job_dir):
    if not (SEED / 'inference.py').is_file():
        raise RuntimeError('尚未安装 Seed-VC，请先双击「安装_小柒唱歌.bat」。')
    out_dir = job_dir / 'seed_out'
    out_dir.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    # 国内 Hugging Face 镜像可由用户在外部设置 HF_ENDPOINT；不用擅自替换来源。
    env['PYTHONUTF8'] = '1'
    # 避免非必要的 HF checkpoint 在不正确目录反复下载
    line('正在把歌声转换为小柒音色；首次可能自动下载官方模型，时间较长。')
    run([ENV_PY, 'inference.py', '--source', vocals, '--target', reference,
         '--output', out_dir, '--diffusion-steps', '24', '--f0-condition', 'True',
         '--auto-f0-adjust', 'False', '--fp16', 'True'], cwd=SEED, timeout=3600, env=env)
    produced = list(out_dir.glob('vc_*.wav'))
    if not produced:
        raise RuntimeError('Seed-VC 完成后未找到输出 WAV 文件，请检查模型下载日志。')
    return max(produced, key=lambda p: p.stat().st_mtime)


def build_mix(converted, bgm, destination):
    destination.parent.mkdir(exist_ok=True, parents=True)
    if bgm is not None:
        filter_complex = '[0:a]volume=1.15[v];[1:a]volume=0.65[b];[v][b]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0[out]'
        run([ffmpeg_exe(), '-y', '-hide_banner', '-loglevel', 'error', '-i', converted, '-i', bgm,
             '-filter_complex', filter_complex, '-map', '[out]', '-ar', '48000', '-ac', '2', destination], timeout=300)
    else:
        run([ffmpeg_exe(), '-y', '-hide_banner', '-loglevel', 'error', '-i', converted,
             '-ar', '48000', '-ac', '2', destination], timeout=300)
    if not destination.is_file() or destination.stat().st_size < 1000:
        raise RuntimeError('合成歌曲输出为空。')


def send_voice(song_wav, target):
    sender = PROJECT / 'xiaoqi_voice_sender_auto_v2.py'
    if not sender.is_file():
        raise RuntimeError('找不到现有微信语音发送脚本：xiaoqi_voice_sender_auto_v2.py')
    # 发送脚本本身会要求微信界面存在且当前聊天对象与目标完全匹配。
    if media_duration(song_wav) > 50:
        raise RuntimeError('微信发送脚本只允许 1～50 秒，当前歌曲太长。')
    line('正在尝试向微信聊天 ' + target + ' 发送一条语音气泡。')
    run(['py', '-3.11', sender, '--target', target, '--wav', song_wav, '--open-target', '--no-wait', '--send'], cwd=PROJECT, timeout=180)
    line('发送脚本已执行；请在微信里确认气泡是否真正发出。')


def create(song_name=None, *, send=False, recipient='主人', seconds=38, start=0):
    song = choose_song(song_name)
    reference = voice_reference()
    total = media_duration(song)
    if start < 0 or start >= total:
        raise RuntimeError('起始秒数必须在歌曲时长以内。')
    duration = min(float(seconds), MAX_CLIP, total-start)
    if duration < 1:
        raise RuntimeError('可用歌曲片段不足 1 秒。')
    stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    safe_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', song.stem)[:45]
    RESULTS.mkdir(parents=True, exist_ok=True)
    output = RESULTS / f'{stamp}_{safe_name}_小柒翻唱.wav'
    line(f'选中歌曲：{song.name}；从 {start} 秒开始，处理 {duration:.1f} 秒。')
    # 临时文件自动清理，显卡模型随子进程结束退出
    with tempfile.TemporaryDirectory(prefix='xiaoqi_sing_', dir=str(HERE)) as td:
        work = Path(td)
        clip = work / 'source_clip.wav'
        cut_audio(song, clip, duration, start=start)
        vocals, instrumental = get_vocals(song, work, clip)
        converted = convert_voice(vocals, reference, work)
        build_mix(converted, instrumental, output)
    line('已生成：' + str(output))
    if send:
        send_voice(output, recipient)
    return output


def main(argv=None):
    p = argparse.ArgumentParser(description='小柒 AI 翻唱：本地歌曲 -> 零样本转换 -> 可选语音发送')
    p.add_argument('--song', default='', help='本地歌曲名；不填写则随机选歌')
    p.add_argument('--seconds', type=float, default=38, help='长度，最多 38 秒；现有微信气泡脚本限制 50 秒')
    p.add_argument('--start', type=float, default=0, help='从歌曲第几秒开始')
    p.add_argument('--send', action='store_true', help='明确同意发送到微信（默认仅生成文件）')
    p.add_argument('--recipient', default='主人', help='精确匹配微信聊天名')
    p.add_argument('--list', action='store_true', help='列出本地歌曲')
    args = p.parse_args(argv)
    if args.list:
        songs = audio_files()
        line('本地歌曲：' + ('\n'.join(' • '+p.name for p in songs) if songs else '空'))
        return 0
    if not (1 <= args.seconds <= MAX_CLIP):
        p.error(f'--seconds 须为 1～{MAX_CLIP}')
    create(args.song, send=args.send, recipient=args.recipient, seconds=args.seconds, start=args.start)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        line('用户已取消。')
        sys.exit(130)
    except Exception as exc:
        print('小柒翻唱出错：' + str(exc), file=sys.stderr, flush=True)
        sys.exit(1)
