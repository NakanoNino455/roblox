# -*- coding: utf-8 -*-

"""Xiaoqi song registry + Seed-VC conversion runner.



Independent of the WeChat V4.1 project. Standard-library only in controller.

"""

from __future__ import annotations

import json

import os

import re

import shutil

import subprocess

import sys

import time

import uuid

from datetime import datetime

from pathlib import Path



HERE = Path(__file__).resolve().parent

SONGS = HERE / 'songs.json'

STORE = HERE / 'sources'

OUT = HERE / 'outputs'

LOG = HERE / 'logs'

REQUIREMENTS = HERE / 'requirements_seedvc.txt'



class SetupError(RuntimeError): pass



def project_path():

    """Expected location: <project>/xiaoqi_singing/xiaoqi_songstudio."""

    if HERE.parent.name.lower() == 'xiaoqi_singing':

        return HERE.parent.parent

    return HERE.parent



def seed_path():

    base = project_path() / 'xiaoqi_singing' / 'third_party' / 'seed-vc'

    if (base / 'inference.py').exists():

        return base

    # Also support when the bundle is directly under xiaoqi_singing.

    other = HERE.parent / 'third_party' / 'seed-vc'

    return other if (other / 'inference.py').exists() else base



def cozy_python():

    return project_path() / 'cosyvoice_env' / 'Scripts' / 'python.exe'



def converter_python():

    return project_path() / 'xiaoqi_seedvc_env' / 'Scripts' / 'python.exe'



def environment():

    env = os.environ.copy()

    extra = project_path() / 'cosyvoice_env' / 'Lib' / 'site-packages'

    env['PYTHONPATH'] = str(extra) + (os.pathsep + env['PYTHONPATH'] if env.get('PYTHONPATH') else '')

    # Repo-recommended alternative for mainland China. Not guaranteed reachable.

    env.setdefault('HF_ENDPOINT', 'https://hf-mirror.com')

    env.setdefault('HF_HUB_DISABLE_TELEMETRY', '1')

    env['PYTHONUTF8'] = '1'

    return env



def clean_name(value: str) -> str:

    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', value).strip('. ')

    return value[:80] or 'song'



def songs_read():

    if not SONGS.exists():

        return []

    obj = json.loads(SONGS.read_text(encoding='utf-8'))

    return obj if isinstance(obj, list) else []



def songs_write(items):

    SONGS.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding='utf-8')



def add_song(title, artist, source_file):

    source_file = Path(source_file).expanduser().resolve()

    if source_file.suffix.lower() not in {'.wav', '.flac', '.mp3', '.ogg', '.m4a'}:

        raise ValueError('需要清唱音频 WAV / FLAC / MP3 / OGG / M4A。')

    if not source_file.is_file() or source_file.stat().st_size == 0:

        raise FileNotFoundError('所选音频不存在或为空。')

    if not title.strip():

        raise ValueError('请填写歌名。')

    STORE.mkdir(parents=True, exist_ok=True)

    identifier = uuid.uuid4().hex[:8]

    out = STORE / f'{clean_name(title)}_{identifier}{source_file.suffix.lower()}'

    shutil.copy2(source_file, out)

    item = {'id':identifier,'title':title.strip(),'artist':artist.strip(),

            'source':str(out.resolve()), 'added_at':datetime.now().isoformat(timespec='seconds')}

    items=songs_read(); items.append(item); songs_write(items)

    return item



def match_song(request):

    text = re.sub(r'[\s《》「」『』“”"\'·,，。！？!?:：]+', '', request).casefold()

    matched=[]

    for item in songs_read():

        title = re.sub(r'[\s《》「」『』“”"\'·,，。！？!?:：]+', '', item['title']).casefold()

        if title and title in text and Path(item['source']).is_file():

            matched.append(item)

    matched.sort(key=lambda x:len(x['title']),reverse=True)

    return matched[0] if matched else None



def run_live(command, env=None, cwd=None, echo=print):

    textcmd = ' '.join(str(x) for x in command[:3])

    echo('执行：' + textcmd)

    proc = subprocess.Popen([str(c) for c in command], stdout=subprocess.PIPE,

                            stderr=subprocess.STDOUT, cwd=str(cwd) if cwd else None,

                            env=env, text=True, encoding='utf-8', errors='replace',

                            bufsize=1)

    try:

        for line in proc.stdout:

            echo(line.rstrip())

    finally:

        proc.stdout.close()

    code = proc.wait()

    if code:

        raise SetupError(f'操作退出码 {code}，请查看上方最后一段错误信息。')



def run_capture(command, env=None, cwd=None):

    return subprocess.run([str(c) for c in command], cwd=str(cwd) if cwd else None,

                          env=env, capture_output=True, text=True, encoding='utf-8',errors='replace')



def status():

    messages=[]

    s=seed_path(); messages.append(('Seed-VC 完整源码', (s/'inference.py').is_file() and (s/'hf_utils.py').is_file() and (s/'modules').is_dir()))

    messages.append(('CosyVoice Python 3.11',cozy_python().is_file()))

    messages.append(('专用转换环境',converter_python().is_file()))

    if converter_python().is_file():

        check=run_capture([converter_python(),'-c','import torch,torchaudio;print(torch.__version__,torch.cuda.is_available())'],env=environment())

        messages.append(('GPU PyTorch + torchaudio',check.returncode==0 and 'True' in check.stdout))

    else:

        messages.append(('GPU PyTorch + torchaudio',False))

    messages.append(('已有可用清唱源文件',bool(songs_read())))

    return messages



def install(emit=print):

    """Set up isolated env; borrow ONLY installed Cosy packages at runtime.

    No pip changes inside cosyvoice_env or V4.1 directories.

    """

    seed=seed_path()

    if not (seed/'inference.py').is_file() or not (seed/'hf_utils.py').is_file() or not (seed/'modules').is_dir():

        raise SetupError(f'Seed-VC 源码不完整：{seed}\n需要 inference.py、hf_utils.py、modules 文件夹。')

    cozy=cozy_python()

    if not cozy.is_file():

        raise SetupError(f'找不到 CosyVoice 虚拟环境：{cozy}')

    ck=run_capture([cozy,'-c','import torch,torchaudio;print(torch.__version__,torch.cuda.is_available())'])

    if ck.returncode != 0 or 'True' not in ck.stdout:

        raise SetupError('CosyVoice 环境里必须同时有 GPU torch 和匹配的 torchaudio。\n'+ck.stderr[-1300:])

    emit('检测通过：现有 CosyVoice CUDA PyTorch 可用；只借用，不修改。')

    py=converter_python()

    if not py.is_file():

        emit('创建独立 xiaoqi_seedvc_env（不覆盖原有唱歌环境）。')

        run_live([cozy,'-m','venv',str(py.parent.parent)],echo=emit)

    ck=run_capture([py,'-c','import torch,torchaudio;print(torch.__version__,torch.cuda.is_available())'],env=environment())

    if ck.returncode or 'True' not in ck.stdout:

        raise SetupError('独立转换环境目前无法借用 torch / torchaudio：\n'+ck.stderr[-1500:])

    emit('正在准备 Seed-VC 额外依赖。pip 只会向专用 xiaoqi_seedvc_env 写入文件。')

    run_live([py,'-m','pip','install','--prefer-binary','--disable-pip-version-check',

              '-i','https://pypi.tuna.tsinghua.edu.cn/simple',

              '--constraint', str(HERE/'constraints.txt'),'-r',str(REQUIREMENTS)],

             env=environment(),echo=emit)

    # Verify essential modules and CUDA after install.

    ck=run_capture([py,'-c','import torch, torchaudio, librosa, scipy, transformers, yaml, huggingface_hub; print("OK",torch.__version__,torch.cuda.is_available())'],env=environment())

    if ck.returncode or 'True' not in ck.stdout:

        raise SetupError('依赖检查失败。\n'+ck.stderr[-2500:])

    emit('基础依赖准备完成。第一次转换仍需下载官方模型（数 GB），使用 HF 国内镜像。')



def convert(source, reference, name='小柒清唱',steps=30,setup=False, emit=print):

    source=Path(source).expanduser().resolve(); reference=Path(reference).expanduser().resolve()

    if not source.is_file():raise SetupError(f'找不到清唱源文件：{source}')

    if not reference.is_file():raise SetupError(f'找不到小柒参考音色：{reference}')

    if source.suffix.lower() not in {'.wav','.mp3','.flac','.m4a','.ogg'}:

        raise SetupError('清唱源文件格式不支持。')

    if reference.suffix.lower() not in {'.wav','.mp3','.flac','.m4a','.ogg'}:

        raise SetupError('参考音色格式不支持。')

    if setup:install(emit=emit)

    py=converter_python(); seed=seed_path()

    if not py.exists():raise SetupError('转换环境尚未安装，请先点击「准备依赖」。')

    if not (seed/'inference.py').is_file():raise SetupError('找不到 Seed-VC/inference.py')

    OUT.mkdir(parents=True,exist_ok=True)

    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')

    task_dir=OUT/f'{clean_name(name)}_{stamp}_{uuid.uuid4().hex[:4]}'

    task_dir.mkdir(parents=True, exist_ok=True)

    args=[py,'inference.py','--source',str(source),'--target',str(reference),

          '--output',str(task_dir),'--diffusion-steps',str(int(steps)),

          '--length-adjust','1.0','--inference-cfg-rate','0.7',

          '--f0-condition','True', '--auto-f0-adjust','False',

          '--semi-tone-shift','0', '--fp16','True']

    emit('使用音高条件模型（F0=True），保留原旋律；不自动调整音高。')

    emit('首次运行需下载 Seed-VC、RMVPE、声学编码器等权重，可能需要数 GB；这不是歌曲下载。')

    started=time.time()

    run_live(args,env=environment(),cwd=seed,echo=emit)

    results=sorted(task_dir.glob('*.wav'),key=lambda p:p.stat().st_mtime,reverse=True)

    if not results:raise SetupError('Seed-VC 进程返回成功，但没有生成 WAV。请检查日志。')

    dest=task_dir/f'{clean_name(name)}_小柒音色.wav'

    shutil.copy2(results[0],dest)

    emit(f'转换完成，用时 {round(time.time()-started)} 秒：{dest}')

    return dest





# XIAOQI_SAFE_PATH_REPAIR_V2

# The previous release assumed a fixed extraction depth. Override only two path helpers.

def project_path():

    for p in (HERE, *HERE.parents):

        if p.name.lower() == 'xiaoqi_singing':

            return p.parent

        if (p / 'xiaoqi_singing').is_dir() and (p / 'cosyvoice_env').is_dir():

            return p

    return HERE.parent.parent



def seed_path():

    singing = project_path() / 'xiaoqi_singing'

    candidates = [

        HERE / 'third_party' / 'seed-vc',

        HERE / 'third_party' / 'seed-vc-main',

        HERE.parent / 'third_party' / 'seed-vc',

        HERE.parent / 'third_party' / 'seed-vc-main',

        singing / 'third_party' / 'seed-vc',

        singing / 'third_party' / 'seed-vc-main',

        

    ]

    for p in candidates:

        if (p / 'inference.py').is_file() and (p / 'hf_utils.py').is_file() and (p / 'modules').is_dir():

            return p

    for p in candidates:

        if (p / 'inference.py').is_file():

            return p

    return candidates[0]


# XIAOQI_PIP_MIRROR_FALLBACK_V3
# Retry the workbench's pip dependency-install step ONLY when a mirror is unreachable.
_XIAOQI_RUN_LIVE_BEFORE_MIRROR_FIX = run_live

def run_live(command, env=None, cwd=None, echo=print):
    args = [str(x) for x in command]
    if not ('-m' in args and 'pip' in args and 'install' in args
            and '-r' in args and any('requirements_seedvc.txt' in a for a in args)):
        return _XIAOQI_RUN_LIVE_BEFORE_MIRROR_FIX(command, env=env, cwd=cwd, echo=echo)
    mirrors = [
        ('Tencent', 'https://mirrors.cloud.tencent.com/pypi/simple'),
        ('Aliyun', 'https://mirrors.aliyun.com/pypi/simple/'),
        ('Official PyPI', 'https://pypi.org/simple'),
    ]
    network_errors = ('403', '429', 'timeout', 'timed out', 'timedout',
                      'proxyerror', 'connectionerror', 'connection refused',
                      'connection reset', 'could not fetch url', 'temporary failure',
                      'failed to establish', '502', '503', '504', 'ssl',
                      'name or service not known')
    last_error = None
    for label, url in mirrors:
        attempt = args[:]
        if '-i' in attempt:
            k = attempt.index('-i')
            if k + 1 < len(attempt): attempt[k+1] = url
        else:
            attempt.extend(['-i', url])
        attempt += ['--timeout', '25', '--retries', '2']
        lines=[]
        def record(line):
            msg=str(line)
            lines.append(msg)
            if len(lines)>70: del lines[:30]
            echo(line)
        echo('Trying %s pip mirror: %s' % (label, url))
        try:
            return _XIAOQI_RUN_LIVE_BEFORE_MIRROR_FIX(attempt, env=env, cwd=cwd, echo=record)
        except SetupError as error:
            last_error = error
            tail = '\n'.join(lines).lower()
            if not any(term in tail for term in network_errors):
                echo('Pip error is not a mirror connectivity issue. Stopping to avoid repeated installs.')
                raise
            echo('This mirror failed; trying another source.')
    raise SetupError('All three pip mirrors failed. See log for original error.') from last_error
