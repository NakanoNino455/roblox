# -*- coding: utf-8 -*-
"""Standalone Tkinter front-end. No alteration to original WeChat V4.1 scripts."""
from __future__ import annotations
import datetime
import os
import queue
import threading
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from song_core import (HERE, LOG, add_song, convert, install, match_song,
                       project_path, songs_read, status)

class Studio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('小柒 · MIDI 清唱音色转换与点歌素材库')
        self.geometry('870x700')
        self.minsize(780,610)
        self.queue = queue.Queue()
        self.busy=False
        self.source=tk.StringVar()
        self.reference=tk.StringVar()
        self.title_var=tk.StringVar(value='晴天')
        self.artist_var=tk.StringVar(value='周杰伦')
        self.request=tk.StringVar(value='小柒，唱首晴天')
        self.steps=tk.StringVar(value='30')
        self.entries=[]
        self.pick_initial_files()
        self.make_ui()
        self.refresh_songs()
        self.after(100,self.pump)
        self.say('已启动。此工具只操作独立歌声转换文件，不更改小柒 V4.1。')
        self.say('请先确认清唱 WAV 与小柒音色参考 WAV 的路径。')

    def pick_initial_files(self):
        desktop=Path.home()/'Desktop'
        project=project_path()
        for p in [desktop/'xiaoqi_qingtian_source.wav',project/'xiaoqi_qingtian_source.wav',
                  project/'xiaoqi_singing'/'xiaoqi_qingtian_source.wav']:
            if p.is_file():self.source.set(str(p));break
        candidates=[project/'xiaoqi_reference_16k.wav',desktop/'xiaoqi_reference_16k.wav',
                    project/'xiaoqi_singing'/'xiaoqi_reference_16k.wav',
                    project/'CosyVoice'/'xiaoqi_reference_16k.wav']
        for p in candidates:
            if p.is_file():self.reference.set(str(p));break

    def make_ui(self):
        self.configure(bg='#f3f7fa')
        style=ttk.Style(self)
        if 'clam' in style.theme_names():style.theme_use('clam')
        style.configure('TButton',padding=7)
        style.configure('Header.TLabel',font=('Microsoft YaHei UI',16,'bold'),background='#f3f7fa')
        style.configure('Info.TLabel',background='#f3f7fa')
        body=ttk.Frame(self,padding=14)
        body.pack(fill='both',expand=True)
        ttk.Label(body,text='🐳 小柒 · AI 清唱音色转换工作台',style='Header.TLabel').pack(anchor='w')
        ttk.Label(body,text='独立于 V4.1｜源歌声由 OpenUTAU 等工具生成｜Seed-VC 保留旋律并尝试转换成小柒音色',style='Info.TLabel',wraplength=800).pack(anchor='w',pady=(2,10))

        group=ttk.LabelFrame(body,text='① 选择源文件',padding=9);group.pack(fill='x',pady=4)
        self.file_row(group,'清唱源音频',self.source,lambda:self.choose(self.source))
        self.file_row(group,'小柒音色参考',self.reference,lambda:self.choose(self.reference))
        ops=ttk.Frame(group);ops.pack(fill='x',pady=4)
        ttk.Label(ops,text='输出歌曲名称').pack(side='left')
        ttk.Entry(ops,textvariable=self.title_var,width=23).pack(side='left',padx=(10,16))
        ttk.Label(ops,text='歌手（可选）').pack(side='left')
        ttk.Entry(ops,textvariable=self.artist_var,width=16).pack(side='left',padx=8)
        ttk.Label(ops,text='推理步数').pack(side='left',padx=(12,5))
        ttk.Combobox(ops,textvariable=self.steps,width=5,values=['20','30','40','50'],state='readonly').pack(side='left')

        actions=ttk.LabelFrame(body,text='② 一键准备与转换',padding=9);actions.pack(fill='x',pady=5)
        row=ttk.Frame(actions);row.pack(fill='x')
        self.btn_all=ttk.Button(row,text='一键准备环境并转换',command=lambda:self.begin(full=True));self.btn_all.pack(side='left',padx=(0,9))
        self.btn_convert=ttk.Button(row,text='已安装 → 直接转换',command=lambda:self.begin(full=False));self.btn_convert.pack(side='left',padx=(0,9))
        ttk.Button(row,text='环境体检',command=self.health).pack(side='left',padx=(0,9))
        ttk.Button(row,text='打开输出文件夹',command=self.open_outputs).pack(side='left')
        ttk.Label(actions,text='首次转换会下载模型权重，可能超过数 GB；国内镜像连通性和显存情况需要实际验证。',wraplength=790).pack(anchor='w',pady=(6,0))

        library=ttk.LabelFrame(body,text='③ 点歌素材库（支持任意新增歌曲，未收录的歌曲不会凭空生成）',padding=9)
        library.pack(fill='x',pady=5)
        row=ttk.Frame(library);row.pack(fill='x')
        ttk.Label(row,text='聊天消息').pack(side='left')
        ttk.Entry(row,textvariable=self.request,width=46).pack(side='left',padx=10,fill='x',expand=True)
        ttk.Button(row,text='识别歌曲',command=self.lookup).pack(side='left')
        row2=ttk.Frame(library);row2.pack(fill='x',pady=(9,1))
        self.song_combo=ttk.Combobox(row2,width=43,state='readonly');self.song_combo.pack(side='left',fill='x',expand=True,padx=(0,6))
        ttk.Button(row2,text='使用已收录清唱',command=self.choose_song).pack(side='left',padx=(0,6))
        ttk.Button(row2,text='把当前清唱加入曲库',command=self.register).pack(side='left')

        logs=ttk.LabelFrame(body,text='运行日志 / 故障提示（无需频繁截图，可复制文字）',padding=7);logs.pack(fill='both',expand=True,pady=5)
        self.logbox=tk.Text(logs,height=12,font=('Consolas',9),wrap='word',state='disabled')
        scroll=ttk.Scrollbar(logs,orient='vertical',command=self.logbox.yview)
        self.logbox.configure(yscrollcommand=scroll.set)
        self.logbox.pack(side='left',fill='both',expand=True)
        scroll.pack(side='left',fill='y')
        ttk.Button(body,text='复制日志',command=self.copy_logs).pack(anchor='e')

    def file_row(self,parent,caption,var,command):
        line=ttk.Frame(parent);line.pack(fill='x',pady=3)
        ttk.Label(line,text=caption,width=13).pack(side='left')
        ttk.Entry(line,textvariable=var).pack(side='left',fill='x',expand=True,padx=6)
        ttk.Button(line,text='浏览…',command=command,width=9).pack(side='left')

    def choose(self,var):
        result=filedialog.askopenfilename(title='选择音频文件',filetypes=[('音频','*.wav *.flac *.mp3 *.ogg *.m4a'),('全部文件','*.*')])
        if result:var.set(result)

    def say(self,txt):
        stamp=datetime.datetime.now().strftime('%H:%M:%S')
        self.logbox.configure(state='normal')
        self.logbox.insert('end',f'[{stamp}] {txt}\n')
        self.logbox.see('end')
        self.logbox.configure(state='disabled')

    def pump(self):
        try:
            while True:
                kind,contents=self.queue.get_nowait()
                if kind=='log':self.say(contents)
                if kind=='success':self.say('✅ 已输出 WAV：'+contents);messagebox.showinfo('转换成功','转换完成！\n文件：\n'+contents)
                if kind=='error':self.say('❌ '+contents);messagebox.showerror('操作未完成',contents[-2200:])
                if kind=='end':
                    self.busy=False
                    self.btn_all.configure(state='normal');self.btn_convert.configure(state='normal')
        except queue.Empty:pass
        self.after(100,self.pump)

    def health(self):
        self.say('正在检查项目目录：'+str(project_path()))
        for name,passed in status():self.say(('✅ ' if passed else '⚠️ ')+name)
        self.say('未通过的项目不代表 V4.1 损坏。')

    def begin(self,full):
        if self.busy:return
        src=Path(self.source.get().strip());ref=Path(self.reference.get().strip())
        if not src.is_file() or not ref.is_file():
            messagebox.showwarning('请先选好音频','请选择已导出的清唱源 WAV 和小柒参考音色 WAV。')
            return
        try: steps=int(self.steps.get())
        except ValueError:steps=30
        if full:
            msg='将建立独立 xiaoqi_seedvc_env 并在其中安装依赖，首次还需从镜像下载数 GB 模型。\n不会更改 CosyVoice 和小柒 V4.1。\n继续吗？'
            if not messagebox.askyesno('首次准备',msg):return
        self.busy=True
        self.btn_all.configure(state='disabled');self.btn_convert.configure(state='disabled')
        name=self.title_var.get().strip() or src.stem
        LOG.mkdir(parents=True,exist_ok=True)
        filename=LOG / (datetime.datetime.now().strftime('job_%Y%m%d_%H%M%S')+'.log')
        def worker():
            with open(filename,'a',encoding='utf-8') as logfile:
                def emit(msg):
                    msg=str(msg)
                    logfile.write(msg+'\n');logfile.flush()
                    self.queue.put(('log',msg))
                try:
                    result=convert(src,ref,name=name,steps=steps,setup=full,emit=emit)
                    self.queue.put(('success',str(result)))
                except Exception as exc:
                    emit('错误详情：'+traceback.format_exc()[-4000:])
                    self.queue.put(('error',str(exc)+'\n\n诊断日志：'+str(filename)))
                finally:self.queue.put(('end',''))
        threading.Thread(target=worker,daemon=True).start()

    def refresh_songs(self):
        self.entries=songs_read()
        self.song_combo['values']=[f'{x["title"]} - {x["artist"] or "未知歌手"}' for x in self.entries]
        if self.entries:self.song_combo.current(len(self.entries)-1)

    def register(self):
        src=self.source.get().strip()
        if not Path(src).is_file():
            messagebox.showwarning('缺少音频','请先选择已经生成的清唱源音频。');return
        if not messagebox.askyesno('确认曲库来源','确认你对该录音拥有相应使用权或许可，可以将它用于自己的歌声处理。\n添加到本地私人曲库吗？'):
            return
        try:
            item=add_song(self.title_var.get(),self.artist_var.get(),src)
            self.refresh_songs()
            self.say(f'曲库已新增：{item["artist"]} - {item["title"]}')
        except Exception as e:messagebox.showerror('添加失败',str(e))

    def lookup(self):
        item=match_song(self.request.get())
        if not item:
            messagebox.showinfo('尚未收录','本地曲库没有匹配的清唱音源。\n请先用 OpenUTAU 等方式制备一段有权使用的清唱 WAV，然后添加到曲库；本工具不会伪造原曲旋律。')
            return
        self.source.set(item['source']);self.title_var.set(item['title']);self.artist_var.set(item['artist'])
        self.say(f'已从聊天消息匹配歌曲：{item["title"]} / {item["artist"]}')

    def choose_song(self):
        ix=self.song_combo.current()
        if ix<0 or ix>=len(self.entries):return
        item=self.entries[ix]
        self.source.set(item['source']);self.title_var.set(item['title']);self.artist_var.set(item['artist'])
        self.say('已选歌曲：'+item['title'])

    def copy_logs(self):
        self.clipboard_clear();self.clipboard_append(self.logbox.get('1.0','end'))
        self.say('日志已复制到剪贴板。')

    def open_outputs(self):
        dst=HERE/'outputs';dst.mkdir(exist_ok=True)
        if os.name=='nt':os.startfile(dst)
        else:self.say('输出文件夹：'+str(dst))

if __name__=='__main__':
    Studio().mainloop()
