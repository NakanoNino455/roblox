# -*- coding: utf-8 -*-
"""Stable JSON-based song-request interface for future WeChat integration.

No direct chat access; no automatic WeChat messages are sent.
Example:
  py -3.11 song_bridge.py --request "小柒，唱首晴天" --reference "D:\\...\\xiaoqi_reference_16k.wav"
"""
import argparse,json,sys
from pathlib import Path
from song_core import match_song, convert

def resolve_request(request, reference='', do_convert=False, steps=30):
    item=match_song(request)
    if not item:
        return {'ok':False,'code':'song_not_in_library','message':'曲库中尚无这首歌可用的清唱音源。'}
    if not do_convert:
        return {'ok':True,'code':'song_found','title':item['title'],'artist':item['artist'],'source':item['source']}
    if not reference or not Path(reference).is_file():
        return {'ok':False,'code':'reference_missing','message':'未找到小柒参考音色 WAV。'}
    try:
        # Diagnostics go to stderr so stdout stays JSON for future callers.
        file=convert(item['source'],reference,name=item['title'],steps=steps,setup=False,emit=lambda t:print(t,file=sys.stderr,flush=True))
        return {'ok':True,'code':'converted','title':item['title'],'wav':str(file)}
    except Exception as exc:
        return {'ok':False,'code':'conversion_failed','message':str(exc)}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--request',required=True)
    p.add_argument('--reference',default='')
    p.add_argument('--convert',action='store_true',help='Actually run Seed-VC (otherwise lookup only)')
    p.add_argument('--steps',type=int,default=30)
    a=p.parse_args()
    result=resolve_request(a.request,a.reference,a.convert,a.steps)
    print(json.dumps(result,ensure_ascii=False))
    sys.exit(0 if result['ok'] else 2)
