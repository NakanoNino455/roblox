# -*- coding: utf-8 -*-
"""Optional Xiaoqi online music library. Public API, no paid keys; no DRM bypass.

Internet Archive metadata is supplied by uploaders; users must confirm each item's license.
Only items declaring CC0/CC BY/CC BY-SA and a downloadable audio file are offered.
"""
from __future__ import annotations
import json
from pathlib import Path
import re
import shutil
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox
from concurrent.futures import ThreadPoolExecutor

BASE = Path(__file__).resolve().parent
SONGS = BASE / 'songs'
API = 'https://archive.org/advancedsearch.php'
METADATA = 'https://archive.org/metadata/'
MAX_BYTES = 90 * 1024 * 1024
ALLOWED = {'.mp3', '.ogg', '.flac', '.wav', '.m4a'}
UA = 'XiaoqiSingingOnlineMusic/1.1 (personal educational project)'


def fetch_json(url):
    req = urllib.request.Request(url, headers={'User-Agent': UA, 'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=35) as rsp:
        return json.load(rsp)


def licensed(link):
    """Do not fetch no-derivatives or unknown license links."""
    if isinstance(link, list):
        link = next((s for s in link if isinstance(s, str)), '')
    link = str(link or '').lower().replace('https://', 'http://')
    if 'creativecommons.org/publicdomain/zero/' in link:
        return 'CC0'
    if 'creativecommons.org/licenses/by-sa/' in link:
        return 'CC BY-SA'
    if 'creativecommons.org/licenses/by/' in link:
        return 'CC BY'
    return None


def search_archive(term, page=1):
    term = (term or '').strip()[:85]
    q = 'mediatype:audio AND licenseurl:http*creativecommons.org*'
    if term:
        # Quote literal input to avoid introducing Lucene operations.
        escaped = term.replace('\\', '').replace('"', '')
        q += ' AND (title:"' + escaped + '" OR creator:"' + escaped + '" OR subject:"' + escaped + '")'
    params = [('q', q), ('fl[]', 'identifier'), ('fl[]', 'title'),
              ('fl[]', 'creator'), ('fl[]', 'licenseurl'),
              ('rows', '30'), ('page', str(max(1, int(page)))),
              ('sort[]', 'downloads desc'), ('output', 'json')]
    data = fetch_json(API + '?' + urllib.parse.urlencode(params))
    docs = data.get('response', {}).get('docs', [])
    entries = []
    for d in docs:
        license_name = licensed(d.get('licenseurl'))
        ident = d.get('identifier', '')
        if not license_name or not re.fullmatch(r'[A-Za-z0-9_\-.]{1,150}', str(ident)):
            continue
        creator = d.get('creator', '')
        if isinstance(creator, list): creator = ', '.join(str(x) for x in creator[:2])
        title = d.get('title', ident)
        if isinstance(title, list): title = title[0] if title else ident
        entries.append({'identifier': str(ident), 'title': str(title)[:140],
                        'creator': str(creator)[:90], 'license': license_name,
                        'licenseurl': d.get('licenseurl', ''),
                        'page': 'https://archive.org/details/' + ident})
    return entries


def select_audio_file(metadata):
    choices=[]
    for f in metadata.get('files', []):
        name = f.get('name', '')
        if not isinstance(name, str): continue
        ext = Path(name).suffix.lower()
        if ext not in ALLOWED: continue
        if f.get('private') == 'true': continue
        try: size = int(f.get('size', '0'))
        except (ValueError, TypeError): size = 0
        if not (20_000 <= size <= MAX_BYTES): continue
        priority = {'.mp3': 0, '.ogg': 1, '.flac': 2, '.m4a': 3, '.wav': 4}[ext]
        secondary = 0 if f.get('source') == 'original' else 1
        choices.append((priority, secondary, size, f))
    choices.sort(key=lambda x: x[:3])
    return choices[0][-1] if choices else None


def clean_name(s):
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', str(s)).strip('. ')
    return name[:65] or '公开授权音乐'


def import_archive(entry, status=None):
    def report(msg):
        if status: status(msg)
    ident = entry['identifier']
    meta = fetch_json(METADATA + urllib.parse.quote(ident, safe=''))
    meta_info = meta.get('metadata', {})
    final_license = licensed(meta_info.get('licenseurl'))
    if final_license is None:
        raise RuntimeError('源站未确认可改编的 Creative Commons 许可，已停止下载。')
    item = select_audio_file(meta)
    if item is None:
        raise RuntimeError('该专辑未找到可公开下载且不超过 90 MB 的音频，请换一首。')
    SONGS.mkdir(parents=True, exist_ok=True)
    ext = Path(item['name']).suffix.lower()
    base = clean_name(entry['title']) + '_' + clean_name(ident)[:24]
    dest = SONGS / (base + ext)
    if dest.exists():
        return dest
    src = 'https://archive.org/download/' + urllib.parse.quote(ident, safe='') + '/' + urllib.parse.quote(item['name'], safe='/')
    report('正在下载授权音频；可能需要几十秒……')
    with tempfile.NamedTemporaryFile(dir=SONGS, prefix='xiaoqi_dl_', suffix='.part', delete=False) as temp:
        temp_path = Path(temp.name)
    try:
        req = urllib.request.Request(src, headers={'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=65) as rsp, open(temp_path, 'wb') as out:
            final_url = rsp.geturl()
            if not final_url.startswith('https://'):
                raise RuntimeError('源站没有提供 HTTPS 下载链接。')
            length = rsp.headers.get('Content-Length', '')
            if length.isdigit() and int(length) > MAX_BYTES:
                raise RuntimeError('音频文件超过 90MB 的限制。')
            count = 0
            while True:
                part = rsp.read(1024*128)
                if not part: break
                count += len(part)
                if count > MAX_BYTES: raise RuntimeError('下载超过 90MB 限制。')
                out.write(part)
        if temp_path.stat().st_size < 20_000:
            raise RuntimeError('下载音频太小，疑似不完整。')
        temp_path.replace(dest)
    finally:
        temp_path.unlink(missing_ok=True)
    record = SONGS / (base + '_来源与授权.txt')
    link = meta_info.get('licenseurl', '')
    if isinstance(link,list): link = '\n'.join(map(str,link))
    record.write_text('\n'.join([
        '曲目：' + entry['title'], '作者：' + entry['creator'],
        '来源：' + entry['page'], '许可：' + final_license,
        '许可网址：' + str(link),
        '说明：请到作品原页面核实作者、文件及授权条款；改编和转发可能需署名/同方式共享。',
        '文件：' + item['name'],
    ]) + '\n', encoding='utf-8')
    return dest


class LibraryWindow:
    def __init__(self, master, callback=None):
        self.callback = callback
        self.root = tk.Toplevel(master)
        self.root.title('小柒 · 在线歌曲库（公开授权音乐 / 主流音乐搜索）')
        self.root.geometry('920x570')
        self.root.minsize(760,480)
        self.word = tk.StringVar()
        self.state = tk.StringVar(value='输入关键词搜索；留空可浏览热门公开授权音频。')
        self.rows = {}
        self.busy = False
        self.pool = ThreadPoolExecutor(max_workers=1)
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        f=ttk.Frame(self.root,padding=13); f.pack(fill='both',expand=True)
        ttk.Label(f,text='在线曲库 · 两种来源', font=('Microsoft YaHei UI',16,'bold')).pack(anchor='w')
        ttk.Label(f,text='免费授权曲库可尝试一键导入翻唱。QQ音乐 / 网易云音乐 / Spotify 提供搜索与试听，不能直接提取其受版权保护的音源。',
                  wraplength=860).pack(anchor='w',pady=(5,11))
        bar=ttk.Frame(f);bar.pack(fill='x')
        ttk.Label(bar,text='歌名 / 歌手：').pack(side='left')
        self.inp=ttk.Entry(bar,textvariable=self.word,width=40);self.inp.pack(side='left',fill='x',expand=True,padx=(6,7))
        self.btn=ttk.Button(bar,text='搜索可下载授权音乐',command=self.search);self.btn.pack(side='left')
        platforms=ttk.Frame(f);platforms.pack(fill='x',pady=(10,8))
        ttk.Label(platforms,text='主流音乐平台：').pack(side='left')
        for name in ('网易云音乐','QQ音乐','Spotify'):
            ttk.Button(platforms,text='搜索 '+name,command=lambda n=name:self.open_platform(n)).pack(side='left',padx=(6,0))
        cols=('title','creator','license')
        self.tree=ttk.Treeview(f,columns=cols,show='headings',selectmode='browse',height=13)
        self.tree.heading('title',text='公开授权曲目 / 专辑')
        self.tree.heading('creator',text='创作者')
        self.tree.heading('license',text='标注许可')
        self.tree.column('title',width=450,anchor='w')
        self.tree.column('creator',width=230,anchor='w')
        self.tree.column('license',width=110,anchor='center')
        scroll=ttk.Scrollbar(f,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side='left',fill='both',expand=True)
        scroll.pack(side='left',fill='y')
        footer=ttk.Frame(self.root,padding=(13,5,13,12));footer.pack(fill='x',side='bottom')
        ttk.Button(footer,text='打开作品授权页面',command=self.open_source).pack(side='left')
        self.import_btn=ttk.Button(footer,text='确认授权并导入所选音频',command=self.import_selected)
        self.import_btn.pack(side='left',padx=8)
        ttk.Label(footer,textvariable=self.state,wraplength=450).pack(side='right',fill='x',expand=True)

    def close(self):
        self.root.destroy()
        self.pool.shutdown(wait=False,cancel_futures=True)

    def update_status(self,msg):
        try:
            self.root.after(0,lambda s=msg:self.state.set(s) if self.root.winfo_exists() else None)
        except RuntimeError: pass

    def async_run(self,func,done):
        if self.busy: return
        self.busy=True
        self.btn.configure(state='disabled'); self.import_btn.configure(state='disabled')
        def job():
            try: result=func(); error=None
            except Exception as exc: result=None;error=str(exc)
            def finish():
                if not self.root.winfo_exists(): return
                self.busy=False
                self.btn.configure(state='normal'); self.import_btn.configure(state='normal')
                done(result,error)
            try:self.root.after(0,finish)
            except RuntimeError:pass
        self.pool.submit(job)

    def search(self):
        word=self.word.get().strip()
        self.state.set('正在查询 Internet Archive 公开授权目录……')
        def done(entries, error):
            if error:
                self.state.set('搜索失败：'+error[:160]);return
            self.rows.clear()
            for item in self.tree.get_children():self.tree.delete(item)
            for i,entry in enumerate(entries):
                key=str(i);self.rows[key]=entry
                self.tree.insert('', 'end',iid=key,values=(entry['title'],entry['creator'],entry['license']))
            self.state.set(f'找到 {len(entries)} 项许可标记曲目。每次选择前请查看来源与授权。' if entries else '没有匹配结果。可尝试英文关键词，或在主流音乐平台搜索试听。')
        self.async_run(lambda:search_archive(word),done)

    def selected(self):
        sel=self.tree.selection()
        if not sel:
            messagebox.showinfo('先选歌曲','请先从列表里选择一首歌曲或专辑。',parent=self.root)
            return None
        return self.rows.get(sel[0])

    def open_source(self):
        entry=self.selected()
        if entry: webbrowser.open(entry['page'])

    def open_platform(self,platform):
        word=self.word.get().strip()
        if platform=='QQ音乐':
            url='https://y.qq.com/n/ryqq/search?w='+urllib.parse.quote(word)
        elif platform=='网易云音乐':
            url='https://music.163.com/#/search/m/?s='+urllib.parse.quote(word)
        else:
            url='https://open.spotify.com/search/'+urllib.parse.quote(word) if word else 'https://open.spotify.com/'
        webbrowser.open(url)
        self.state.set('已在浏览器打开 '+platform+'。平台搜索不代表有权限下载、转制或翻唱。')

    def import_selected(self):
        entry=self.selected()
        if not entry:return
        ok=messagebox.askyesno('确认授权','将从 Internet Archive 下载该条目公开提供的音频到小柒歌曲库。\n\n请先查看原页面的授权与录音版权。CC BY/CC BY-SA 可能要求署名与相同许可分享。\n\n继续下载吗？',parent=self.root)
        if not ok:return
        self.state.set('正在检查作品元数据和下载授权音频……')
        def done(path,error):
            if error:
                self.state.set('导入失败：'+error[:180]);messagebox.showerror('无法导入',error,parent=self.root);return
            self.state.set('已导入：'+path.name)
            if self.callback:self.callback()
            messagebox.showinfo('导入成功','曲目已加入小柒本地歌曲库。\n\n'+str(path)+'\n\n请在主界面刷新并测试生成。',parent=self.root)
        self.async_run(lambda:import_archive(entry,self.update_status),done)


def show_library(master,callback=None):
    LibraryWindow(master,callback)
