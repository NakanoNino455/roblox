"""小柒运行状态与自有缓存数据库；不操作 wechatauto_db 中的文件。"""
import json
import sqlite3
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DB=ROOT/'xiaoqi_runtime.db'

def connect(path=None):
    path=Path(path or DB)
    con=sqlite3.connect(str(path),timeout=10)
    con.execute('PRAGMA busy_timeout=10000')
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('''CREATE TABLE IF NOT EXISTS health (
        component TEXT PRIMARY KEY, status TEXT NOT NULL,
        failures INTEGER NOT NULL DEFAULT 0, last_ok REAL,
        last_error REAL, retry_at REAL, detail TEXT NOT NULL DEFAULT '')''')
    con.execute('''CREATE TABLE IF NOT EXISTS cache (
        namespace TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL,
        expires_at REAL NOT NULL, PRIMARY KEY(namespace,key))''')
    con.execute('''CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL,
        component TEXT NOT NULL, severity TEXT NOT NULL, detail TEXT NOT NULL)''')
    con.commit()
    return con

def record(con,component,ok,failures=0,retry_at=0,detail=''):
    now=time.time(); status='ok' if ok else 'degraded'
    con.execute('''INSERT INTO health(component,status,failures,last_ok,last_error,retry_at,detail)
        VALUES (?,?,?,?,?,?,?) ON CONFLICT(component) DO UPDATE SET
        status=excluded.status,failures=excluded.failures,
        last_ok=CASE WHEN excluded.status='ok' THEN excluded.last_ok ELSE health.last_ok END,
        last_error=CASE WHEN excluded.status='degraded' THEN excluded.last_error ELSE health.last_error END,
        retry_at=excluded.retry_at,detail=excluded.detail''',
        (component,status,failures,now if ok else None,None if ok else now,retry_at,str(detail)[:250]))
    if ok or failures in (1,3,7,12) or failures%12==0:
        con.execute('INSERT INTO events(at,component,severity,detail) VALUES (?,?,?,?)',
            (now,component,'info' if ok else 'error',str(detail)[:250]))
    con.commit()

def cache_put(con,namespace,key,value,ttl=86400):
    if ttl<=0: raise ValueError('ttl must be positive')
    con.execute('INSERT OR REPLACE INTO cache(namespace,key,value,expires_at) VALUES (?,?,?,?)',
                (namespace,key,json.dumps(value,ensure_ascii=False),time.time()+ttl));con.commit()

def cache_get(con,namespace,key):
    row=con.execute('SELECT value FROM cache WHERE namespace=? AND key=? AND expires_at>?',
                    (namespace,key,time.time())).fetchone()
    return json.loads(row[0]) if row else None

def maintenance(con,days=14):
    """Only remove THIS DB's expired cache and dated events. Does not VACUUM or touch wx files."""
    now=time.time()
    expired=con.execute('DELETE FROM cache WHERE expires_at<?',(now,)).rowcount
    events=con.execute('DELETE FROM events WHERE at<?',(now-days*86400,)).rowcount
    con.commit()
    return {'cache_expired':expired,'old_events':events}

def report(con):
    rows=con.execute('SELECT component,status,failures,last_ok,last_error,retry_at,detail FROM health ORDER BY component').fetchall()
    return [{'component':r[0],'status':r[1],'failures':r[2],'last_ok':r[3],'last_error':r[4],'retry_at':r[5],'detail':r[6]} for r in rows]

if __name__=='__main__':
    with connect() as con:
        print('小柒运行缓存库：',DB)
        for item in report(con):print(json.dumps(item,ensure_ascii=False))
        print('本次清理：',maintenance(con))
