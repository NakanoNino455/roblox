"""小柒安全故障汇报。只保留最小错误元数据，不存私人消息。
报告发送：只向配置的主人 wxid，且由主程序完整的发送前验证负责。
"""
import sqlite3
import time
import datetime


def init(con):
    con.execute('''CREATE TABLE IF NOT EXISTS recovery_incidents(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        component TEXT NOT NULL, started REAL NOT NULL, ended REAL,
        failures INTEGER NOT NULL DEFAULT 1,
        error_type TEXT NOT NULL, winerror INTEGER,
        send_state TEXT NOT NULL DEFAULT 'open', last_detail TEXT NOT NULL DEFAULT '')''')
    con.commit()
    # Process died during send: unsafe to retry automatically.
    con.execute("UPDATE recovery_incidents SET send_state='uncertain' WHERE send_state='sending'")
    con.commit()


def failed(con, ex):
    now=time.time()
    typ=type(ex).__name__
    win=getattr(ex,'winerror',None)
    detail=(str(ex) or '')[:160]
    row=con.execute("SELECT id FROM recovery_incidents WHERE component='wechat_sessions' AND send_state='open' ORDER BY id DESC LIMIT 1").fetchone()
    if row:
        con.execute('UPDATE recovery_incidents SET failures=failures+1,last_detail=? WHERE id=?',(detail,row[0]))
    else:
        con.execute('''INSERT INTO recovery_incidents(component,started,error_type,winerror,last_detail)
                    VALUES (?,?,?,?,?)''',('wechat_sessions',now,typ,win,detail))
    con.commit()


def recovered(con):
    now=time.time()
    con.execute("UPDATE recovery_incidents SET ended=?,send_state='pending' WHERE component='wechat_sessions' AND send_state='open'",(now,))
    con.commit()


def _format_time(ts):
    return datetime.datetime.fromtimestamp(ts).strftime('%m-%d %H:%M:%S')


def deliver_one(con,sender):
    """sender 必须是仅支持主人精确 wxid 的安全发送函数。
    调用之前标记 sending；无法确认成功则转 uncertain，永不自动重复发送。
    """
    row=con.execute('''SELECT id,started,ended,failures,error_type,winerror
                      FROM recovery_incidents WHERE send_state='pending' ORDER BY id LIMIT 1''').fetchone()
    if not row:return False
    rid,start,end,count,typ,win=row
    duration=max(0,int(end-start))
    code='WinError '+str(win) if win is not None else typ
    report=('小柒故障恢复报告\n'
            f'发生时间：{_format_time(start)}\n恢复时间：{_format_time(end)}\n'
            f'持续：{duration//60}分{duration%60}秒，失败次数：{count}\n'
            f'错误：{code}\n原因：检测到微信会话数据库访问异常；具体占用进程未确定。\n'
            '处理：暂停扫描、退避重试、尝试重建连接；恢复后重新验证聊天对象。')
    con.execute("UPDATE recovery_incidents SET send_state='sending' WHERE id=? AND send_state='pending'",(rid,))
    con.commit()
    try:
        sender(report)
    except Exception as ex:
        con.execute("UPDATE recovery_incidents SET send_state='uncertain',last_detail=? WHERE id=?",(type(ex).__name__+': '+str(ex)[:110],rid))
        con.commit()
        print('故障报告未能确认发送，标记为 uncertain，禁止自动重发：',type(ex).__name__,flush=True)
        return False
    con.execute("UPDATE recovery_incidents SET send_state='sent' WHERE id=?",(rid,))
    con.commit()
    print('故障恢复报告已确认发送给主人',rid,flush=True)
    return True
