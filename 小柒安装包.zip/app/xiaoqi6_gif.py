"""XiaoQi opt-in Wikimedia Commons GIF stickers (test group only).

Does NOT scrape copyrighted meme sites; considers only Commons public domain / CC0.
Emits diagnostic messages when the source cannot be reached or no suitable GIF exists.
"""
import hashlib
import json
import os
import random
import re
import time
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from PIL import Image

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / 'xiaoqi_gif_cache'
STATE = CACHE / 'state.json'
SEARCH = 'https://commons.wikimedia.org/w/api.php'
KEYWORDS = {
    'happy': 'animated happy cat gif',
    'angry': 'animated angry cat gif',
    'comfort': 'animated heart gif',
    'surprise': 'animated surprised cat gif',
    'default': 'animated cute cat gif',
}

def mood(text):
    t = str(text)
    if any(x in t for x in ('抱抱','别难过','加油','安慰','辛苦','别哭')): return 'comfort'
    if any(x in t for x in ('生气','炸毛','无语','哼','气死','不许')): return 'angry'
    if any(x in t for x in ('震惊','啊？','？？','什么鬼','离谱')): return 'surprise'
    if any(x in t for x in ('哈哈','笑死','开心','嘿嘿','好耶','嘻嘻')): return 'happy'
    return 'default'

def _json(url):
    req = Request(url, headers={'User-Agent':'XiaoQiWeChat/6.2 (Commons public-domain image search)', 'Accept':'application/json'})
    with urlopen(req, timeout=10) as r:
        if r.status != 200: raise RuntimeError('search HTTP '+str(r.status))
        return json.load(r)

def _search_gif(m):
    query = KEYWORDS.get(m, KEYWORDS['default'])
    args = dict(action='query',generator='search',gsrsearch=query,gsrnamespace=6,
                gsrlimit=15,prop='imageinfo',iiprop='url|size|extmetadata',iilimit=1,format='json')
    results = _json(SEARCH+'?'+urlencode(args))
    found = []
    for page in results.get('query',{}).get('pages',{}).values():
        title = str(page.get('title',''))
        if not title.lower().endswith('.gif'): continue
        ii=(page.get('imageinfo') or [{}])[0]
        md=ii.get('extmetadata') or {}
        lic=re.sub('<[^>]*>',' ',str((md.get('LicenseShortName') or {}).get('value',''))).lower()
        if not any(x in lic for x in ('cc0','public domain','pd-')): continue
        size = int(ii.get('size') or 0)
        if not (1000 < size <= 3_000_000): continue
        url = str(ii.get('url') or '')
        if url.startswith('https://upload.wikimedia.org/'):
            found.append((url,title,lic))
    random.shuffle(found)
    return found

def _download(url):
    CACHE.mkdir(exist_ok=True)
    dest=CACHE/(hashlib.sha256(url.encode()).hexdigest()[:22]+'.gif')
    if dest.is_file(): return dest
    req=Request(url,headers={'User-Agent':'XiaoQiWeChat/6.2'})
    with urlopen(req,timeout=15) as r:
        if r.status!=200: raise RuntimeError('image HTTP '+str(r.status))
        data=r.read(3_000_001)
    if len(data)>3_000_000 or not data.startswith((b'GIF87a',b'GIF89a')): return None
    dest.write_bytes(data)
    try:
        with Image.open(dest) as im:
            if im.format!='GIF' or getattr(im,'n_frames',1)<2:
                dest.unlink(missing_ok=True); return None
            if im.width>1200 or im.height>1200:
                dest.unlink(missing_ok=True); return None
    except Exception:
        dest.unlink(missing_ok=True); return None
    return dest

def maybe_send_gif(wx, db, uid, name, answer, now=None):
    """Test-group-only GIF sender. In test mode it always ATTEMPTS a search.

    The actual WeChat result is only known after checking send_image's response
    and confirming the GIF in the chat. Never retry automatically on uncertainty.
    """
    if os.getenv('XIAOQI_GIF_TEST_ENABLED', '1') != '1':
        return False
    if str(uid) != '48070338966@chatroom' or str(name) != 'test':
        return False

    # During testing, do not silently skip ~75% of eligible replies.
    # Preserve a small cooldown to prevent a busy test group being flooded.
    cooldown = max(0, int(os.getenv('XIAOQI_GIF_COOLDOWN_SECONDS', '60')))
    CACHE.mkdir(exist_ok=True)
    try:
        state = json.loads(STATE.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        state = {}
    remaining = cooldown - (time.time() - float(state.get(str(uid), 0)))
    if remaining > 0:
        print('GIF跳过：测试群冷却中，剩余约', int(remaining) + 1, '秒', flush=True)
        return False

    try:
        if not wx or getattr(wx, '_gui', None) is None:
            print('GIF跳过：微信界面对象不可用', flush=True)
            return False
        gui = wx._gui
        if gui._get_db() is not db:
            print('GIF跳过：微信数据库对象不一致', flush=True)
            return False
        if not gui.open_chat(name, exact=True):
            print('GIF跳过：无法准确打开 test 群', flush=True)
            return False
        inp = gui._get_uia()._chat_input()
        # Do not silently loosen the recipient safety check.
        if inp is None or inp.AutomationId != 'chat_input_field' or inp.Name != name:
            print('GIF跳过：输入框目标校验失败；实际名称=',
                  repr(getattr(inp, 'Name', None)), flush=True)
            return False

        selected_mood = mood(answer)
        print('GIF测试：准备联网搜索，情绪=', selected_mood, flush=True)
        try:
            candidates = _search_gif(selected_mood)[:5]
        except Exception as exc:
            print('GIF搜索失败：', type(exc).__name__, str(exc)[:220], flush=True)
            return False
        if not candidates:
            print('GIF跳过：网络图库没有符合要求的公开授权 GIF', flush=True)
            return False

        for url, title, license_name in candidates:
            try:
                path = _download(url)
            except Exception as exc:
                print('GIF下载失败：', type(exc).__name__, str(exc)[:160], flush=True)
                continue
            if path is None:
                print('GIF素材不合格，继续查找：', repr(title)[:100], flush=True)
                continue
            # Reserve cooldown BEFORE send: sending may succeed even if verification fails.
            state[str(uid)] = time.time()
            STATE.write_text(json.dumps(state, ensure_ascii=False), encoding='utf-8')
            try:
                response = gui.send_image(str(path), who=name, verify=True)
            except Exception as exc:
                print('GIF发送发生异常，结果不确定，请先检查 test 群：',
                      type(exc).__name__, str(exc)[:180], flush=True)
                return False
            print('GIF发送已尝试，核对 test 群是否收到动态图片：',
                  repr(title), '许可证', license_name,
                  '接口结果', str(response)[:180], flush=True)
            return True
        print('GIF跳过：候选动态图均下载失败或不符合格式要求', flush=True)
        return False
    except Exception as exc:
        # A GIF-only failure must not take down the main reply loop.
        print('GIF模块异常：', type(exc).__name__, str(exc)[:220], flush=True)
        return False
