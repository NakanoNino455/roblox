"""Optional opt-in private/group WeChat SILK voice extraction and offline transcription.
Only call for messages already authenticated by the existing bot's chat scan.
No auto-download on import. No automatic voice forwarding.
"""
import os
import tempfile
import wave
from pathlib import Path


def voice_enabled():
    return os.environ.get('XIAOQI8_VOICE_PRIVATE','0') == '1'


def group_voice_enabled():
    return os.environ.get('XIAOQI8_VOICE_GROUP','0') == '1'


def is_voice(message):
    for key in ('local_type','type','msg_type','message_type'):
        val=str(message.get(key,'')).strip().lower()
        if val in ('34','voice','语音','语音消息'):
            return True
    return False


def _to_wav(silk_path, wav_path):
    try:
        import pilk
    except ImportError as exc:
        raise RuntimeError('请先安装语音解码依赖：py -3.11 -m pip install pilk') from exc
    pcm_path = str(Path(wav_path).with_suffix('.pcm'))
    # WeChat SILK is typically 24kHz, but confirm on your local messages.
    sample_rate = 24000
    pilk.decode(str(silk_path), pcm_path)
    data = Path(pcm_path).read_bytes()
    if not data: raise RuntimeError('SILK 解码结果为空')
    with wave.open(str(wav_path),'wb') as f:
        f.setnchannels(1);f.setsampwidth(2);f.setframerate(sample_rate);f.writeframes(data)
    return wav_path


def transcribe_wechat_voice(db, chat_id, message):
    """Extract from local media DB using chat wxid and local_id; never changes chat history."""
    local_id=message.get('local_id')
    if local_id is None: raise RuntimeError('语音缺少 local_id')
    from wechatauto.media import MediaDownloader
    import xiaoqi7_tools as tools
    with tempfile.TemporaryDirectory(prefix='xiaoqi8_voice_') as tmp:
        dl=MediaDownloader(db,save_dir=tmp)
        silk=dl.download_voice(str(chat_id),int(local_id),save_dir=tmp)
        if not silk: raise RuntimeError('微信本地媒体库未找到这条语音')
        if not Path(silk).is_file(): raise RuntimeError('下载接口未返回有效文件')
        wav=str(Path(tmp)/'voice.wav')
        _to_wav(silk,wav)
        transcript=tools.transcribe_audio(wav).strip()
        return transcript[:1200]
