"""Freshness checks based on real message timestamps; no WeChat imports."""
import time
from datetime import datetime
DIRECT={'private','mention','ambient','media','link','weather','news'}

def timestamp(value):
 if value is None or isinstance(value,bool):return None
 try:
  x=float(value)
  while x>100000000000:x/=1000
  return x if 946684800<x<4102444800 else None
 except (TypeError,ValueError):pass
 try:
  if isinstance(value,datetime):d=value
  else:d=datetime.fromisoformat(str(value).strip().replace('Z','+00:00'))
  return d.timestamp()
 except (TypeError,ValueError,OverflowError):return None

def message_time(message):
 for key in ('create_time','createTime','createtime','timestamp','msg_time','time'):
  result=timestamp(message.get(key))
  if result is not None:return result
 return None

def incoming_reason(message,started,now=None):
 now=time.time() if now is None else now;received=message_time(message)
 if received is None:return '消息时间无法核实'
 if received<started-2:return '本次启动前的历史消息'
 if now-received>120:return '新消息已超过120秒'
 if received-now>30:return '消息时间超前，请核对电脑时间'
 return None

def job_reason(kind,received,started,now=None):
 if kind not in DIRECT:return None
 now=time.time() if now is None else now;ts=timestamp(received)
 if ts is None:return '回复任务时间无法核实'
 if ts<started-2:return '本次启动前的旧回复任务'
 if now-ts>180:return '回复任务已超过180秒'
 if ts-now>30:return '回复任务时间异常'
 return None
