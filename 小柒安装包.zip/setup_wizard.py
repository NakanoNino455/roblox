# -*- coding: utf-8 -*-
"""Copy a publishable project to an EMPTY destination. Never modifies existing running app.
No network, pip, WeChat or model operations are done by this installer.
"""
from pathlib import Path
import json, shutil, sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

ROOT=Path(__file__).resolve().parent


def choose_default():
    return Path.home()/'Documents'/'Xiaoqi Community'


def install_to(folder):
    target=Path(folder).expanduser().resolve()
    root=ROOT.resolve()
    if root == target or root in target.parents or target in root.parents:
        raise ValueError('安装目录不能与安装包源码目录重叠。请选择一个新的独立目录。')
    if target.exists() and any(target.iterdir()):
        raise FileExistsError('为保护已有小柒，目标目录必须不存在或为空文件夹。')
    target.mkdir(parents=True,exist_ok=True)
    for src in (root/'app').iterdir():
        dst=target/src.name
        if src.is_dir():shutil.copytree(src,dst)
        else:shutil.copy2(src,dst)
    shutil.copytree(root/'docs', target/'docs', dirs_exist_ok=False)
    for name in ('.gitignore','AUTHOR.md','README.md','VERSION.json','requirements-basic.txt','config.example.json','persona.example.json','settings-safe.example.json','CHANGELOG.md',
                 'CONFIGURE.cmd','CHECK_ENV.cmd','RUN_DEMO.cmd','START_WITH_CONFIRMATION.cmd','INSTALL_BASIC_DEPENDENCIES.cmd','environment_check.py','configure_local.py','START_HERE.html','FEATURE_SETUP.py','SETUP_COMPONENTS.py','FEATURE_SETUP.cmd','FULL_CHECK.py','FULL_CHECK.cmd','xiaoqi_launcher.py'):
        shutil.copy2(root/name,target/name)
    # Safe first-run settings. User identity is never inherited from the creator.
    for example,actual in (('config.example.json','config.json'),('persona.example.json','persona.json'),('settings-safe.example.json','xiaoqi_final_settings.json')):
        shutil.copy2(root/example,target/actual)
    (target/'INSTALL_COMPLETE.txt').write_text('Xiaoqi installed safely. Created by 同一意.\nNEXT: CONFIGURE.cmd -> CHECK_ENV.cmd -> RUN_DEMO.cmd\nAutomatic sending is OFF.\n',encoding='utf-8')
    return target


def main():
    if not (sys.version_info[:2]==(3,11)):
        tk.Tk().withdraw()
        messagebox.showerror('Python 版本不兼容','需要 Python 3.11（64 位）。请先安装再运行。')
        return 1
    win=tk.Tk();win.title('小柒 Xiaoqi • Community Edition — 安装向导');win.geometry('790x475');win.minsize(690,430)
    frame=ttk.Frame(win,padding=25);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='🐳 小柒 Xiaoqi  ·  Community Edition',font=('Microsoft YaHei UI',18,'bold')).pack(anchor='w',pady=(0,7))
    ttk.Label(frame,text='原创作者：同一意   |   GitHub: 2068969346-maker',font=('Microsoft YaHei UI',10)).pack(anchor='w')
    ttk.Separator(frame).pack(fill='x',pady=17)
    msg=('欢迎使用小柒 Windows 安装向导（v1.0.0 全功能安装版）。\n\n'
         '本安装只会复制程序到新的目录，不运行微信、模型通过功能配置界面由用户单独授权安装、不会修改你现有的小柒。\n'
         '所有自动发送开关在新安装中默认关闭；语音/音乐功能需要自备有权使用的素材和模型。\n\n'
         '准备要求：Windows 10/11、Python 3.11、适配的桌面微信及 wechatauto（后续再设置）。')
    ttk.Label(frame,text=msg,justify='left',wraplength=710).pack(anchor='w')
    ttk.Label(frame,text='选择安装位置（必须是空目录）：',font=('Microsoft YaHei UI',10,'bold')).pack(anchor='w',pady=(18,3))
    path=tk.StringVar(value=str(choose_default()))
    line=ttk.Frame(frame);line.pack(fill='x')
    ttk.Entry(line,textvariable=path).pack(side='left',fill='x',expand=True)
    def browse():
        result=filedialog.askdirectory(title='选择安装目录')
        if result:path.set(result)
    ttk.Button(line,text='浏览…',command=browse).pack(side='left',padx=8)
    status=tk.StringVar(value='尚未安装。安装后先运行 CONFIGURE.cmd，再检测环境。')
    ttk.Label(frame,textvariable=status,foreground='#285c80',wraplength=690).pack(anchor='w',pady=(14,12))
    buttons=ttk.Frame(frame);buttons.pack(fill='x')
    def go():
        try:
            result=install_to(path.get())
        except Exception as exc:
            status.set('安装失败：'+str(exc))
            messagebox.showerror('安装未完成',str(exc))
            return
        status.set('安装完成，位置：'+str(result))
        messagebox.showinfo('完成 ✓','小柒已复制到独立目录。\n自动发送默认关闭。\n下一步：双击 CONFIGURE.cmd 配置自己的账号。')
    ttk.Button(buttons,text='安装到所选文件夹',command=go).pack(side='left')
    ttk.Button(buttons,text='退出',command=win.destroy).pack(side='right')
    ttk.Label(frame,text='Xiaoqi © 同一意 · 本候选版未经过全部 Windows/微信新机实测',font=('Microsoft YaHei UI',9)).pack(side='bottom',anchor='e',pady=9)
    win.mainloop();return 0

if __name__=='__main__':raise SystemExit(main())
