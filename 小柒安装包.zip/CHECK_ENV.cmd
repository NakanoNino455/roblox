@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0.xiaoqi_base_env\Scripts\python.exe" (
 "%~dp0.xiaoqi_base_env\Scripts\python.exe" -X utf8 "%~dp0environment_check.py"
) else (
 py -3.11 -X utf8 "%~dp0environment_check.py"
)
pause
