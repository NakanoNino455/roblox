@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "%~dp0.xiaoqi_base_env\Scripts\python.exe" (
 set "BOTPY=%~dp0.xiaoqi_base_env\Scripts\python.exe"
) else (
 set "BOTPY=py -3.11"
)
%BOTPY% -X utf8 "%~dp0environment_check.py" --strict
if errorlevel 1 (
 echo Account or dependencies not ready. Do NOT start real WeChat sending.
 pause
 exit /b 1
)
choice /c YN /m "Authorize bot launch for this session"
if errorlevel 2 exit /b 0
%BOTPY% -X utf8 "%~dp0xiaoqi_launcher.py"
pause
