@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3.11 -X utf8 "%~dp0configure_local.py"
if errorlevel 1 echo Configuration wizard ended with a warning.
pause
