# -*- coding: utf-8 -*-
"""Non-mutating preflight checks. Never opens WeChat, never sends or changes files."""
import sys,os,importlib.util,json,platform,argparse
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main(strict=False):
    print('= Xiaoqi Community Edition · 环境检查 | by 同一意 =')
    print('操作系统:',platform.platform())
    print('Python:',sys.version.split()[0],sys.executable)
    checks={}
    checks['系统是 Windows'] = sys.platform=='win32'
    checks['Python 3.11'] = sys.version_info[:2]==(3,11)
    for package in ('openai','wechatauto'):
        good=importlib.util.find_spec(package) is not None
        checks[f'依赖 {package}']=good
    for package in ('torch','soundfile','numpy','sounddevice'):
        print('  可选',package,'=',bool(importlib.util.find_spec(package)))
    cfg_file=ROOT/'config.json'
    try:cfg=json.loads(cfg_file.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):cfg={}
    for field in ('db_account','approved_account_wxid','owner_wxid'):
        val=str(cfg.get(field,'')).strip()
        checks['用户配置 '+field]=bool(val) and not val.startswith('请填写') and val!='wxid_REPLACE_WITH_YOURS'
    checks['DEEPSEEK_API_KEY 已设']=bool(os.environ.get('DEEPSEEK_API_KEY','').strip())
    sett=ROOT/'xiaoqi_final_settings.json'
    try:s=json.loads(sett.read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):s={}
    checks['已显式授权自动发送']=s.get('auto_send_enabled') is True
    for label,good in checks.items():print(('✔ ' if good else '✘ ')+label)
    print('\n检查不会联网，也不会验证真实微信版本/账号可用性。')
    if strict and not all(checks.values()):
        print('预检未满足；不会启动真实发送。请先阅读 docs/INSTALL_GUIDE.md。')
        return 1
    return 0

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--strict',action='store_true')
    raise SystemExit(main(parser.parse_args().strict))
