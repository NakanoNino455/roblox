@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo Xiaoqi - optional basic Python packages

echo This will download and install only the OpenAI Python SDK.
echo It does NOT install WeChat automation, voice models, or music content.
choice /c YN /m "Continue with pip install"
if errorlevel 2 goto end
py -3.11 -m pip install -r "%~dp0requirements-basic.txt"
:end
pause
