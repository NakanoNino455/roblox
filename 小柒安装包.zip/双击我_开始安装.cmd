@echo off
chcp 65001 >nul
cd /d "%~dp0"
py -3.11 -c "import tkinter" >nul 2>&1
if errorlevel 1 (
 echo [Xiaoqi] Python 3.11 not detected.
 echo Please install Python 3.11 x64 from https://www.python.org/downloads/
 echo Enable Python Launcher, then double-click this file again.
 pause
 exit /b 1
)
start "" pyw -3.11 "%~dp0GUI_INSTALL.py"
if errorlevel 1 (
 py -3.11 "%~dp0GUI_INSTALL.py"
 pause
)
