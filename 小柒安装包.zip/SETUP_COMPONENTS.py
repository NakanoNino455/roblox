# -*- coding: utf-8 -*-
"""Explicit opt-in third-party provisioning (network). Never touches existing Xiaoqi instance.
Github URLs / ModelScope are upstream; respect each license and network policy.
"""
from pathlib import Path
import argparse,os,subprocess,sys,shutil,datetime,json
ROOT=Path(__file__).resolve().parent
APP=ROOT if (ROOT/'xiaoqi_v4_voice_choice.py').exists() else ROOT/'app'
LOG=ROOT/'logs';LOG.mkdir(exist_ok=True)
def emit(*xs):print(*xs,flush=True)
def run(*cmd,cwd=None):
    emit('运行：', ' '.join(map(str,cmd)))
    p=subprocess.Popen(list(map(str,cmd)),cwd=str(cwd) if cwd else None,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace')
    with (LOG/'setup_latest.log').open('a',encoding='utf8') as f:
      for line in p.stdout: print(line.rstrip(),flush=True);f.write(line)
    if p.wait():raise RuntimeError('上一步失败，请查看 logs/setup_latest.log；停止后不会宣称安装成功。')
def python_selector(prefer310=False):
    if prefer310:
      p=subprocess.run(['py','-3.10','-c','import sys;print(sys.executable)'],capture_output=True,text=True)
      if p.returncode==0:return ['py','-3.10']
    return ['py','-3.11']
def venv(folder,interpreter):
    py=folder/'Scripts'/'python.exe'
    if not py.is_file():run(*interpreter,'-m','venv',folder)
    return py
def repo(url,dest):
    if (dest/'.git').exists():emit('发现现有仓库，跳过覆盖：',dest);return
    if dest.exists() and any(dest.iterdir()):raise RuntimeError('安装目标非空，不会覆盖：'+str(dest))
    if not shutil.which('git'):raise RuntimeError('需要先安装 Git for Windows： https://git-scm.com/downloads/win')
    dest.parent.mkdir(parents=True,exist_ok=True)
    run('git','clone','--recursive',url,dest)
def base():
    p=venv(ROOT/'.xiaoqi_base_env',python_selector())
    run(p,'-m','pip','install','--disable-pip-version-check','openai')
    emit('注意：wechatauto 未提供已验证的安装来源，请按适配版本单独获取，不能宣称基础微信自动化就绪。')
    # Validate wechatauto install without touching accounts or DB.
    run(p,'-c','import openai;print("OpenAI SDK ready; WeChat integration NOT verified")')
    emit('OpenAI SDK 已就绪；微信自动化依赖仍需单独解决。')
def voice():
    interpreter=python_selector(prefer310=True)
    p=venv(APP/'cosyvoice_env',interpreter)
    d=APP/'third_party'/'CosyVoice'
    repo('https://github.com/FunAudioLLM/CosyVoice.git',d)
    # Official dependencies may require conda / additional OS packages; explicit failure is visible.
    run(p,'-m','pip','install','--disable-pip-version-check','-r',d/'requirements.txt')
    run(p,'-m','pip','install','--disable-pip-version-check','modelscope')
    dst=APP/'CosyVoice2-0.5B';dst.mkdir(exist_ok=True)
    run(p,'-c',"from modelscope import snapshot_download;import sys;snapshot_download('iic/CosyVoice2-0.5B',local_dir=sys.argv[1])",dst)
    emit('CosyVoice 源码、依赖及模型安装流程结束。仍需在 FEATURE_SETUP.py 选择本人参考音色并试听。')
def singing():
    p=venv(APP/'xiaoqi_seedvc_env',python_selector(prefer310=True))
    d=APP/'xiaoqi_singing'/'third_party'/'seed-vc'
    repo('https://github.com/Plachtaa/seed-vc.git',d)
    run(p,'-m','pip','install','--disable-pip-version-check','-r',d/'requirements.txt')
    run(p,'-c','import torch,torchaudio;print("Torch ready",torch.__version__)')
    emit('Seed-VC依赖已安装。官方首次推理时才下载模型权重；请在曲库中选用本人有权使用的清唱素材验证。')
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--component',choices=['base','voice','singing'],required=True);a=parser.parse_args()
    with (LOG/'setup_latest.log').open('a',encoding='utf8') as f:f.write('\n=== '+datetime.datetime.now().isoformat()+' '+a.component+' ===\n')
    try:globals()[a.component]()
    except Exception as e:emit('安装未完成：',type(e).__name__,str(e));sys.exit(1)
