# 语音与唱歌完整安装指南 · 作者：同一意

此文档适用于 v1.0.0 全功能安装版。安装包**有全部作者自写的桥接代码，不包含数 GB 的预训练模型权重、参考音色或商业歌曲**。

## 一、语音回复：CosyVoice2

1. 按 README 安装小柒，并运行 `FEATURE_SETUP.cmd`。
2. 在“安装缺失环境”中点击“下载和安装 CosyVoice2”，程序会尝试从官方仓库获取源码、建立独立的 Python 环境、安装依赖和从 ModelScope 下载模型。
3. 此过程可能需要 Git for Windows、Python 3.10、Conda、匹配的 PyTorch/CUDA。**必须核对官方仓库当前要求**。安装失败请查看 `logs/setup_latest.log`，不要反复重装整个机器人。
4. 在“配置模型路径”中选取**自己的**参考音色 WAV（16000 Hz 单声道推荐），确认 CosyVoice 源码、模型目录、Python 路径正确，点击“保存路径”。
5. 用 `FULL_CHECK.cmd` 检查路径，再在使用自己的素材的前提下实际试听。路径存在 ≠ 模型可成功推理。

官方源码：https://github.com/FunAudioLLM/CosyVoice
官方模型：https://modelscope.cn/models/iic/CosyVoice2-0.5B

## 二、微信语音气泡 / 电脑声音设备

原发送器通过桌面微信及音频设备操作录制语音。请使用兼容 Windows 微信的版本；若系统缺少合适的录放音路径，可能需要安装官方 VB-CABLE 虚拟音频驱动，并手动配置输入/输出及授权录音设备。
驱动下载及许可见：https://vb-audio.com/Cable/ 。安装驱动往往需要管理员权限/重启；本发布包不会静默安装或附带它。
Windows 音频播放/转换可能需要 FFmpeg，可从 https://ffmpeg.org/download.html 获取并加入 PATH。安装后的命令提示符执行 `ffmpeg -version` 验证。

## 三、整首唱歌：Seed-VC

1. 在 `FEATURE_SETUP.cmd` 中点击“下载和安装 Seed-VC”，它会单独获取官方 GPL-3.0 仓库并尝试安装依赖，不会打包作者的模型或共享私人声线。
2. 填写 Seed-VC 源码、运行 Python 与歌曲工作台目录。上传或导入**你有权使用**的清唱 WAV。它不会只凭纯伴奏或歌曲名称演唱歌词。
3. 通过 `xiaoqi_autosong_v1/music_app.py` 导入歌曲并转换成自己的声音；验证整首 WAV 成功后再启用微信点歌。
4. 普通点歌会随机抽取片段，完整版会拆分多条语音，**但消息实际送达仍依赖微信界面与已授权发送目标**。

官方 Seed-VC（归档，GPL-3.0）：https://github.com/Plachtaa/seed-vc

## 四、可能的失败与应对

| 现象 | 检查 |
|---|---|
| CosyVoice 安装失败 | `logs/setup_latest.log`、Conda / Python 版本、PyTorch 与 CUDA、网路来源 |
| 语音生成缺参考音色 | `FEATURE_SETUP.cmd` 中 `reference_wav` 的文件路径和 16 kHz 采样率 |
| 模型文件夹存在但生成失败 | 权重是否下载完整、源码是否与模型版本匹配 |
| 唱歌只有固定片段 | 是否完整导入源人声，转换成品是否完整，随机/全曲命令是否匹配 |
| 语音条发送失败 | 微信版本、前台聊天目标、虚拟音频驱动、录音设备权限 |
| 微信里无法点歌 | 先检查 `autosong.json`、库中是否有已完成小柒音色 WAV、聊天授权范围 |

发布包静态检查通过，不等于每台电脑上的音频链路都已通过验证。
