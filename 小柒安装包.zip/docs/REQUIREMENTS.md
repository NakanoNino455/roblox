# 小柒运行环境要求（对应发布候选版 v1.0.0）

## A. 基础运行——AI 文字聊天

| 项目 | 要求 | 说明 |
|---|---|---|
| 系统 | Windows 10 / 11 64 位 | 原程序基于 Windows 桌面微信与 Windows GUI；macOS / Linux 不在支持范围 |
| Python | **Python 3.11，64 位** | 代码和原有启动方式按 3.11 开发；其他版本未验证 |
| 微信客户端 | **兼容 `wechatauto` 的 Windows 桌面微信** | 特定微信版本、数据库接口、自动化操作必须单独核对；**不能保证最新版微信可用** |
| 自动化库 | `wechatauto`（兼容版本） | 未包含到 ZIP；因不同版本的接口差异很大，请从可信来源获取并审查 |
| LLM API | **DeepSeek API Key**，能够访问 API | 当前主程序使用 `openai` Python SDK 访问 `https://api.deepseek.com`；可能产生 API 费用 |
| Python 库 | `openai` | 安装包提供单独的依赖安装命令，不自动下载 |
| 硬件 | 普通能够运行桌面微信的 64 位 Windows PC | **基础文字功能不要求独立 NVIDIA 显卡**；具体 CPU / 内存下限未进行基准测试 |
| 权限 | 普通用户通常即可 | 具体取决于微信自动化库和设备安全策略；不鼓励提权绕过系统保护 |

## B. 可选——语音气泡 / 本地语音模型

- 本地 **CosyVoice 2**：需要独立安装运行环境、模型权重、参考音色 WAV；由 FEATURE_SETUP.cmd 联网部署或选择本机已有环境；模型素材不在 ZIP 内。
- 源码引用 `torch`、`soundfile`、`numpy`、`sounddevice`，有些可选场景使用 `pilk` / 微信媒体接口。
- Windows 音频设备、兼容的虚拟音频线及 GUI 前台操作可能影响是否能实际发送微信语音气泡。
- NVIDIA CUDA GPU **推荐但不是基础文字功能硬要求**；显存 / RAM / 磁盘容量取决于下载的模型与选用音色，**未实测统一最低配置**。
- 原有示例路径含 `YOUR_USERNAME` 占位符，首次使用需按本机实际环境配置，不能直接照抄作者电脑路径。

## C. 可选——离线音乐点歌与唱歌

- 自备**有合法使用权**的整首人声音频素材、Seed-VC 等兼容转换模型与转换环境。
- 曲库模块支持 `catalog.sqlite3` 元数据、清唱 WAV、转换缓存和分段接口；**发布包不含商业音乐音频、原作者克隆音色、模型权重或现成曲库**。
- 数据库能记录歌曲不等于全部歌曲都已完成音色转换，也不保证微信语音发送端到端成功。
- 默认禁止点歌自动发送，需先验证微信机器人权限与发送器。

## D. 不承诺的项目

无法保证微信更新后保持兼容；没有宣称所有型号 GPU、Python 版本或 Windows 系统已经通过测试；不保证所有第三方模型支持商用。

## E. 第三方资源提示

- Python: https://www.python.org/downloads/windows/
- DeepSeek API 文档: https://api-docs.deepseek.com/
- PyPI 官方仓库: https://pypi.org/
- `wechatauto` 版本与许可证需由安装者根据当前微信客户端进一步确认。
