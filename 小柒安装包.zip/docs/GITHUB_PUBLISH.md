# 将小柒发布到 GitHub（新手版）

1. 在 GitHub 登录自己的账户 `2068969346-maker`。
2. 创建新仓库，例如 `xiaoqi-wechat-assistant`，初期选择 **Private**，避免公开意外隐私。
3. 上传本包根目录的 README、app、docs、安装器和辅助脚本。**切勿上传个人 `config.json` 或项目运行目录中的数据库、音乐、音色和模型**。
4. 在仓库内检查 README 作者、.gitignore、提交内容及第三方依赖许可。先在一台干净的 Windows 测试安装、演示和微信发送。
5. 通过 Releases 创建 `v0.2.0-rc` 预发布，附件上传本 ZIP。说明它是带引导的源码安装包而非单独 `.exe`。
6. 所有安装测试通过后再把仓库改为 Public。公开后任何人都能看到提交过的源码，千万别把私密文件先提交再删除。

建议 Release 标题：`Xiaoqi Community Edition v0.2.0-rc — Created by 同一意`
建议简介：Windows / Python 3.11 / WeChat version-compatible wechatauto / optional local voice; safe-default setup wizard. No commercial song audio or model weights bundled.
