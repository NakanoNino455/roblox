# 🐳 小柒 Xiaoqi AI 微信助手 · 完整功能安装版

**作者：同一意** · GitHub：[@2068969346-maker](https://github.com/2068969346-maker)

这是小柒已编写功能的**统一 Windows 安装及环境配置包**，不再需要分别下载语音/点歌模块的补丁。**它并非已经附带所有大型 AI 权重的离线 EXE**；语音和唱歌功能首次使用需要自行下载官方模型并提供授权音色/清唱素材。

## 已整合模块

- 微信 AI 聊天、群聊 / 私聊，已存在的消息去重、记忆、互动、主人管理指令
- 定时群早报及会话刷新避让修复（需本人配置并授权发送）
- 百度等联网搜索相关代码、图片/媒体辅助模块
- CosyVoice 2 本地语音合成、微信语音气泡发送
- Seed-VC 整首歌声音色转换，离线 SQLite 曲库管理
- 普通点歌随机片段、整首歌曲按约 45 秒连续分条发送（实际微信送达需测试）

## 环境要求

**Windows 10/11 64 位；Python 3.11 64 位（基础程序）；兼容 `wechatauto` 的 Windows 桌面微信；DeepSeek API Key 与网络。**

AI 语音：CosyVoice 官方环境/权重、授权参考音色 WAV、适配 CUDA 的 PyTorch；唱歌：Seed-VC 官方环境/权重、合法可用的人声音源。语音/唱歌推荐 NVIDIA CUDA GPU，下载及缓存可能占用数 GB 至数十 GB；CPU 模式是否可用取决于模型及硬件。

CosyVoice 官方安装文档基于 Python 3.10 和 Conda；一键部署会尝试独立虚拟环境，但部分 Windows 机器需要人工安装官方依赖。Seed-VC 官方源码已归档并遵循 GPL-3.0，安装工具会从官方仓库另行下载，不在此包内再分发。安装失败会留下日志，不会谎报安装成功。

## 新手安装步骤

1. 从 GitHub Release 下载 ZIP，**完整解压**，确保 `INSTALL.cmd` 和 `setup_wizard.py` 在同一文件夹。
2. **先安装 Python 3.11**，运行 `INSTALL.cmd`，选择新的空目录安装。
3. 进入安装目录，运行 `CONFIGURE.cmd` 填写自己的微信小柒账号、机器人微信 wxid 与主人 wxid。
4. 运行 `FEATURE_SETUP.cmd`，按顺序点击 **准备基础聊天依赖 → 下载和安装 CosyVoice2 → 下载和安装 Seed-VC**。首次下载需联网、可能需要 Git for Windows、Python 3.10、Conda、CUDA 组件。
5. 在同一个界面确认 **参考音色 WAV** 路径，点击「保存路径并写入离线音乐库配置」。
6. 用 `FULL_CHECK.cmd` 和 `CHECK_ENV.cmd` 检查，运行 `RUN_DEMO.cmd` 进行本地模拟。
7. 将你有权使用的完整人声 WAV 导入 `xiaoqi_autosong_v1/music_app.py` 界面，先验证离线整曲转换与试听。
8. 检查账号授权、发送范围和微信版本，然后经本人同意运行 `START_WITH_CONFIRMATION.cmd`。**默认关闭自动发送，避免误发消息。**

## 版本与边界

代码与安装流程已静态检查，在作者本人之外的全新 Windows 电脑上**尚未完成全部微信 / CosyVoice / Seed-VC 端到端验收**。新机器的 Git、依赖、微信接口及 CUDA 环境各不相同；安装器会提供日志和明确结果，不保证所有系统自动部署成功。模型权重、私人音色、聊天记录、商业歌曲均不随包分发。

这是源码 + GUI 安装流程的 ZIP，不是可在任何电脑免配置直接运行的单文件 EXE。


详细设置请先运行 FEATURE_SETUP.cmd，再使用 FULL_CHECK.cmd 检查各路径与模型。
