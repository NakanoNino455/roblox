@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Local-only demo, not real WeChat sending.
py -3.11 -X utf8 "%~dp0xiaoqi_v32.py" --demo
pause
