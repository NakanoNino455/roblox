# -*- coding: utf-8 -*-
from pathlib import Path
import sys,os,json,importlib.util,subprocess
ROOT=Path(__file__).resolve().parent
APP=ROOT if (ROOT/'xiaoqi_v4_voice_choice.py').is_file() else ROOT/'app'
PRIVATE=APP/'private'/'runtime_paths.json'
def load(p):
 try:return json.loads(p.read_text(encoding='utf8'))
 except (OSError,ValueError):return {}
cfg=load(PRIVATE)
def path(key,default,typ='file'):
 p=Path(cfg.get(key,default));return p,(p.is_file() if typ=='file' else p.is_dir())
def check():
 print('Xiaoqi 全功能检查 | 作者：同一意')
 print('微信基础账号配置:',bool(load(APP/'config.json').get('approved_account_wxid','').startswith('wxid_')))
 py=ROOT/'.xiaoqi_base_env'/'Scripts'/'python.exe'
 print('聊天独立Python环境:',py.is_file())
 for k,d,t in [('cosy_root',APP/'third_party'/'CosyVoice','dir'),('cosy_python',APP/'cosyvoice_env'/'Scripts'/'python.exe','file'),('cosy_model',APP/'CosyVoice2-0.5B','dir'),('reference_wav',APP/'private'/'reference.wav','file'),('seed_root',APP/'xiaoqi_singing'/'third_party'/'seed-vc','dir'),('seed_python',APP/'xiaoqi_seedvc_env'/'Scripts'/'python.exe','file'),('song_studio',APP/'xiaoqi_singing'/'xiaoqi_songstudio','dir')]:
  p,ok=path(k,d,t); print(('OK' if ok else 'MISSING'),k,str(p))
 print('转换歌曲数量（未预载商业音源）：', len(list((APP/'xiaoqi_autosong_v1'/'converted').glob('*.wav'))) if (APP/'xiaoqi_autosong_v1'/'converted').exists() else 0)
 print('微信语音气泡可能需要 VB-CABLE 驱动和音频设备权限。')
 print('注意：全部 OK 也需在获得允许的好友/群聊测试实际送达。')
if __name__=='__main__':check()
